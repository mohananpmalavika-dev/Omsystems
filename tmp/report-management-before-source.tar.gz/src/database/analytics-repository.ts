import { randomUUID } from "node:crypto";
import type { Pool, PoolClient } from "pg";
import { activeCamera } from "./active-resource.js";
import type {
  AnalyticsAlert,
  AnalyticsEvent,
  AnalyticsIngestResult,
  AnalyticsRule,
  AlertNotification,
  AlertNotificationPolicy,
} from "../domain/models.js";
import type {
  AnalyticsAlertFilters,
  AnalyticsAlertsAggregateSummary,
  AnalyticsAlertTransitionInput,
  AnalyticsEventFilters,
  AnalyticsEventInput,
  AnalyticsRuleInput,
} from "../control-plane-store.js";
import {
  analyticsAlertDescription,
  analyticsAlertTitle,
  eventDetectionTypes,
  isTerminalAlertStatus,
  sortedMatchingRules,
  isConfirmedShutterTransition,
} from "../analytics/rule-engine.js";
import { moreSevere, resolveAlertSeverity } from "../analytics/severity-policy.js";
import { buildFalseAlarmSignature, matchesFalseAlarm, type FalseAlarmSignature } from "../analytics/false-alarm-feedback.js";

function correlationCount(metadata?: Record<string, unknown>) {
  const explicit = metadata?.correlatedDetectionCount;
  if (typeof explicit === "number" && Number.isFinite(explicit)) return Math.max(0, Math.floor(explicit));
  return Array.isArray(metadata?.correlatedDetectionTypes) ? metadata.correlatedDetectionTypes.length : 0;
}

const ruleSelection = `
  SELECT rule.*,
         zone.id::text AS zone_join_id, zone.name AS zone_name,
         zone.shape AS zone_shape, zone.points AS zone_points
  FROM analytics_rules rule
  LEFT JOIN analytics_zones zone ON zone.id=rule.zone_id`;

export class AnalyticsRepository {
  constructor(private readonly pool: Pool) {}

  private async resolveTenantUuid(tenantIdOrSlug: string): Promise<string> {
    const slug = (tenantIdOrSlug || "omsystems").trim();

    // 1. If it looks like a UUID, verify it exists in tenants table
    if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(slug)) {
      const existing = await this.pool.query(
        `SELECT id::text FROM tenants WHERE id = $1::uuid LIMIT 1`,
        [slug],
      ).catch(() => ({ rows: [] }));
      if (existing.rows[0]?.id) {
        return existing.rows[0].id;
      }

      // If this UUID does not exist in tenants, insert it so foreign keys never fail
      try {
        const insertedUuid = await this.pool.query(
          `INSERT INTO tenants (id, slug, name, status, created_at, updated_at)
           VALUES ($1::uuid, $2, $3, 'active', now(), now())
           ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name
           RETURNING id::text`,
          [slug, `tenant-${slug.slice(0, 8)}`, "Sentinel Grid Enterprise"],
        );
        if (insertedUuid.rows[0]?.id) return insertedUuid.rows[0].id;
      } catch {
        // Continue to slug lookup or fallback
      }
    }

    // 2. Lookup by slug
    const result = await this.pool.query(
      `SELECT id::text FROM tenants WHERE slug = $1 OR id::text = $1 LIMIT 1`,
      [slug],
    ).catch(() => ({ rows: [] }));
    if (result.rows[0]?.id) {
      return result.rows[0].id;
    }

    // 3. Insert tenant with generated UUID
    try {
      const inserted = await this.pool.query(
        `INSERT INTO tenants (id, slug, name, status, created_at, updated_at)
         VALUES (gen_random_uuid(), $1, $2, 'active', now(), now())
         ON CONFLICT (slug) DO UPDATE SET name = EXCLUDED.name
         RETURNING id::text`,
        [slug, slug === "omsystems" ? "Sentinel Grid Enterprise" : slug],
      );
      if (inserted.rows[0]?.id) return inserted.rows[0].id;
    } catch {
      // safe fallback: return any existing tenant
      const anyTenant = await this.pool.query(
        `SELECT id::text FROM tenants ORDER BY created_at ASC LIMIT 1`
      ).catch(() => ({ rows: [] }));
      if (anyTenant.rows[0]?.id) return anyTenant.rows[0].id;
    }

    // 4. Ultimate fallback
    const fallback = await this.pool.query(
      `INSERT INTO tenants (id, slug, name, status, created_at, updated_at)
       VALUES ('00000000-0000-0000-0000-000000000001'::uuid, 'default-tenant', 'Sentinel Grid Enterprise', 'active', now(), now())
       ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name
       RETURNING id::text`,
    );
    return fallback.rows[0]!.id;
  }

  async listRules(cameraId: string): Promise<AnalyticsRule[]> {
    const result = await this.pool.query(
      `${ruleSelection}
       WHERE rule.camera_id=$1 AND rule.archived_at IS NULL ORDER BY rule.name`,
      [cameraId],
    );
    return result.rows.map(mapRule);
  }

  async listRulesByCameraIds(cameraIds: string[]): Promise<AnalyticsRule[]> {
    if (cameraIds.length === 0) return [];
    const result = await this.pool.query(
      `${ruleSelection}
       WHERE rule.camera_id = ANY($1::uuid[]) AND rule.archived_at IS NULL`,
      [cameraIds],
    );
    return result.rows.map(mapRule);
  }

  async createRule(
    tenantId: string,
    cameraId: string,
    createdBy: string | undefined,
    input: AnalyticsRuleInput,
  ): Promise<AnalyticsRule> {
    const client = await this.pool.connect();
    try {
      await client.query("BEGIN");
      const zoneId = await replaceZone(client, tenantId, cameraId, input.zone);
      const result = await client.query(
        `INSERT INTO analytics_rules (
           id, tenant_id, camera_id, zone_id, model_id, name, detection_type,
           enabled, schedule, object_classes, min_confidence,
           min_duration_seconds, direction, severity, cooldown_seconds,
           recipients, escalate_after_seconds, recording_policy,
           pre_roll_seconds, post_roll_seconds, created_by, shutter_config
         )
         SELECT $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,
                $16,$17,$18,$19,$20,$21,$22
          FROM cameras camera
          JOIN resource_nodes node ON node.id=camera.resource_node_id
          WHERE camera.id=$3
            AND ($21::uuid IS NULL OR EXISTS (
              SELECT 1 FROM users actor WHERE actor.id=$21
            ))
          RETURNING id`,
        [
          randomUUID(), tenantId, cameraId, zoneId, input.modelId ?? null,
          input.name, input.detectionType, input.enabled,
          input.schedule ? JSON.stringify(input.schedule) : null,
          JSON.stringify(input.objectClasses), input.minConfidence,
          input.minDurationSeconds, input.direction, input.severity,
          input.cooldownSeconds, JSON.stringify(input.recipients),
          input.escalateAfterSeconds ?? null, input.recordingPolicy,
          input.preRollSeconds, input.postRollSeconds, createdBy ?? null,
          input.shutterConfig ? JSON.stringify(input.shutterConfig) : null,
        ],
      );
      if (!result.rows[0]) throw new Error("camera_not_found");
      const created = await selectRule(client, result.rows[0].id);
      await client.query("COMMIT");
      return created!;
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    } finally {
      client.release();
    }
  }

  async updateRule(
    id: string,
    tenantId: string,
    cameraId: string,
    input: Partial<AnalyticsRuleInput>,
  ): Promise<AnalyticsRule | undefined> {
    const client = await this.pool.connect();
    try {
      await client.query("BEGIN");
      const current = await selectRule(client, id, tenantId, cameraId, true);
      if (!current) {
        await client.query("ROLLBACK");
        return undefined;
      }
      const next = { ...current, ...input };
      let zoneId = current.zone?.id ?? null;
      if (input.zone) {
        if (current.zone) {
          await client.query(
            `UPDATE analytics_zones SET name=$2, shape=$3, points=$4, updated_at=now()
             WHERE id=$1 AND tenant_id=$5 AND camera_id=$6`,
            [current.zone.id, input.zone.name, input.zone.shape,
              JSON.stringify(input.zone.points), tenantId, cameraId],
          );
        } else {
          zoneId = await replaceZone(client, tenantId, cameraId, input.zone);
        }
      }
      await client.query(
        `UPDATE analytics_rules SET
           zone_id=$4, model_id=$5, name=$6, detection_type=$7, enabled=$8,
           schedule=$9, object_classes=$10, min_confidence=$11,
           min_duration_seconds=$12, direction=$13, severity=$14,
           cooldown_seconds=$15, recipients=$16, escalate_after_seconds=$17,
           recording_policy=$18, pre_roll_seconds=$19, post_roll_seconds=$20,
           shutter_config=$21, updated_at=now()
         WHERE id=$1 AND tenant_id=$2 AND camera_id=$3`,
        [
          id, tenantId, cameraId, zoneId, next.modelId ?? null, next.name,
          next.detectionType, next.enabled,
          next.schedule ? JSON.stringify(next.schedule) : null,
          JSON.stringify(next.objectClasses), next.minConfidence,
          next.minDurationSeconds, next.direction, next.severity,
          next.cooldownSeconds, JSON.stringify(next.recipients),
          next.escalateAfterSeconds ?? null, next.recordingPolicy,
          next.preRollSeconds, next.postRollSeconds,
          next.shutterConfig ? JSON.stringify(next.shutterConfig) : null,
        ],
      );
      const updated = await selectRule(client, id);
      await client.query("COMMIT");
      return updated;
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    } finally {
      client.release();
    }
  }

  async deleteRule(id: string, tenantId: string, cameraId: string) {
    const result = await this.pool.query(
      `UPDATE analytics_rules SET enabled=false, archived_at=now(), updated_at=now()
       WHERE id=$1 AND tenant_id=$2 AND camera_id=$3 AND archived_at IS NULL
       RETURNING zone_id`,
      [id, tenantId, cameraId],
    );
    if (!result.rows[0]) return false;
    return true;
  }

  async processEvent(input: AnalyticsEventInput): Promise<AnalyticsIngestResult> {
    const client = await this.pool.connect();
    try {
      await client.query("BEGIN");
      await client.query(
        "SELECT pg_advisory_xact_lock(hashtextextended($1, 0))",
        [`${input.tenantId}:${input.sourceEventId}`],
      );
      await client.query("SELECT pg_advisory_xact_lock(hashtextextended($1, 0))",
        [`analytics-camera:${input.tenantId}:${input.cameraId}`]);
      const camera = await client.query(
        `SELECT camera.id, COALESCE(camera.branch_node_id::text, node.id::text) AS branch_id
         FROM cameras camera
         JOIN resource_nodes node ON node.id=camera.resource_node_id
         WHERE camera.id=$1 AND node.tenant_id=$2`,
        [input.cameraId, input.tenantId],
      );
      if (!camera.rows[0]) throw new Error("camera_not_found");
      const cameraBranchId: string = camera.rows[0].branch_id ?? "";
      const duplicate = await client.query(
        "SELECT * FROM analytics_events WHERE tenant_id=$1 AND source_event_id=$2",
        [input.tenantId, input.sourceEventId],
      );
      if (duplicate.rows[0]) {
        const alerts = await client.query(
          "SELECT * FROM analytics_alerts WHERE event_id=$1 ORDER BY created_at",
          [duplicate.rows[0].id],
        );
        const rules = await rulesByIds(client, alerts.rows.map((row) => row.rule_id));
        await client.query("COMMIT");
        return {
          event: { ...mapEvent(duplicate.rows[0], []), status: "duplicate" },
          alerts: alerts.rows.map(mapAlert), rules,
        };
      }
      const candidates = await client.query(
        `${ruleSelection}
         WHERE rule.camera_id=$1 AND rule.tenant_id=$2
           AND rule.enabled AND rule.archived_at IS NULL
           AND rule.detection_type = ANY($3::text[])`,
        [input.cameraId, input.tenantId, eventDetectionTypes(input)],
      );
      const rules = sortedMatchingRules(candidates.rows.map(mapRule), input);
      const signature = rules.length ? await buildFalseAlarmSignature(input) : null;
      const eventId = randomUUID();
      await client.query(
        `INSERT INTO analytics_events (
           id, tenant_id, camera_id, source_event_id, primary_rule_id,
           detection_type, occurred_at, ended_at, confidence, duration_seconds,
           model_version, snapshot_reference, clip_reference, metadata, status,
           rejection_reason
         ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16)`,
        [
          eventId, input.tenantId, input.cameraId, input.sourceEventId,
          rules[0]?.id ?? null, input.detectionType, input.occurredAt,
          input.endedAt ?? null, input.confidence, input.durationSeconds,
          input.modelVersion, input.snapshotReference ?? null,
          input.clipReference ?? null, JSON.stringify(input.metadata ?? {}),
          rules.length ? "accepted" : "unmatched",
          rules.length ? null : "no_matching_rule",
        ],
      );
      for (const object of input.objects) {
        const bbox = object.boundingBox ?? { x: 0, y: 0, width: 1, height: 1 };
        const objectClass = (object.label || input.detectionType || "object").slice(0, 50);
        const confidence = Math.min(1.0, Math.max(0.0, Number(Number(object.confidence ?? input.confidence ?? 0).toFixed(2))));
        await client.query("SAVEPOINT insert_object");
        try {
          await client.query(
            `INSERT INTO detected_objects (
               id, event_id, camera_id, tenant_id, detected_at, object_class, label, confidence, track_id, bounding_box
             ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
            [
              randomUUID(),
              eventId,
              input.cameraId,
              input.tenantId,
              input.occurredAt || new Date().toISOString(),
              objectClass,
              object.label || objectClass,
              confidence,
              object.trackId ?? null,
              JSON.stringify(bbox),
            ],
          );
          await client.query("RELEASE SAVEPOINT insert_object");
        } catch (err) {
          await client.query("ROLLBACK TO SAVEPOINT insert_object");
          console.warn(`Failed to insert detected object: ${err instanceof Error ? err.message : String(err)}`);
        }
      }

      const alerts: AnalyticsAlert[] = [];
      let created = 0;
      let suppressedByPolicy = 0;
      for (const rule of rules) {
        const feedback = signature ? await client.query(
          `SELECT false_alarm_signature FROM analytics_alerts
           WHERE tenant_id=$1 AND camera_id=$2 AND rule_id=$3
             AND status='false_alarm' AND false_alarm_signature IS NOT NULL`,
          [input.tenantId, input.cameraId, rule.id],
        ) : { rows: [] };
        if (feedback.rows.some((row) => matchesFalseAlarm(json<FalseAlarmSignature | null>(row.false_alarm_signature, null), signature))) continue;
        const effectiveSeverity = resolveAlertSeverity({
          configuredSeverity: rule.severity,
          durationSeconds: input.durationSeconds,
          correlatedDetectionCount: correlationCount(input.metadata),
        });
        const cooldownSeconds = Math.max(rule.cooldownSeconds || 60, 30);
        const recent = isConfirmedShutterTransition(input) ? {rows:[]} : await client.query(
          `SELECT * FROM analytics_alerts
           WHERE rule_id=$1 AND camera_id=$2
             AND status NOT IN ('resolved', 'false_alarm', 'suppressed')
             AND last_detected_at >= $3::timestamptz - ($4::double precision * interval '1 second')
           ORDER BY last_detected_at DESC LIMIT 1 FOR UPDATE`,
          [rule.id, input.cameraId, input.occurredAt, cooldownSeconds],
        );
        if (recent.rows[0]) {
          const updated = await client.query(
            `UPDATE analytics_alerts SET last_detected_at=$2,
                occurrence_count=occurrence_count+1,
                confidence=GREATEST(confidence,$3), severity=$4, updated_at=now()
              WHERE id=$1 RETURNING *`,
            [recent.rows[0].id, input.occurredAt, input.confidence,
              moreSevere(recent.rows[0].severity, effectiveSeverity)],
          );
          alerts.push(mapAlert(updated.rows[0]));
          continue;
        }

        // If an alert for this rule/camera was recently resolved within cooldownSeconds,
        // suppress creating a new alert to prevent flutter.
        const recentlyResolved = isConfirmedShutterTransition(input) ? {rows:[]} : await client.query(
          `SELECT id FROM analytics_alerts
           WHERE rule_id=$1 AND camera_id=$2
             AND status = 'resolved'
             AND resolved_at IS NOT NULL
             AND resolved_at >= $3::timestamptz - ($4::double precision * interval '1 second')
           LIMIT 1`,
          [rule.id, input.cameraId, input.occurredAt, rule.cooldownSeconds],
        );
        if (recentlyResolved.rows[0]) {
          continue;
        }
        // ── Suppression gate ─────────────────────────────────────────────────
        // Check alert_suppression_config using the same precedence as
        // AlertSuppressionService.isSuppressed(): camera > branch > global.
        // A match with suppressed=true blocks alert creation; suppressed=false
        // at a more-specific scope re-enables alerts within a broader suppression.
        const suppressionCheck = await client.query<Record<string, any>>(
          `SELECT suppressed
           FROM alert_suppression_config
           WHERE tenant_id = $1
             AND (branch_id = $2 OR branch_id IS NULL)
             AND (camera_id = $3 OR camera_id IS NULL)
             AND (detection_type = $4 OR detection_type IS NULL)
           ORDER BY
             CASE WHEN camera_id IS NOT NULL THEN 0
                  WHEN branch_id IS NOT NULL THEN 1
                  ELSE 2 END,
             CASE WHEN detection_type IS NOT NULL THEN 0 ELSE 1 END
           LIMIT 1`,
          [input.tenantId, cameraBranchId || null, input.cameraId, input.detectionType],
        );
        if (suppressionCheck.rows[0]?.suppressed === true) {
          suppressedByPolicy += 1;
          continue; // skip alert creation for this rule
        }
        // ── End suppression gate ─────────────────────────────────────────────

        const alertId = randomUUID();
        const inserted = await client.query(
          `INSERT INTO analytics_alerts (
             id, tenant_id, camera_id, rule_id, event_id, title, description,
             severity, confidence, object_classes, model_version,
           snapshot_reference, clip_reference, first_detected_at,
             last_detected_at, sla_due_at, correlation_key, detection_signature
           ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$14,$15,$16,$17)
           RETURNING *`,
          [
            alertId, input.tenantId, input.cameraId, rule.id, eventId,
            analyticsAlertTitle(rule, input.metadata), analyticsAlertDescription(rule, input.metadata),
            effectiveSeverity, input.confidence,
            JSON.stringify([...new Set(input.objects.map((object) => object.label))]),
            input.modelVersion, `/v1/alerts/${alertId}/evidence/snapshot`,
            input.clipReference ?? null, input.occurredAt,
            rule.escalateAfterSeconds
              ? new Date(Date.parse(input.occurredAt) + rule.escalateAfterSeconds * 1_000).toISOString()
              : null,
            typeof input.metadata?.correlationKey === "string"
              ? input.metadata.correlationKey : `${rule.id}:${input.cameraId}`,
            JSON.stringify(signature),
          ],
        );
        alerts.push(mapAlert(inserted.rows[0]));
        created += 1;
        for (const recipient of rule.recipients) {
          await client.query(
            `INSERT INTO analytics_notifications (
               id, tenant_id, alert_id, recipient
             ) VALUES ($1,$2,$3,$4)`,
            [randomUUID(), input.tenantId, alertId, recipient],
          );
        }
      }
      if (rules.length > 0 && created === 0) {
        // Mark event suppressed whether by cooldown/dedup OR by the suppression policy.
        await client.query(
          "UPDATE analytics_events SET status='suppressed' WHERE id=$1",
          [eventId],
        );
      }
      const event = await client.query("SELECT * FROM analytics_events WHERE id=$1", [eventId]);
      await client.query("COMMIT");
      return { event: mapEvent(event.rows[0], input.objects), alerts, rules };
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    } finally {
      client.release();
    }
  }

  async getEvent(id: string, tenantId: string): Promise<AnalyticsEvent | undefined> {
    const result = await this.pool.query(
      `SELECT event.* FROM analytics_events event WHERE event.id=$1::uuid AND event.tenant_id=$2 LIMIT 1`,
      [id, tenantId],
    );
    return result.rows[0] ? mapEvent(result.rows[0], []) : undefined;
  }

  async listEvents(tenantId: string, filters: AnalyticsEventFilters): Promise<AnalyticsEvent[]> {
    const conditions = ["event.tenant_id=$1"];
    const values: unknown[] = [tenantId];
    let parameter = 2;
    if (filters.cameraId) {
      conditions.push(`event.camera_id=$${parameter++}`);
      values.push(filters.cameraId);
    }
    if (filters.cameraIds?.length) {
      conditions.push(`event.camera_id::text = ANY($${parameter++}::text[])`);
      values.push(filters.cameraIds);
    }
    if (filters.from) {
      conditions.push(`event.occurred_at >= $${parameter++}`);
      values.push(filters.from);
    }
    if (filters.to) {
      conditions.push(`event.occurred_at <= $${parameter++}`);
      values.push(filters.to);
    }
    if (filters.detectionTypes?.length) {
      conditions.push(`event.detection_type = ANY($${parameter++}::text[])`);
      values.push(filters.detectionTypes);
    }
    values.push(filters.limit);
    const result = await this.pool.query(
      `SELECT event.*
       FROM analytics_events event
       JOIN cameras camera ON camera.id = event.camera_id
       WHERE ${activeCamera("camera")} AND ${conditions.join(" AND ")}
       ORDER BY event.occurred_at DESC
       LIMIT $${parameter}`,
      values,
    );
    return result.rows.map((row) => mapEvent(row, []));
  }

  async listAlerts(tenantId: string, filters: AnalyticsAlertFilters): Promise<AnalyticsAlert[]> {
    const resolvedTenantId = await this.resolveTenantUuid(tenantId);
    
    // Build branch filter condition
    let branchCondition = '$3::uuid IS NULL OR camera.branch_node_id=$3';
    const params: any[] = [
      resolvedTenantId, 
      filters.cameraId ?? null, 
      filters.branchId ?? null,
    ];
    let nextParamIndex = 4;
    
    // If branchIds array is provided, use IN clause instead of single branch equality
    if (filters.branchIds && filters.branchIds.length > 0) {
      branchCondition = `camera.branch_node_id = ANY($3::uuid[])`;
      params[2] = filters.branchIds;
    }
    
    const result = await this.pool.query(
      `SELECT 
         alert.*,
         COALESCE(cam_node.name, camera.model, 'Camera') AS camera_name,
         camera.branch_node_id AS branch_id,
         branch.name AS branch_name,
         event.metadata->>'zoneName' AS zone_name,
         COALESCE(
           CASE WHEN parent_node.node_type = 'area' THEN parent_node.name
                WHEN grandparent_node.node_type = 'area' THEN grandparent_node.name
                ELSE NULL END,
           NULL
         ) AS area_name,
         COALESCE(
           CASE WHEN parent_node.node_type = 'region' THEN parent_node.name
                WHEN grandparent_node.node_type = 'region' THEN grandparent_node.name
                ELSE NULL END,
           NULL
         ) AS region_name,
         COALESCE(event.detection_type, alert.object_classes->>0, 'intrusion') AS detection_type,
         inc.incident_number,
         inc.status AS incident_status
       FROM analytics_alerts alert
       JOIN cameras camera ON camera.id=alert.camera_id
       LEFT JOIN analytics_events event ON event.id=alert.event_id
       LEFT JOIN resource_nodes cam_node ON cam_node.id=camera.resource_node_id
       LEFT JOIN resource_nodes branch ON branch.id=camera.branch_node_id
       LEFT JOIN resource_nodes parent_node ON parent_node.id=branch.parent_id
       LEFT JOIN resource_nodes grandparent_node ON grandparent_node.id=parent_node.parent_id
       LEFT JOIN incidents inc ON inc.id=alert.incident_id
       WHERE alert.tenant_id=$1
         AND ${activeCamera("camera")}
         AND ($2::uuid IS NULL OR alert.camera_id=$2)
         AND (${branchCondition})
         AND ($4::text IS NULL OR alert.status=$4)
         AND ($5::text IS NULL OR alert.severity=$5)
         AND ($6::timestamptz IS NULL OR alert.last_detected_at >= $6)
         AND ($7::timestamptz IS NULL OR alert.first_detected_at <= $7)
       AND ($9::uuid[] IS NULL OR alert.camera_id = ANY($9::uuid[]))
       ORDER BY ${filters.priorityFirst ? "CASE WHEN alert.status IN ('resolved','false_alarm','suppressed') THEN 1 ELSE 0 END, alert.severity ASC," : ""} alert.last_detected_at DESC LIMIT $8`,
      [...params, filters.status ?? null, filters.severity ?? null, filters.from ?? null,
        filters.to ?? null, filters.limit, filters.cameraIds ?? null],
    );
    return result.rows.map(mapAlert);
  }

  async countAlerts(tenantId: string, filters: AnalyticsAlertFilters): Promise<Record<AnalyticsAlert["severity"], number>> {
    const resolvedTenantId = await this.resolveTenantUuid(tenantId);
    
    // Build branch filter condition (same logic as listAlerts)
    let branchCondition = '$3::uuid IS NULL OR camera.branch_node_id=$3';
    const params: any[] = [resolvedTenantId, filters.cameraId ?? null, filters.branchId ?? null];
    
    if (filters.branchIds && filters.branchIds.length > 0) {
      branchCondition = `camera.branch_node_id = ANY($3::uuid[])`;
      params[2] = filters.branchIds;
    }
    
    const result = await this.pool.query(
      `SELECT
         COUNT(*) FILTER (WHERE alert.severity='P1' AND alert.status NOT IN ('resolved','false_alarm','suppressed')) AS p1,
         COUNT(*) FILTER (WHERE alert.severity='P2' AND alert.status NOT IN ('resolved','false_alarm','suppressed')) AS p2,
         COUNT(*) FILTER (WHERE alert.severity='P3' AND alert.status NOT IN ('resolved','false_alarm','suppressed')) AS p3,
         COUNT(*) FILTER (WHERE alert.severity='P4' AND alert.status NOT IN ('resolved','false_alarm','suppressed')) AS p4,
         COUNT(*) FILTER (WHERE alert.severity='P5' AND alert.status NOT IN ('resolved','false_alarm','suppressed')) AS p5
       FROM analytics_alerts alert
       JOIN cameras camera ON camera.id=alert.camera_id
       WHERE alert.tenant_id=$1
         AND ${activeCamera("camera")}
         AND ($2::uuid IS NULL OR alert.camera_id=$2)
         AND (${branchCondition})
         AND ($4::timestamptz IS NULL OR alert.last_detected_at >= $4)
         AND ($5::timestamptz IS NULL OR alert.first_detected_at <= $5)
         AND ($6::uuid[] IS NULL OR alert.camera_id = ANY($6::uuid[]))`,
      [...params, filters.from ?? null, filters.to ?? null, filters.cameraIds ?? null],
    );
    const row = result.rows[0] ?? {};
    return {
      P1: Number(row.p1 ?? 0),
      P2: Number(row.p2 ?? 0),
      P3: Number(row.p3 ?? 0),
      P4: Number(row.p4 ?? 0),
      P5: Number(row.p5 ?? 0),
    };
  }

  async getAlertsSummary(
    tenantId: string,
    filters?: { branchId?: string; branchIds?: string[]; cameraId?: string; cameraIds?: string[] },
  ): Promise<AnalyticsAlertsAggregateSummary> {
    const resolvedTenantId = await this.resolveTenantUuid(tenantId);
    
    // Build branch filter condition
    let branchCondition = '$3::uuid IS NULL OR camera.branch_node_id=$3';
    const params: any[] = [resolvedTenantId, filters?.cameraId ?? null, filters?.branchId ?? null];
    
    if (filters?.branchIds && filters.branchIds.length > 0) {
      branchCondition = `camera.branch_node_id = ANY($3::uuid[])`;
      params[2] = filters.branchIds;
    }
    
    const result = await this.pool.query(
      `SELECT
         COUNT(*)::int AS total,
         COUNT(*) FILTER (WHERE alert.status NOT IN ('resolved','false_alarm','suppressed'))::int AS active,
         COUNT(*) FILTER (WHERE alert.incident_id IS NOT NULL)::int AS converted,
         COUNT(*) FILTER (WHERE alert.incident_id IS NULL AND alert.status NOT IN ('resolved','false_alarm','suppressed'))::int AS unconverted,
         COUNT(*) FILTER (WHERE alert.severity IN ('P1', 'P2'))::int AS critical,
         COUNT(*) FILTER (WHERE alert.status = 'false_alarm')::int AS "falseAlarms"
       FROM analytics_alerts alert
       JOIN cameras camera ON camera.id=alert.camera_id
       WHERE alert.tenant_id=$1
         AND ${activeCamera("camera")}
         AND ($2::uuid IS NULL OR alert.camera_id=$2)
         AND (${branchCondition})
         AND ($4::uuid[] IS NULL OR alert.camera_id = ANY($4::uuid[]))`,
      [...params, filters?.cameraIds ?? null],
    );
    const row = result.rows[0] ?? {};
    return {
      total: Number(row.total ?? 0),
      active: Number(row.active ?? 0),
      converted: Number(row.converted ?? 0),
      unconverted: Number(row.unconverted ?? 0),
      critical: Number(row.critical ?? 0),
      falseAlarms: Number(row.falseAlarms ?? 0),
    };
  }

  async updateAlertEvidence(
    id: string,
    tenantId: string,
    input: { snapshotReference?: string; clipReference?: string },
  ): Promise<AnalyticsAlert | undefined> {
    const resolvedTenantId = await this.resolveTenantUuid(tenantId);
    const result = await this.pool.query(
      `UPDATE analytics_alerts
       SET snapshot_reference=COALESCE(snapshot_reference,$3),
           clip_reference=COALESCE(clip_reference,$4),
           version=CASE
             WHEN (snapshot_reference IS NULL AND $3::text IS NOT NULL)
               OR (clip_reference IS NULL AND $4::text IS NOT NULL)
             THEN version+1 ELSE version END,
           updated_at=CASE
             WHEN (snapshot_reference IS NULL AND $3::text IS NOT NULL)
               OR (clip_reference IS NULL AND $4::text IS NOT NULL)
             THEN now() ELSE updated_at END
       WHERE id=$1 AND tenant_id=$2
       RETURNING *`,
      [id, resolvedTenantId, input.snapshotReference ?? null, input.clipReference ?? null],
    );
    return result.rows[0] ? mapAlert(result.rows[0]) : undefined;
  }

  async getAlert(id: string, tenantId: string): Promise<AnalyticsAlert | undefined> {
    const resolvedTenantId = await this.resolveTenantUuid(tenantId);
    const result = await this.pool.query(
      `SELECT 
         alert.*,
         COALESCE(cam_node.name, camera.model, 'Camera') AS camera_name,
         camera.branch_node_id AS branch_id,
         branch.name AS branch_name,
         zone.name AS zone_name,
         COALESCE(
           CASE WHEN parent_node.node_type = 'area' THEN parent_node.name
                WHEN grandparent_node.node_type = 'area' THEN grandparent_node.name
                ELSE NULL END,
           NULL
         ) AS area_name,
         COALESCE(
           CASE WHEN parent_node.node_type = 'region' THEN parent_node.name
                WHEN grandparent_node.node_type = 'region' THEN grandparent_node.name
                ELSE NULL END,
           NULL
         ) AS region_name,
         COALESCE(event.detection_type, alert.object_classes->>0, 'intrusion') AS detection_type,
         inc.incident_number,
         inc.status AS incident_status
       FROM analytics_alerts alert
       JOIN cameras camera ON camera.id=alert.camera_id
       LEFT JOIN analytics_events event ON event.id=alert.event_id
       LEFT JOIN resource_nodes cam_node ON cam_node.id=camera.resource_node_id
       LEFT JOIN resource_nodes branch ON branch.id=camera.branch_node_id
       LEFT JOIN resource_nodes parent_node ON parent_node.id=branch.parent_id
       LEFT JOIN resource_nodes grandparent_node ON grandparent_node.id=parent_node.parent_id
       LEFT JOIN LATERAL (
         SELECT name FROM nbfc_analytics_zones 
         WHERE camera_id = camera.id::text OR branch_id = camera.branch_node_id::text 
         ORDER BY created_at DESC LIMIT 1
       ) zone ON true
       LEFT JOIN incidents inc ON inc.id=alert.incident_id
       WHERE alert.id=$1 AND alert.tenant_id=$2
         AND ${activeCamera("camera")}`,
      [id, resolvedTenantId],
    );
    return result.rows[0] ? mapAlert(result.rows[0]) : undefined;
  }

  async transitionAlert(
    id: string,
    tenantId: string,
    input: AnalyticsAlertTransitionInput,
  ): Promise<AnalyticsAlert | undefined> {
    const client = await this.pool.connect();
    try {
      await client.query("BEGIN");
      const scope = await client.query("SELECT camera_id FROM analytics_alerts WHERE id=$1 AND tenant_id=$2", [id, tenantId]);
      if (scope.rows[0]) {
        await client.query("SELECT pg_advisory_xact_lock(hashtextextended($1, 0))",
          [`analytics-camera:${tenantId}:${scope.rows[0].camera_id}`]);
      }
      const current = await client.query(
        "SELECT * FROM analytics_alerts WHERE id=$1 AND tenant_id=$2 FOR UPDATE",
        [id, tenantId],
      );
      if (!current.rows[0]) {
        await client.query("ROLLBACK");
        return undefined;
      }
      if (isTerminalAlertStatus(current.rows[0].status) &&
          current.rows[0].status !== input.status) {
        throw new Error("invalid_alert_transition");
      }
      if (input.expectedVersion !== undefined && current.rows[0].version !== input.expectedVersion) {
        throw new Error("alert_version_conflict");
      }
      if (input.status === "acknowledged" && current.rows[0].acknowledged_at) {
        throw new Error("alert_already_acknowledged");
      }
      // Older alerts predate the signature column. Use the original evidence
      // displayed to the operator, rather than the last coalesced detection.
      if (input.status === "false_alarm" && !current.rows[0].detection_signature) {
        const original = await client.query("SELECT * FROM analytics_events WHERE id=$1 AND tenant_id=$2", [current.rows[0].event_id, tenantId]);
        if (original.rows[0]) {
          const objects = await client.query("SELECT label, confidence, track_id, bounding_box FROM detected_objects WHERE event_id=$1 AND tenant_id=$2", [current.rows[0].event_id, tenantId]);
          const signature = await buildFalseAlarmSignature(mapEvent(original.rows[0], objects.rows.map((object) => ({
            label: object.label, confidence: Number(object.confidence), trackId: object.track_id ?? undefined,
            boundingBox: json(object.bounding_box, undefined),
          }))));
          await client.query("UPDATE analytics_alerts SET detection_signature=$3 WHERE id=$1 AND tenant_id=$2", [id, tenantId, signature ? JSON.stringify(signature) : null]);
        }
      }
      const updated = await client.query(
        `UPDATE analytics_alerts SET status=$3,
           acknowledged_by=CASE WHEN $3='acknowledged' THEN $4 ELSE acknowledged_by END,
           acknowledged_at=CASE WHEN $3='acknowledged' THEN now() ELSE acknowledged_at END,
           false_alarm_reason=CASE WHEN $3='false_alarm' THEN $5 ELSE false_alarm_reason END,
           resolved_at=CASE WHEN $3 IN ('resolved', 'false_alarm') THEN now() ELSE resolved_at END,
           false_alarm_signature=CASE WHEN $3='false_alarm' THEN detection_signature ELSE false_alarm_signature END,
           assigned_to=COALESCE($6, assigned_to),
           assigned_at=CASE WHEN $6::uuid IS NOT NULL THEN now() ELSE assigned_at END,
           version=version+1,
           updated_at=now()
         WHERE id=$1 AND tenant_id=$2 RETURNING *`,
        [id, tenantId, input.status, input.actorUserId,
          input.falseAlarmReason ?? null, input.assignedTo ?? null],
      );
      if (input.status === "false_alarm") {
        await client.query(
          `UPDATE analytics_notifications SET status='cancelled', updated_at=now()
           WHERE alert_id=$1 AND tenant_id=$2 AND status IN ('queued', 'failed')`,
          [id, tenantId],
        );
      }
      if (input.status === "acknowledged") {
        await client.query(
          `INSERT INTO analytics_acknowledgements
             (id, tenant_id, alert_id, user_id, notes)
           VALUES ($1,$2,$3,$4,$5)`,
          [randomUUID(), tenantId, id, input.actorUserId, input.notes ?? null],
        );
      }
      if (input.status === "escalated") {
        await client.query(
          `INSERT INTO analytics_escalations
             (id, tenant_id, alert_id, escalated_by, recipients, notes)
           VALUES ($1,$2,$3,$4,$5,$6)`,
          [randomUUID(), tenantId, id, input.actorUserId,
            JSON.stringify(input.recipients ?? []), input.notes ?? null],
        );
      }
      await client.query("COMMIT");
      return mapAlert(updated.rows[0]);
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    } finally {
      client.release();
    }
  }

  async linkIncident(id: string, tenantId: string, incidentId: string) {
    const result = await this.pool.query(
      `UPDATE analytics_alerts SET incident_id=$3, updated_at=now()
       WHERE id=$1 AND tenant_id=$2 RETURNING *`,
      [id, tenantId, incidentId],
    );
    return result.rows[0] ? mapAlert(result.rows[0]) : undefined;
  }

  async getNotificationPolicy(tenantId: string): Promise<AlertNotificationPolicy> {
    const result = await this.pool.query("SELECT * FROM alert_notification_policies WHERE tenant_id=$1", [tenantId]);
    if (!result.rows[0]) return defaultNotificationPolicy(tenantId);
    const row = result.rows[0];
    return {
      tenantId,
      recipientGroups: json(row.recipient_groups, {}),
      onCallSchedules: json(row.on_call_schedules, []),
      ...(row.quiet_hours ? { quietHours: json(row.quiet_hours, undefined) } : {}),
      rateLimitPerMinute: row.rate_limit_per_minute,
      escalationAfterSeconds: json(row.escalation_after_seconds, {}),
      smsTemplates: json(row.sms_templates, {}),
      smsTemplateIds: json(row.sms_template_ids, {}),
      updatedAt: iso(row.updated_at),
    };
  }

  async upsertNotificationPolicy(policy: AlertNotificationPolicy): Promise<AlertNotificationPolicy> {
    await this.pool.query(
      `INSERT INTO alert_notification_policies
         (tenant_id, recipient_groups, on_call_schedules, quiet_hours, rate_limit_per_minute, escalation_after_seconds, sms_templates, sms_template_ids)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
       ON CONFLICT (tenant_id) DO UPDATE SET recipient_groups=EXCLUDED.recipient_groups,
         on_call_schedules=EXCLUDED.on_call_schedules, quiet_hours=EXCLUDED.quiet_hours,
         rate_limit_per_minute=EXCLUDED.rate_limit_per_minute,
         escalation_after_seconds=EXCLUDED.escalation_after_seconds, sms_templates=EXCLUDED.sms_templates,
         sms_template_ids=EXCLUDED.sms_template_ids, updated_at=now()`,
      [policy.tenantId, JSON.stringify(policy.recipientGroups), JSON.stringify(policy.onCallSchedules),
        policy.quietHours ? JSON.stringify(policy.quietHours) : null, policy.rateLimitPerMinute,
        JSON.stringify(policy.escalationAfterSeconds), JSON.stringify(policy.smsTemplates ?? {}),
        JSON.stringify(policy.smsTemplateIds ?? {})],
    );
    return this.getNotificationPolicy(policy.tenantId);
  }

  async enqueueNotifications(input: Parameters<import("../control-plane-store.js").ControlPlaneStore["enqueueAlertNotifications"]>[0]) {
    if (input.length === 0) return [];
    const client = await this.pool.connect();
    try {
      await client.query("BEGIN");
      const created: AlertNotification[] = [];
      for (const target of input) {
        const result = await client.query(
          `INSERT INTO analytics_notifications (id, tenant_id, alert_id, channel, recipient, next_attempt_at, voice_call, sms_delivery, email_delivery)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
           ON CONFLICT (alert_id, channel, recipient) DO UPDATE SET alert_id=EXCLUDED.alert_id
           RETURNING *`,
          [randomUUID(), target.tenantId, target.alertId, target.channel, target.recipient,
            target.nextAttemptAt ?? new Date().toISOString(), target.voiceCall ? JSON.stringify(target.voiceCall) : null,
            target.smsDelivery ? JSON.stringify(target.smsDelivery) : null, target.emailDelivery ? JSON.stringify(target.emailDelivery) : null],
        );
        created.push(mapNotification(result.rows[0]));
      }
      await client.query("COMMIT");
      return created;
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    } finally { client.release(); }
  }

  async claimNotifications(limit: number, now: string) {
    const result = await this.pool.query(
      `WITH candidates AS (
         SELECT id FROM analytics_notifications
         WHERE status IN ('queued','failed') AND next_attempt_at <= $1
         ORDER BY next_attempt_at, created_at FOR UPDATE SKIP LOCKED LIMIT $2
       ) UPDATE analytics_notifications notification SET status='processing', attempts=attempts+1, updated_at=now()
         FROM candidates WHERE notification.id=candidates.id RETURNING notification.*`,
      [now, limit],
    );
    return result.rows.map(mapNotification);
  }

  async completeNotification(id: string, result: {
    status: "sent" | "delivered" | "failed" | "dead" | "cancelled"; providerId?: string; error?: string; nextAttemptAt?: string;
  }) {
    const updated = await this.pool.query(
      `UPDATE analytics_notifications SET status=$2, provider_id=COALESCE($3,provider_id),
         last_error=$4, next_attempt_at=COALESCE($5,next_attempt_at),
         sent_at=CASE WHEN $2 IN ('sent','delivered') THEN now() ELSE sent_at END,
         delivered_at=CASE WHEN $2='delivered' THEN now() ELSE delivered_at END, updated_at=now()
       WHERE id=$1 RETURNING *`,
      [id, result.status, result.providerId ?? null, result.error ?? null, result.nextAttemptAt ?? null],
    );
    return updated.rows[0] ? mapNotification(updated.rows[0]) : undefined;
  }

  async recordVoiceCallEvent(id: string, event: Parameters<import("../control-plane-store.js").ControlPlaneStore["recordVoiceCallEvent"]>[1]) {
    const updated = await this.pool.query(
      `UPDATE analytics_notifications SET
         provider_id=COALESCE($3,provider_id),
         voice_call=jsonb_set(jsonb_set(
           COALESCE(voice_call,'{}'::jsonb), '{status}', to_jsonb($2::text), true),
           '{events}', COALESCE(voice_call->'events','[]'::jsonb) || $4::jsonb, true)
           || CASE WHEN $9::text IS NULL THEN '{}'::jsonb ELSE jsonb_build_object('provider',$9::text) END
           || CASE WHEN $5::text IS NULL THEN '{}'::jsonb ELSE jsonb_build_object('acknowledgedAt',$5::text) END
           || CASE WHEN $6::text IS NULL THEN '{}'::jsonb ELSE jsonb_build_object('acknowledgedBy',$6::text) END
           || CASE WHEN $7::text IS NULL THEN '{}'::jsonb ELSE jsonb_build_object('recordingUrl',$7::text) END
           || CASE WHEN $8::integer IS NULL THEN '{}'::jsonb ELSE jsonb_build_object('durationSeconds',$8::integer) END,
         updated_at=now() WHERE id=$1 RETURNING *`,
      [id, event.status, event.providerId ?? null,
        JSON.stringify([{ status: event.status, occurredAt: event.occurredAt, ...(event.detail ? { detail: event.detail } : {}) }]),
        event.acknowledgedAt ?? null, event.acknowledgedBy ?? null, event.recordingUrl ?? null,
        event.durationSeconds ?? null, event.provider ?? null],
    );
    return updated.rows[0] ? mapNotification(updated.rows[0]) : undefined;
  }

  async recordSmsDeliveryEvent(id: string, event: Parameters<import("../control-plane-store.js").ControlPlaneStore["recordSmsDeliveryEvent"]>[1]) {
    const updated = await this.pool.query(
      `UPDATE analytics_notifications SET provider_id=COALESCE($3,provider_id),
         sms_delivery=jsonb_set(jsonb_set(COALESCE(sms_delivery,'{}'::jsonb),
           '{status}',to_jsonb($2::text),true),'{events}',
           COALESCE(sms_delivery->'events','[]'::jsonb) || $4::jsonb,true)
           || CASE WHEN $5::text IS NULL THEN '{}'::jsonb ELSE jsonb_build_object('provider',$5::text) END,
         updated_at=now() WHERE id=$1 RETURNING *`,
      [id, event.status, event.providerId ?? null,
        JSON.stringify([{ status: event.status, occurredAt: event.occurredAt, ...(event.detail ? { detail: event.detail } : {}) }]),
        event.provider ?? null],
    );
    return updated.rows[0] ? mapNotification(updated.rows[0]) : undefined;
  }

  async recordEmailDeliveryEvent(id: string, event: Parameters<import("../control-plane-store.js").ControlPlaneStore["recordEmailDeliveryEvent"]>[1]) {
    const updated = await this.pool.query(
      `UPDATE analytics_notifications SET provider_id=COALESCE($3,provider_id),
         email_delivery=jsonb_set(jsonb_set(COALESCE(email_delivery,'{}'::jsonb),
           '{status}',to_jsonb($2::text),true),'{events}',
           COALESCE(email_delivery->'events','[]'::jsonb) || $4::jsonb,true)
           || CASE WHEN $5::text IS NULL THEN '{}'::jsonb ELSE jsonb_build_object('provider',$5::text) END
           || CASE WHEN $6::text IS NULL THEN '{}'::jsonb ELSE jsonb_build_object('subject',$6::text) END,
         updated_at=now() WHERE id=$1 RETURNING *`,
      [id, event.status, event.providerId ?? null,
        JSON.stringify([{ status: event.status, occurredAt: event.occurredAt, ...(event.detail ? { detail: event.detail } : {}) }]),
        event.provider ?? null, event.subject ?? null],
    );
    return updated.rows[0] ? mapNotification(updated.rows[0]) : undefined;
  }

  async reserveSmsRateLimit(tenantId: string, limit: number, requested: number, now: string) {
    const client = await this.pool.connect();
    try {
      await client.query("BEGIN");
      const windowStart = new Date(new Date(now).setUTCSeconds(0, 0)).toISOString();
      await client.query(
        `INSERT INTO sms_rate_limit_windows (tenant_id, window_start, sent_count) VALUES ($1,$2,0)
         ON CONFLICT (tenant_id,window_start) DO NOTHING`, [tenantId, windowStart]);
      const result = await client.query(
        `WITH current AS (
           SELECT tenant_id,window_start,sent_count FROM sms_rate_limit_windows
           WHERE tenant_id=$1 AND window_start=$2 FOR UPDATE
         ), updated AS (
           UPDATE sms_rate_limit_windows AS limits SET sent_count=LEAST($3, current.sent_count+$4)
           FROM current WHERE limits.tenant_id=current.tenant_id AND limits.window_start=current.window_start
           RETURNING current.sent_count AS before_count, limits.sent_count AS after_count
         ) SELECT after_count-before_count AS allowed FROM updated`,
        [tenantId, windowStart, limit, requested]);
      await client.query("COMMIT");
      return Number(result.rows[0]?.allowed ?? 0);
    } catch (error) {
      await client.query("ROLLBACK"); throw error;
    } finally { client.release(); }
  }

  async listNotifications(tenantId: string, alertId?: string) {
    const result = await this.pool.query(
      `SELECT * FROM analytics_notifications WHERE tenant_id=$1 AND ($2::uuid IS NULL OR alert_id=$2)
       ORDER BY created_at DESC`, [tenantId, alertId ?? null],
    );
    return result.rows.map(mapNotification);
  }

  async listNotificationsByAlertIds(tenantId: string, alertIds: string[]) {
    if (alertIds.length === 0) return [];
    const result = await this.pool.query(
      `SELECT * FROM analytics_notifications WHERE tenant_id=$1 AND alert_id = ANY($2::uuid[]) ORDER BY created_at DESC`,
      [tenantId, alertIds],
    );
    return result.rows.map(mapNotification);
  }
}

async function replaceZone(
  client: PoolClient,
  tenantId: string,
  cameraId: string,
  zone: AnalyticsRuleInput["zone"],
) {
  if (!zone) return null;
  const id = zone.id || randomUUID();
  await client.query(
    `INSERT INTO analytics_zones (id, tenant_id, camera_id, name, shape, points)
     VALUES ($1,$2,$3,$4,$5,$6)`,
    [id, tenantId, cameraId, zone.name, zone.shape, JSON.stringify(zone.points)],
  );
  return id;
}

async function selectRule(
  client: PoolClient,
  id: string,
  tenantId?: string,
  cameraId?: string,
  lock = false,
) {
  const result = await client.query(
    `${ruleSelection} WHERE rule.id=$1
       AND ($2::uuid IS NULL OR rule.tenant_id=$2)
       AND ($3::uuid IS NULL OR rule.camera_id=$3)${lock ? " FOR UPDATE OF rule" : ""}`,
    [id, tenantId ?? null, cameraId ?? null],
  );
  return result.rows[0] ? mapRule(result.rows[0]) : undefined;
}

async function rulesByIds(client: PoolClient, ids: string[]) {
  if (ids.length === 0) return [];
  const result = await client.query(
    `${ruleSelection} WHERE rule.id=ANY($1::uuid[])`,
    [ids],
  );
  return result.rows.map(mapRule);
}

function mapRule(row: any): AnalyticsRule {
  return {
    id: row.id, tenantId: row.tenant_id, cameraId: row.camera_id,
    name: row.name, detectionType: row.detection_type, enabled: row.enabled,
    ...(row.shutter_config ? {shutterConfig:json(row.shutter_config,undefined)} : {}),
    ...(row.zone_join_id ? { zone: {
      id: row.zone_join_id, name: row.zone_name, shape: row.zone_shape,
      points: json(row.zone_points, []),
    } } : {}),
    ...(row.schedule ? { schedule: json(row.schedule, undefined) } : {}),
    objectClasses: json(row.object_classes, []),
    minConfidence: Number(row.min_confidence),
    minDurationSeconds: Number(row.min_duration_seconds),
    direction: row.direction, severity: row.severity,
    cooldownSeconds: row.cooldown_seconds,
    recipients: json(row.recipients, []),
    ...(row.escalate_after_seconds != null
      ? { escalateAfterSeconds: row.escalate_after_seconds } : {}),
    recordingPolicy: row.recording_policy,
    preRollSeconds: row.pre_roll_seconds, postRollSeconds: row.post_roll_seconds,
    ...(row.model_id ? { modelId: row.model_id } : {}),
    ...(row.created_by ? { createdBy: row.created_by } : {}),
    createdAt: iso(row.created_at), updatedAt: iso(row.updated_at),
  };
}

function mapEvent(row: any, objects: AnalyticsEvent["objects"]): AnalyticsEvent {
  return {
    id: row.id, tenantId: row.tenant_id, cameraId: row.camera_id,
    sourceEventId: row.source_event_id,
    ...(row.primary_rule_id ? { ruleId: row.primary_rule_id } : {}),
    detectionType: row.detection_type, occurredAt: iso(row.occurred_at),
    ...(row.ended_at ? { endedAt: iso(row.ended_at) } : {}),
    confidence: Number(row.confidence), durationSeconds: Number(row.duration_seconds),
    modelVersion: row.model_version, objects,
    ...(row.snapshot_reference ? { snapshotReference: row.snapshot_reference } : {}),
    ...(row.clip_reference ? { clipReference: row.clip_reference } : {}),
    metadata: json(row.metadata, {}), status: row.status,
    ...(row.rejection_reason ? { rejectionReason: row.rejection_reason } : {}),
    createdAt: iso(row.created_at),
  };
}

function mapAlert(row: any): AnalyticsAlert {
  return {
    id: row.id, tenantId: row.tenant_id, cameraId: row.camera_id,
    ruleId: row.rule_id, eventId: row.event_id, title: row.title,
    ...(row.description ? { description: row.description } : {}),
    severity: row.severity, status: row.status,
    confidence: Number(row.confidence),
    objectClasses: json(row.object_classes, []), modelVersion: row.model_version,
    ...(row.snapshot_reference ? { snapshotReference: row.snapshot_reference } : {}),
    ...(row.clip_reference ? { clipReference: row.clip_reference } : {}),
    firstDetectedAt: iso(row.first_detected_at),
    lastDetectedAt: iso(row.last_detected_at),
    occurrenceCount: row.occurrence_count,
    ...(row.incident_id ? { incidentId: row.incident_id } : {}),
    ...(row.acknowledged_by ? { acknowledgedBy: row.acknowledged_by } : {}),
    ...(row.acknowledged_at ? { acknowledgedAt: iso(row.acknowledged_at) } : {}),
    ...(row.false_alarm_reason ? { falseAlarmReason: row.false_alarm_reason } : {}),
    ...(row.status === "false_alarm" ? { repeatSuppressionActive: Boolean(row.false_alarm_signature) } : {}),
    ...(row.resolved_at ? { resolvedAt: iso(row.resolved_at) } : {}),
    ...(row.assigned_to ? { assignedTo: row.assigned_to } : {}),
    ...(row.assigned_at ? { assignedAt: iso(row.assigned_at) } : {}),
    ...(row.sla_due_at ? { slaDueAt: iso(row.sla_due_at) } : {}),
    ...(row.correlation_key ? { correlationKey: row.correlation_key } : {}),
    version: Number(row.version ?? 1),
    ...(row.camera_name ? { cameraName: row.camera_name } : {}),
    ...(row.branch_id ? { branchId: row.branch_id } : {}),
    ...(row.branch_name ? { branchName: row.branch_name } : {}),
    ...(row.zone_name ? { zoneName: row.zone_name } : {}),
    ...(row.region_name ? { regionName: row.region_name } : {}),
    ...(row.area_name ? { areaName: row.area_name } : {}),
    ...(row.detection_type ? { detectionType: row.detection_type, alertType: row.detection_type } : {}),
    ...(row.incident_number ? { incidentNumber: row.incident_number } : {}),
    ...(row.incident_status ? { incidentStatus: row.incident_status } : {}),
    snapshotUrl: row.snapshot_reference ?? `/v1/analytics/alerts/${row.id}/snapshot`,
    videoClipUrl: row.clip_reference ?? `/v1/analytics/alerts/${row.id}/clip`,
    createdAt: iso(row.created_at), updatedAt: iso(row.updated_at),
  };
}

function mapNotification(row: any): AlertNotification {
  return {
    id: row.id, tenantId: row.tenant_id, alertId: row.alert_id,
    channel: row.channel, recipient: row.recipient, status: row.status,
    attempts: row.attempts, nextAttemptAt: iso(row.next_attempt_at),
    ...(row.provider_id ? { providerId: row.provider_id } : {}),
    ...(row.last_error ? { lastError: row.last_error } : {}),
    ...(row.sent_at ? { sentAt: iso(row.sent_at) } : {}),
    ...(row.delivered_at ? { deliveredAt: iso(row.delivered_at) } : {}),
    ...(row.voice_call ? { voiceCall: json(row.voice_call, undefined) } : {}),
    ...(row.sms_delivery ? { smsDelivery: json(row.sms_delivery, undefined) } : {}),
    ...(row.email_delivery ? { emailDelivery: json(row.email_delivery, undefined) } : {}),
    createdAt: iso(row.created_at), updatedAt: iso(row.updated_at),
  };
}

function defaultNotificationPolicy(tenantId: string): AlertNotificationPolicy {
  return {
    tenantId, recipientGroups: {}, onCallSchedules: [], rateLimitPerMinute: 120,
    escalationAfterSeconds: { P1: 30, P2: 300, P3: 900 }, updatedAt: new Date(0).toISOString(),
  };
}

function json<T>(value: unknown, fallback: T): T {
  if (value == null) return fallback;
  return (typeof value === "string" ? JSON.parse(value) : value) as T;
}

function iso(value: string | Date) {
  return new Date(value).toISOString();
}
