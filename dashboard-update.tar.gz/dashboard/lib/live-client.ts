import type { LiveSessionResponse } from "@/lib/types";

interface BrowserDirectLiveStart {
  cameraId: string;
  direct: {
    url: string;
    controlPlaneToken: string;
  };
  directFallbacks?: Array<{
    url: string;
    controlPlaneToken: string;
  }>;
}

const LIVE_START_TIMEOUT_MS = 30_000;
const DIRECT_GATEWAY_ATTEMPT_TIMEOUT_MS = 6_000;

export async function startLiveFromBrowser(
  cameraId: string,
  profile: "main" | "sub" = "sub",
  signal: AbortSignal = AbortSignal.timeout(LIVE_START_TIMEOUT_MS),
): Promise<LiveSessionResponse> {
  const authorization = await requestLiveAuthorization(cameraId, profile, "auto", signal);
  if (!isBrowserDirectLiveStart(authorization)) return authorization;

  const direct = await startDirectSession(authorization, signal);
  if (direct) return direct;

  // A private branch address is reachable only from an operator on that
  // branch LAN/VPN. Ask for a new, single-use session before trying the
  // branch's public/named-tunnel route from outside that private network.
  try {
    const publicRoute = await requestLiveAuthorization(cameraId, profile, "public", signal);
    if (!isBrowserDirectLiveStart(publicRoute)) return publicRoute;
    const publicDirect = await startDirectSession(publicRoute, signal);
    if (publicDirect) return publicDirect;
  } catch (error) {
    if (signal.aborted) throw timeoutError(signal.reason ?? error);
    if (error instanceof Error) throw error;
    throw new Error("media_gateway_unavailable");
  }

  throw new Error("media_gateway_unavailable");
}

async function requestLiveAuthorization(
  cameraId: string,
  profile: "main" | "sub",
  routePreference: "auto" | "public",
  signal: AbortSignal,
): Promise<LiveSessionResponse | BrowserDirectLiveStart> {
  const token = typeof window !== "undefined" ? localStorage.getItem("accessToken") : null;
  const headers: Record<string, string> = { "content-type": "application/json" };
  if (token) {
    headers["x-sentinel-session"] = token;
    headers["authorization"] = `Bearer ${token}`;
  }

  let response: Response;
  try {
    response = await fetch("/api/live", {
      method: "POST",
      headers,
      credentials: "include",
      body: JSON.stringify({ cameraId, profile, routePreference }),
      signal,
    });
  } catch (error) {
    throw timeoutError(error);
  }
  const body = await readJson(response);
  if (!response.ok) throw new Error(errorCode(body, "live_session_unavailable"));
  return body as LiveSessionResponse | BrowserDirectLiveStart;
}

async function startDirectSession(
  authorization: BrowserDirectLiveStart,
  signal: AbortSignal,
): Promise<LiveSessionResponse | undefined> {
  const candidates = [authorization.direct, ...(authorization.directFallbacks ?? [])]
    .filter((candidate) => isAllowedGatewayForCurrentPage(candidate.url));

  if (candidates.length === 0) {
    return undefined;
  }

  for (const candidate of candidates) {
    let localResponse: Response;
    try {
      const attemptSignal = AbortSignal.any([
        signal,
        AbortSignal.timeout(DIRECT_GATEWAY_ATTEMPT_TIMEOUT_MS),
      ]);
      localResponse = await fetch(candidate.url, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ controlPlaneToken: candidate.controlPlaneToken }),
        cache: "no-store",
        signal: attemptSignal,
      });
    } catch (error) {
      // A branch-local gateway can be offline or unreachable from the current
      // network. Keep enough of the overall startup budget to try its secure
      // tunnel. Only the caller's deadline/cancellation stops the sequence.
      if (signal.aborted) throw timeoutError(signal.reason ?? error);
      continue;
    }

    const localBody = await readJson(localResponse);
    if (!localResponse.ok) continue;
    return rewriteLiveMediaUrls(localBody as LiveSessionResponse, candidate.url);
  }
  return undefined;
}

function isBrowserDirectLiveStart(value: unknown): value is BrowserDirectLiveStart {
  if (!value || typeof value !== "object") return false;
  const direct = Reflect.get(value, "direct");
  return Boolean(direct && typeof direct === "object" &&
    typeof Reflect.get(direct, "url") === "string" &&
    typeof Reflect.get(direct, "controlPlaneToken") === "string");
}

async function readJson(response: Response): Promise<unknown> {
  return await response.json().catch(() => ({}));
}

function errorCode(value: unknown, fallback: string) {
  if (!value || typeof value !== "object") return fallback;
  const error = Reflect.get(value, "error");
  return typeof error === "string" ? error : fallback;
}

function isAllowedGatewayForCurrentPage(value: string) {
  try {
    const protocol = new URL(value).protocol;
    return typeof window === "undefined" || window.location.protocol !== "https:" || protocol === "https:";
  } catch {
    return false;
  }
}

function rewriteLiveMediaUrls(session: LiveSessionResponse, gatewayUrl: string): LiveSessionResponse {
  let gateway: URL;
  try { gateway = new URL(gatewayUrl); } catch { return session; }
  if (gateway.protocol !== "https:") return session;

  const rewrite = (value: string) => {
    try {
      const source = new URL(value);
      if (source.protocol !== "http:") return value;
      return new URL(`${source.pathname}${source.search}`, gateway).toString();
    } catch {
      return value;
    }
  };

  return {
    ...session,
    ...(session.hls ? { hls: { ...session.hls, url: rewrite(session.hls.url) } } : {}),
    ...(session.webRtc ? { webRtc: { ...session.webRtc, whepUrl: rewrite(session.webRtc.whepUrl) } } : {}),
  };
}

function timeoutError(error: unknown) {
  return error instanceof DOMException && error.name === "TimeoutError"
    ? new Error("live_session_timeout")
    : error;
}
