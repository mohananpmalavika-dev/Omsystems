/**
 * Viewer Capacity Manager
 * 
 * Detects browser capabilities, measures decoder capacity,
 * and provides runtime resource budgets for video playback.
 */

import type {
  ViewerCapacity,
  ViewerResourceBudget,
  HardwareAccelerationState,
  VideoCodec,
  CapacityBenchmarkResult,
  PlaybackMetrics,
} from "./types";
import {
  detectSupportedCodecs,
  selectPreferredCodec,
} from "./stream-utils";

// ============================================================================
// CONFIGURATION
// ============================================================================

const DEFAULT_DECODER_LIMIT = 144; // Conservative starting point
const MIN_DECODER_LIMIT = 8;
const MAX_DECODER_LIMIT = 144;
const CAPACITY_SAFETY_MARGIN = 1.0; // Use 85% of measured capacity
const EMERGENCY_RESERVE_RATIO = 0.0; // Allow 100% of decoder capacity for normal wall viewing

// Default budgets (can be overridden by detection)
const DEFAULT_BITRATE_BUDGET_MBPS = 300;
const DEFAULT_PIXEL_BUDGET = 2_000_000_000; // 2 billion pixels/sec

// Adaptive capacity thresholds
const OVERLOAD_THRESHOLD = 0.05; // 5% dropped frames = overload
const OVERLOAD_DURATION_MS = 5000; // Must be overloaded for 5s
const HEALTHY_DURATION_MS = 30000; // Must be healthy for 30s before increase

// ============================================================================
// VIEWER CAPACITY MANAGER
// ============================================================================

export class ViewerCapacityManager {
  private capacity: ViewerCapacity | null = null;
  private overloadStartTime: number | null = null;
  private healthyStartTime: number | null = null;
  private lastAdjustmentTime: number = 0;

  /**
   * Initialize and detect viewer capacity
   */
  async initialize(): Promise<ViewerCapacity> {
    console.log("[ViewerCapacity] Initializing...");

    const codecs = await detectSupportedCodecs();
    const hardwareAcceleration = await this.detectHardwareAcceleration();
    const baseline = await this.runDecoderBenchmark(codecs, hardwareAcceleration);

    this.capacity = {
      maxVideoDecoders: baseline.maxVideoDecoders,
      maxAggregateBitrateMbps: baseline.maxAggregateBitrateMbps,
      maxPixelsPerSecond: baseline.maxPixelsPerSecond,
      activeDecoders: 0,
      activeBitrateMbps: 0,
      activePixelsPerSecond: 0,
      supportedCodecs: codecs,
      preferredCodec: selectPreferredCodec(codecs, hardwareAcceleration),
      hardwareAcceleration,
      recommendedDecoderLimit: baseline.recommendedDecoderLimit,
      measuredAt: new Date().toISOString(),
    };

    console.log("[ViewerCapacity] Initialized:", {
      decoders: this.capacity.recommendedDecoderLimit,
      codecs: this.capacity.supportedCodecs,
      hwAccel: this.capacity.hardwareAcceleration,
    });

    return this.capacity;
  }

  /**
   * Get current capacity (initialize if needed)
   */
  async getCapacity(): Promise<ViewerCapacity> {
    if (!this.capacity) {
      return await this.initialize();
    }
    return this.capacity;
  }

  /**
   * Get current resource budget
   */
  async getResourceBudget(maxDecoderLimit?: number): Promise<ViewerResourceBudget> {
    const capacity = await this.getCapacity();
    
    const total = Math.min(capacity.recommendedDecoderLimit, this.getDecoderCeiling(maxDecoderLimit));
    const emergencyReserve = total > 1
      ? Math.min(total - 1, Math.max(1, Math.round(total * EMERGENCY_RESERVE_RATIO)))
      : 0;
    const normal = total - emergencyReserve;

    return {
      decoderBudget: total,
      bitrateBudgetMbps: capacity.maxAggregateBitrateMbps,
      pixelsPerSecondBudget: capacity.maxPixelsPerSecond,
      decoderUsage: capacity.activeDecoders,
      bitrateUsageMbps: capacity.activeBitrateMbps,
      pixelsPerSecondUsage: capacity.activePixelsPerSecond,
      emergencyReserve,
      normalPoolSize: normal,
    };
  }

  /**
   * Update active resource usage
   */
  updateUsage(
    decoders: number,
    bitrateMbps: number,
    pixelsPerSecond: number
  ): void {
    if (this.capacity) {
      this.capacity.activeDecoders = decoders;
      this.capacity.activeBitrateMbps = bitrateMbps;
      this.capacity.activePixelsPerSecond = pixelsPerSecond;
    }
  }

  /**
   * Monitor playback metrics and adapt capacity
   */
  async monitorPerformance(
    metrics: Map<string, PlaybackMetrics>,
    maxDecoderLimit?: number,
  ): Promise<boolean> {
    if (!this.capacity) {
      return false;
    }

    const now = Date.now();
    let totalDroppedRatio = 0;
    let cameraCount = 0;

    // Calculate average dropped frame ratio
    for (const metric of metrics.values()) {
      if (!Number.isFinite(metric.droppedFrameRatio) ||
          metric.droppedFrameRatio < 0 || metric.droppedFrameRatio > 1) continue;
      totalDroppedRatio += metric.droppedFrameRatio;
      cameraCount++;
    }

    // No playing samples are not evidence of either overload or recovery.
    if (cameraCount === 0 || this.capacity.activeDecoders === 0) {
      this.overloadStartTime = null;
      this.healthyStartTime = null;
      return false;
    }
    const avgDroppedRatio = totalDroppedRatio / cameraCount;

    // Detect overload
    if (avgDroppedRatio > OVERLOAD_THRESHOLD) {
      this.healthyStartTime = null;
      if (this.overloadStartTime === null) {
        this.overloadStartTime = now;
      }

      // Sustained overload - decrease capacity
      if (now - this.overloadStartTime > OVERLOAD_DURATION_MS) {
        const changed = this.decreaseCapacity(maxDecoderLimit, avgDroppedRatio);
        this.overloadStartTime = null;
        this.healthyStartTime = null;
        return changed;
      }
    } else {
      // Reset overload timer
      this.overloadStartTime = null;

      // Track healthy duration
      if (this.healthyStartTime === null) {
        this.healthyStartTime = now;
      }

      // Sustained healthy state - consider increasing capacity
      if (
        now - this.healthyStartTime > HEALTHY_DURATION_MS &&
        now - this.lastAdjustmentTime > HEALTHY_DURATION_MS
      ) {
        const changed = this.increaseCapacity(maxDecoderLimit);
        this.healthyStartTime = null;
        return changed;
      }
    }

    return false;
  }

  /**
   * Decrease decoder capacity due to performance issues
   */
  private decreaseCapacity(maxDecoderLimit?: number, droppedFrameRatio?: number): boolean {
    if (!this.capacity) return false;

    if (this.capacity.activeDecoders <= 1) return false;

    const ceiling = this.getDecoderCeiling(maxDecoderLimit);
    // Never degrade below the active wall ceiling (e.g. 12, 16, 36, 144)
    const minFloor = ceiling >= 8 ? ceiling : 2;
    const current = Math.min(
      this.capacity.recommendedDecoderLimit,
      ceiling,
      Math.max(this.capacity.activeDecoders, minFloor),
    );
    if (current <= minFloor) return false;
    const decrease = Math.ceil(current * 0.15); // Decrease by 15%
    const newLimit = Math.max(minFloor, current - decrease);

    console.warn(`[ViewerCapacity] Playback overload: decreasing from ${current} to ${newLimit}`, {
      droppedFrameRatio,
      activeDecoders: this.capacity.activeDecoders,
    });

    this.capacity.recommendedDecoderLimit = newLimit;
    this.lastAdjustmentTime = Date.now();
    return true;
  }

  /**
   * Increase decoder capacity when performance is good
   */
  private increaseCapacity(maxDecoderLimit?: number): boolean {
    if (!this.capacity) return false;

    const current = this.capacity.recommendedDecoderLimit;
    
    // Don't exceed hard limit
    const ceiling = this.getDecoderCeiling(maxDecoderLimit);
    if (current >= ceiling) {
      return false;
    }

    const increase = Math.min(2, Math.ceil(current * 0.1)); // Increase by 10% or 2
    const newLimit = Math.min(ceiling, current + increase);

    console.log(`[ViewerCapacity] Increasing from ${current} to ${newLimit}`);

    this.capacity.recommendedDecoderLimit = newLimit;
    this.lastAdjustmentTime = Date.now();
    return true;
  }

  private getDecoderCeiling(maxDecoderLimit?: number): number {
    const configuredLimit = typeof maxDecoderLimit === "number" && Number.isFinite(maxDecoderLimit)
      ? Math.max(1, Math.floor(maxDecoderLimit))
      : MAX_DECODER_LIMIT;
    return Math.min(MAX_DECODER_LIMIT, this.capacity?.maxVideoDecoders ?? MAX_DECODER_LIMIT, configuredLimit);
  }

  // ==========================================================================
  // HARDWARE DETECTION
  // ==========================================================================

  /**
   * Detect hardware acceleration support
   */
  private async detectHardwareAcceleration(): Promise<HardwareAccelerationState> {
    if (typeof window === "undefined") {
      return "UNKNOWN";
    }

    try {
      // Check for GPU availability
      const canvas = document.createElement("canvas");
      const gl = canvas.getContext("webgl2") || canvas.getContext("webgl");
      
      if (!gl) {
        return "UNAVAILABLE";
      }

      // Check WebCodecs API (modern HW acceleration)
      if ("VideoDecoder" in window) {
        try {
          const config = {
            codec: "avc1.42E01E", // H.264 Baseline
            codedWidth: 1920,
            codedHeight: 1080,
          };

          // @ts-ignore - VideoDecoder is experimental
          const support = await VideoDecoder.isConfigSupported(config);
          
          if (support?.supported) {
            return "AVAILABLE";
          }
        } catch (e) {
          console.warn("[ViewerCapacity] VideoDecoder check failed:", e);
        }
      }

      // Check GPU info
      const debugInfo = gl.getExtension("WEBGL_debug_renderer_info");
      if (debugInfo) {
        const renderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
        
        // Intel integrated graphics have limited HW decode
        if (renderer?.toLowerCase().includes("intel")) {
          return "AVAILABLE"; // But capacity will be lower
        }
        
        // Dedicated GPU likely has good HW decode
        if (
          renderer?.toLowerCase().includes("nvidia") ||
          renderer?.toLowerCase().includes("amd") ||
          renderer?.toLowerCase().includes("radeon")
        ) {
          return "AVAILABLE";
        }
      }

      return "UNKNOWN";
    } catch (error) {
      console.warn("[ViewerCapacity] HW detection error:", error);
      return "UNKNOWN";
    }
  }

  /**
   * Run decoder capacity benchmark
   */
  private async runDecoderBenchmark(
    codecs: VideoCodec[],
    hardwareAcceleration: HardwareAccelerationState
  ): Promise<CapacityBenchmarkResult> {
    const startTime = Date.now();

    // Estimate based on hardware capabilities
    let estimatedCapacity = DEFAULT_DECODER_LIMIT;
    let bitrateCapacity = DEFAULT_BITRATE_BUDGET_MBPS;
    let pixelCapacity = DEFAULT_PIXEL_BUDGET;

    // Adjust based on hardware acceleration
    if (hardwareAcceleration === "AVAILABLE") {
      estimatedCapacity = 144;
      bitrateCapacity = 300;
      pixelCapacity = 2_000_000_000;
    } else if (hardwareAcceleration === "UNAVAILABLE") {
      estimatedCapacity = 144;
      bitrateCapacity = 15;
      pixelCapacity = 200_000_000;
    }

    // Check available memory - only boost when memory is plentiful, do not clamp below 144
    const memory = (performance as Performance & {
      memory?: { jsHeapSizeLimit: number };
    }).memory;
    if (memory) {
      const availableGB = memory.jsHeapSizeLimit / (1024 * 1024 * 1024);
      if (availableGB > 4) {
        estimatedCapacity = Math.min(estimatedCapacity + 8, MAX_DECODER_LIMIT);
      }
    }

    // Check CPU cores (if available) - do not clamp below 144
    if (typeof navigator !== "undefined" && "hardwareConcurrency" in navigator) {
      const cores = navigator.hardwareConcurrency || 4;
      if (cores >= 8) {
        estimatedCapacity = Math.min(estimatedCapacity + 4, MAX_DECODER_LIMIT);
      }
    }

    // Apply safety margin
    const recommendedLimit = Math.floor(estimatedCapacity * CAPACITY_SAFETY_MARGIN);

    const benchmarkDurationMs = Date.now() - startTime;

    return {
      maxVideoDecoders: 144,
      maxAggregateBitrateMbps: bitrateCapacity,
      maxPixelsPerSecond: pixelCapacity,
      recommendedDecoderLimit: 144,
      benchmarkDurationMs,
    };
  }

  /**
   * Reset capacity to initial state
   */
  async reset(): Promise<ViewerCapacity> {
    console.log("[ViewerCapacity] Resetting...");
    this.capacity = null;
    this.overloadStartTime = null;
    this.healthyStartTime = null;
    this.lastAdjustmentTime = 0;
    return await this.initialize();
  }
}

// ============================================================================
// SINGLETON INSTANCE
// ============================================================================

let instance: ViewerCapacityManager | null = null;

export function getViewerCapacityManager(): ViewerCapacityManager {
  if (!instance) {
    instance = new ViewerCapacityManager();
  }
  return instance;
}

export function resetViewerCapacityManager(): void {
  instance = null;
}
