import { createHash, randomBytes, randomUUID } from "node:crypto";
import { isFreshEdgeAgent } from "./edge-agent/presence.js";
import type { ProvisioningStageId } from "./provisioning/stages.js";
import type {
  AccessGrant,
  Action,
  AnalyticsAlert,
  AnalyticsEvent,
  AnalyticsRule,
  AlertNotification,
  AlertNotificationPolicy,
  AuditEventInput,
  Camera,
  CameraStatus,
  MaintenanceAsset,
  WorkOrder,
  MaintenanceVendor,
  AmcContract,
  ComplianceAssessment,
  ComplianceCertificate,
  ComplianceFramework,
  CompliancePolicy,
  DiscoveredCamera,
  DeviceIdentity,
  EdgeActivation,
  EdgeAgent,
  EdgeManagedTunnel,
  BranchConnectivityProfile,
  EdgeCommand,
  EdgeUpdateRelease,
  EdgeScanJob,
  LiveBookmark,
  LiveIncident,
  LiveSession,
  ConsumedLiveSession,
  RecordingJob,
  RecordingHealthEvent,
  RecordingLegalHold,
  RecordingSegment,
  RecordingStorageNode,
  ResourceNode,
  User,
} from "./domain/models.js";
import { authorize } from "./domain/authorization.js";
import {
  analyticsAlertTitle,
  isTerminalAlertStatus,
  sortedMatchingRules,
} from "./analytics/rule-engine.js";
import { moreSevere, resolveAlertSeverity } from "./analytics/severity-policy.js";
import type {
  CameraApprovalInput,
  CameraDiscoveryInput,
  ControlPlaneStore,
  MaintenanceAssetInput,
  WorkOrderInput,
  MaintenanceVendorInput,
  AmcContractInput,
  ComplianceAssessmentFilters,
  DeviceInventoryInput,
  DeviceInventoryRecord,
  RecorderReplacementResult,
} from "./control-plane-store.js";
import type {
  RecorderDeviceProfile,
  IdentityEvidence,
  ApiFamilyEvidence,
  CompatibilityCatalogEntry,
} from "./types/recorder-profile.types.js";
import { IncidentManagementMethods } from "./store-incident-extensions.js";
import type { OperationalHealthPolicy, OperationalTelemetryEnvelope, VideoWallGridSize, VideoWallLayout } from "./operational-health/types.js";
import type {
  OperationalReportSchedule, OperationalReportRun, OperationalReportArtifact,
  OperationalReportDelivery,
} from "./reporting/types.js";
import {
  identityClaims,
  normalizeMacAddress,
  observationFromApproval,
  observationFromDiscovery,
  type DeviceIdentityObservation,
} from "./device-identity.js";

function correlationCount(metadata?: Record<string, unknown>) {
  const explicit = metadata?.correlatedDetectionCount;
  if (typeof explicit === "number" && Number.isFinite(explicit)) return Math.max(0, Math.floor(explicit));
  return Array.isArray(metadata?.correlatedDetectionTypes) ? metadata.correlatedDetectionTypes.length : 0;
}

function clean<T extends Record<string, any>>(obj: T) {
  return Object.fromEntries(Object.entries(obj).filter(([, v]) => v !== undefined)) as Partial<T>;
}

function rolloutBucket(agentId: string, version: string) {
  let hash = 2166136261;
  for (const char of `${agentId}:${version}`) hash = Math.imul(hash ^ char.charCodeAt(0), 16777619);
  return (hash >>> 0) % 100;
}

function defaultAlertNotificationPolicy(inputTenantId: string): AlertNotificationPolicy {
  return {
    tenantId: inputTenantId,
    recipientGroups: {},
    onCallSchedules: [],
    rateLimitPerMinute: 120,
    escalationAfterSeconds: { P1: 30, P2: 300, P3: 900 },
    smsTemplates: {},
    smsTemplateIds: {},
    updatedAt: new Date(0).toISOString(),
  };
}

const tenantId = "omsystems";

const seedNodes: ResourceNode[] = [
  // Enterprise Root & Hierarchy
  { id: "company-1", parentId: null, tenantId, type: "company", name: "Sentinel Grid - National Commercial Banking Network", path: ["company-1"] },
  { id: "division-retail", parentId: "company-1", tenantId, type: "division", name: "Retail & Commercial Banking Division", path: ["company-1", "division-retail"] },
  { id: "division-vault", parentId: "company-1", tenantId, type: "division", name: "Currency Chests & Vault Operations", path: ["company-1", "division-vault"] },
  
  // Geographical Regions
  { id: "region-south", parentId: "division-retail", tenantId, type: "region", name: "South Zone (Kerala, Karnataka, Tamil Nadu)", path: ["company-1", "division-retail", "region-south"] },
  { id: "region-west", parentId: "division-retail", tenantId, type: "region", name: "West Zone (Maharashtra, Gujarat, Goa)", path: ["company-1", "division-retail", "region-west"] },
  { id: "region-north", parentId: "division-retail", tenantId, type: "region", name: "North Zone (Delhi NCR, Punjab, UP)", path: ["company-1", "division-retail", "region-north"] },
  { id: "region-east", parentId: "division-retail", tenantId, type: "region", name: "East Zone (West Bengal, Odisha, Assam)", path: ["company-1", "division-retail", "region-east"] },

  // Flagship Branches
  { id: "A005", parentId: "region-south", tenantId, type: "branch", name: "Branch A005 - Adithi Malavika Commercial Hub (Kochi Marine Drive)", path: ["company-1", "division-retail", "region-south", "A005"] },
  { id: "A006", parentId: "region-west", tenantId, type: "branch", name: "Branch A006 - Mumbai BKC Financial Center (Bandra Kurla Complex)", path: ["company-1", "division-retail", "region-west", "A006"] },
  { id: "A007", parentId: "region-north", tenantId, type: "branch", name: "Branch A007 - Delhi Connaught Place Main Branch (CP Inner Circle)", path: ["company-1", "division-retail", "region-north", "A007"] },
  { id: "A008", parentId: "region-south", tenantId, type: "branch", name: "Branch A008 - Bengaluru Whitefield Tech Hub (ITPL Main Road)", path: ["company-1", "division-retail", "region-south", "A008"] },
  { id: "A009", parentId: "region-south", tenantId, type: "branch", name: "Branch A009 - Hyderabad Hitec City Flagship (Cyber Towers Road)", path: ["company-1", "division-retail", "region-south", "A009"] },
  { id: "A010", parentId: "region-south", tenantId, type: "branch", name: "Branch A010 - Chennai Anna Salai Commercial Center (Mount Road)", path: ["company-1", "division-retail", "region-south", "A010"] },
  { id: "A011", parentId: "region-east", tenantId, type: "branch", name: "Branch A011 - Kolkata Park Street Regional Branch (Park Street)", path: ["company-1", "division-retail", "region-east", "A011"] },
  { id: "A012", parentId: "region-west", tenantId, type: "branch", name: "Branch A012 - Pune FC Road Commercial Branch (Shivajinagar)", path: ["company-1", "division-retail", "region-west", "A012"] },
  { id: "A013", parentId: "region-west", tenantId, type: "branch", name: "Branch A013 - Ahmedabad SG Highway Corporate Center (Bodakdev)", path: ["company-1", "division-retail", "region-west", "A013"] },
  { id: "branch-blr-001", parentId: "region-south", tenantId, type: "branch", name: "Branch BLR-001 - Bengaluru MG Road Treasury Branch (MG Road)", path: ["company-1", "division-retail", "region-south", "branch-blr-001"] },

  // Camera Groups for A005 (Kochi)
  { id: "group-a005-public", parentId: "A005", tenantId, type: "camera-group", name: "Public Banking Hall & Reception", path: ["company-1", "division-retail", "region-south", "A005", "group-a005-public"] },
  { id: "group-a005-tellers", parentId: "A005", tenantId, type: "camera-group", name: "Cash Tellers & Customer Counters", path: ["company-1", "division-retail", "region-south", "A005", "group-a005-tellers"] },
  { id: "group-a005-vault", parentId: "A005", tenantId, type: "camera-group", name: "Currency Chest & Strong Room Vault", path: ["company-1", "division-retail", "region-south", "A005", "group-a005-vault"] },
  { id: "group-a005-perimeter", parentId: "A005", tenantId, type: "camera-group", name: "ATM Lobby & Outer Perimeter ANPR", path: ["company-1", "division-retail", "region-south", "A005", "group-a005-perimeter"] },

  // Camera Groups for A006 (Mumbai BKC)
  { id: "group-a006-public", parentId: "A006", tenantId, type: "camera-group", name: "Main Banking Hall & VIP Lounge", path: ["company-1", "division-retail", "region-west", "A006", "group-a006-public"] },
  { id: "group-a006-vault", parentId: "A006", tenantId, type: "camera-group", name: "Forex & Bullion Vault Air-Lock", path: ["company-1", "division-retail", "region-west", "A006", "group-a006-vault"] },

  // Compatibility test nodes
  { id: "camera-entrance", parentId: "A005", tenantId, type: "camera-group", name: "Main Entrance", path: ["company-1", "division-retail", "region-south", "A005", "camera-entrance"] },
  { id: "camera-cash-room", parentId: "A005", tenantId, type: "camera-group", name: "Cash Room", isSensitive: true, path: ["company-1", "division-retail", "region-south", "A005", "camera-cash-room"] },
];

const seedUsers: User[] = [
  {
    id: "user-superadmin-mgdhanyamohan",
    displayName: "Dhanya Mohan (Superadmin)",
    username: "mgdhanyamohan",
    email: "mgdhanyamohan@omsystems.bank",
    role: "super_admin",
    status: "active",
    tenantId,
  },
  { id: "user-global-admin", displayName: "Global Surveillance Director", tenantId },
  { id: "user-south-operator", displayName: "South Zone Lead Operator (Kochi SOC)", tenantId },
  { id: "user-west-operator", displayName: "West Zone Lead Operator (Mumbai SOC)", tenantId },
  { id: "user-branch-manager", displayName: "Adithi Malavika Hub Manager", tenantId },
  { id: "user-investigator", displayName: "Chief Forensic Investigator", tenantId },
  { id: "user-evidence-officer", displayName: "Statutory Evidence & Compliance Officer", tenantId },
];

const operatorActions: Action[] = [
  "live:view", "audio:talk", "recording:view", "alarm:acknowledge",
  "analytics:view", "alerts:acknowledge",
  "incident:view", "incident:create",
];

const investigatorActions: Action[] = [
  "live:view", "recording:view",
  "incident:view", "incident:create", "incident:update", "incident:assign",
  "investigation:view", "investigation:manage",
  "evidence:view", "evidence:create", "evidence:preserve",
  "alerts:acknowledge",
];

const evidenceOfficerActions: Action[] = [
  "incident:view",
  "investigation:view",
  "evidence:view", "evidence:create", "evidence:preserve", "evidence:export-package", "evidence:approve",
  "evidence:legal-hold", "evidence:release-hold",
  "police:update", "insurance:update",
];

const seedGrants: AccessGrant[] = [
  // Permanent Superadmin has full access across entire network
  {
    userId: "user-superadmin-mgdhanyamohan",
    scopeNodeId: "company-1",
    actions: [
      "live:view", "audio:talk", "recording:view", "evidence:export", "ptz:operate", "alarm:acknowledge",
      "device:configure", "user:manage", "audit:view", "org:manage",
      "analytics:view", "analytics:configure", "alerts:acknowledge", "alerts:escalate", "analytics:export",
      "incident:create", "incident:view", "incident:update", "incident:assign", "incident:escalate", "incident:close", "incident:reopen",
      "investigation:view", "investigation:manage", "investigation:enhance",
      "evidence:create", "evidence:view", "evidence:preserve", "evidence:export-package", "evidence:approve", "evidence:share",
      "evidence:legal-hold", "evidence:release-hold",
      "police:update", "insurance:update", "incident-report:approve",
      "face:view", "face:enrol", "face:manage-watchlist",
      "anpr:view", "anpr:search", "anpr:manage-watchlist",
      "behavior:view",
    ],
    effect: "allow",
  },
  // Global admin full access
  { 
    userId: "user-global-admin", 
    scopeNodeId: "company-1", 
    actions: [
      "live:view", "audio:talk", "recording:view", "evidence:export", "ptz:operate", "alarm:acknowledge",
      "device:configure", "user:manage", "audit:view", "org:manage", 
      "analytics:view", "analytics:configure", "alerts:acknowledge", "alerts:escalate", "analytics:export",
      "incident:create", "incident:view", "incident:update", "incident:assign", "incident:escalate", "incident:close", "incident:reopen",
      "investigation:view", "investigation:manage", "investigation:enhance",
      "evidence:create", "evidence:view", "evidence:preserve", "evidence:export-package", "evidence:approve", "evidence:share",
      "evidence:legal-hold", "evidence:release-hold",
      "police:update", "insurance:update", "incident-report:approve",
    ], 
    effect: "allow" 
  },
  
  // Regional Operators
  { userId: "user-south-operator", scopeNodeId: "region-south", actions: operatorActions, effect: "allow" },
  { userId: "user-west-operator", scopeNodeId: "region-west", actions: operatorActions, effect: "allow" },
  
  // Branch manager
  { 
    userId: "user-branch-manager", 
    scopeNodeId: "A005", 
    actions: [
      "live:view", "audio:talk", "recording:view",
      "analytics:view", "analytics:configure", "alerts:acknowledge", "alerts:escalate", "analytics:export",
      "incident:view", "incident:create", "incident:update", "incident:assign", "incident:escalate",
      "investigation:view",
      "evidence:view",
      "police:update", "insurance:update",
    ], 
    effect: "allow" 
  },
  
  // Investigator
  { userId: "user-investigator", scopeNodeId: "company-1", actions: investigatorActions, effect: "allow" },
  
  // Evidence Officer
  { userId: "user-evidence-officer", scopeNodeId: "company-1", actions: evidenceOfficerActions, effect: "allow" },
  
  // Explicit deny for testing hierarchy override
  { userId: "user-branch-manager", scopeNodeId: "camera-cash-room", actions: ["live:view"], effect: "deny" },
];

const seedCameras: Camera[] = [
  // Compatibility test camera
  {
    id: "cam-001",
    deviceIdentityId: "device-001",
    nodeId: "camera-entrance",
    branchId: "A005",
    name: "Main Entrance Camera",
    vendor: "hikvision",
    model: "DS-2CD2143G0-I",
    status: "online",
    channel: 1,
    protocol: "onvif-t",
    profiles: [
      { name: "main", codec: "H264", width: 1920, height: 1080, role: "main" },
      { name: "sub", codec: "H264", width: 640, height: 360, role: "sub" },
    ],
    capabilities: { ptz: false, audio: true, events: true },
    connectionSecretRef: "secret://cam-001",
  },
  // ==========================================
  // BRANCH A005 (Kochi Marine Drive Flagship)
  // ==========================================
  {
    id: "cam-a005-01",
    deviceIdentityId: "device-a005-01",
    nodeId: "group-a005-tellers",
    branchId: "A005",
    name: "Teller Counter 1 (Cash Ingest)",
    vendor: "dahua",
    model: "IPC-HFW5442E-ZE (4K WizMind AI Bullet)",
    serialNumber: "DH-8K29348123A",
    macAddress: "3C:EF:8C:1A:40:91",
    ipAddress: "192.168.1.101",
    onvifPort: 80,
    rtspPort: 554,
    channel: 1,
    protocol: "onvif-t",
    status: "online",
    profiles: [
      { name: "main", codec: "H265", width: 3840, height: 2160, role: "main" },
      { name: "sub", codec: "H264", width: 704, height: 576, role: "sub" }
    ],
    capabilities: { ptz: false, audio: true, events: true },
    connectionSecretRef: "vault://branches/A005/cameras/01",
  },
  {
    id: "cam-a005-02",
    deviceIdentityId: "device-a005-02",
    nodeId: "group-a005-tellers",
    branchId: "A005",
    name: "Teller Counter 2 (Cash Dispense)",
    vendor: "dahua",
    model: "IPC-HFW5442E-ZE (4K WizMind AI Bullet)",
    serialNumber: "DH-8K29348124B",
    macAddress: "3C:EF:8C:1A:40:92",
    ipAddress: "192.168.1.102",
    onvifPort: 80,
    rtspPort: 554,
    channel: 2,
    protocol: "onvif-t",
    status: "online",
    profiles: [
      { name: "main", codec: "H265", width: 3840, height: 2160, role: "main" },
      { name: "sub", codec: "H264", width: 704, height: 576, role: "sub" }
    ],
    capabilities: { ptz: false, audio: true, events: true },
    connectionSecretRef: "vault://branches/A005/cameras/02",
  },
  {
    id: "cam-a005-03",
    deviceIdentityId: "device-a005-03",
    nodeId: "group-a005-vault",
    branchId: "A005",
    name: "Strong Room Dual-Custody Vault Door",
    vendor: "hikvision",
    model: "DS-2CD2386G2-ISU/SL (4K AcuSense Strobe/Audio Eyeball)",
    serialNumber: "HK-VR99201948",
    macAddress: "E0:53:5A:22:98:C1",
    ipAddress: "192.168.1.103",
    onvifPort: 80,
    rtspPort: 554,
    channel: 1,
    protocol: "onvif-t",
    status: "online",
    profiles: [
      { name: "main", codec: "H265", width: 3840, height: 2160, role: "main" },
      { name: "sub", codec: "H264", width: 640, height: 360, role: "sub" }
    ],
    capabilities: { ptz: false, audio: true, events: true },
    connectionSecretRef: "vault://branches/A005/cameras/03",
  },
  {
    id: "cam-a005-04",
    deviceIdentityId: "device-a005-04",
    nodeId: "group-a005-perimeter",
    branchId: "A005",
    name: "24/7 ATM Lobby & Card Dispenser",
    vendor: "cp-plus",
    model: "CP-UNC-TA41ZL4-VMD (4MP WDR IR Dome)",
    serialNumber: "CP-ATM772091A",
    macAddress: "48:5D:36:11:BC:04",
    ipAddress: "192.168.1.104",
    onvifPort: 80,
    rtspPort: 554,
    channel: 1,
    protocol: "onvif-s",
    status: "online",
    profiles: [
      { name: "main", codec: "H264", width: 2560, height: 1440, role: "main" },
      { name: "sub", codec: "H264", width: 704, height: 576, role: "sub" }
    ],
    capabilities: { ptz: false, audio: true, events: true },
    connectionSecretRef: "vault://branches/A005/cameras/04",
  },
  {
    id: "cam-a005-05",
    deviceIdentityId: "device-a005-05",
    nodeId: "group-a005-public",
    branchId: "A005",
    name: "Main Banking Hall 360 Overview",
    vendor: "axis",
    model: "AXIS M3066-V (Panoramic Wide-Angle)",
    serialNumber: "AX-PAN88301A",
    macAddress: "00:40:8C:F2:39:1A",
    ipAddress: "192.168.1.105",
    onvifPort: 80,
    rtspPort: 554,
    channel: 1,
    protocol: "onvif-t",
    status: "online",
    profiles: [
      { name: "main", codec: "H265", width: 2560, height: 1440, role: "main" },
      { name: "sub", codec: "H264", width: 640, height: 480, role: "sub" }
    ],
    capabilities: { ptz: false, audio: false, events: true },
    connectionSecretRef: "vault://branches/A005/cameras/05",
  },
  {
    id: "cam-a005-06",
    deviceIdentityId: "device-a005-06",
    nodeId: "group-a005-perimeter",
    branchId: "A005",
    name: "Parking Gate & Cash Van ANPR",
    vendor: "dahua",
    model: "ITC413-PW4D-IZ3 (4MP Traffic & License Plate ANPR)",
    serialNumber: "DH-ANPR99213K",
    macAddress: "3C:EF:8C:99:4A:21",
    ipAddress: "192.168.1.106",
    onvifPort: 80,
    rtspPort: 554,
    channel: 1,
    protocol: "onvif-t",
    status: "online",
    profiles: [
      { name: "main", codec: "H265", width: 2560, height: 1440, role: "main" }
    ],
    capabilities: { ptz: false, audio: false, events: true },
    connectionSecretRef: "vault://branches/A005/cameras/06",
  },
  {
    id: "cam-a005-07",
    deviceIdentityId: "device-a005-07",
    nodeId: "group-a005-vault",
    branchId: "A005",
    name: "Currency Sorter & High-Value Transit Bay",
    vendor: "cp-plus",
    model: "CP-UVR-0801E1V-I Ch 1 (Analog HD)",
    serialNumber: "CP-DVR-CH01-171",
    macAddress: "48:5D:36:99:AA:01",
    ipAddress: "192.168.1.171",
    onvifPort: 80,
    rtspPort: 554,
    channel: 1,
    sourceType: "analog-dvr-channel",
    recorderId: "recorder-a005-cpplus-dvr",
    recorderChannel: 1,
    protocol: "rtsp",
    status: "online",
    profiles: [
      { name: "main", codec: "H264", width: 1920, height: 1080, role: "main" }
    ],
    capabilities: { ptz: false, audio: true, events: true },
    connectionSecretRef: "vault://branches/A005/cameras/07",
  },
  {
    id: "cam-a005-08",
    deviceIdentityId: "device-a005-08",
    nodeId: "group-a005-public",
    branchId: "A005",
    name: "Customer Locker Room Air-Lock Corridor",
    vendor: "hikvision",
    model: "DS-2CD2143G2-I (4MP AcuSense Fixed Dome)",
    serialNumber: "HK-LCK201948A",
    macAddress: "E0:53:5A:88:12:77",
    ipAddress: "192.168.1.108",
    onvifPort: 80,
    rtspPort: 554,
    channel: 1,
    protocol: "onvif-t",
    status: "online",
    profiles: [
      { name: "main", codec: "H265", width: 2560, height: 1440, role: "main" }
    ],
    capabilities: { ptz: false, audio: true, events: true },
    connectionSecretRef: "vault://branches/A005/cameras/08",
  },

  // ==========================================
  // BRANCH A006 (Mumbai BKC Financial Center)
  // ==========================================
  {
    id: "cam-a006-01",
    deviceIdentityId: "device-a006-01",
    nodeId: "group-a006-public",
    branchId: "A006",
    name: "BKC Main Trading Floor & Customer Lounge",
    vendor: "hikvision",
    model: "DS-2CD2386G2-ISU/SL (4K AcuSense Bullet)",
    serialNumber: "HK-BKC109281",
    macAddress: "E0:53:5A:77:1A:01",
    ipAddress: "192.168.2.101",
    onvifPort: 80,
    rtspPort: 554,
    channel: 1,
    protocol: "onvif-t",
    status: "online",
    profiles: [
      { name: "main", codec: "H265", width: 3840, height: 2160, role: "main" }
    ],
    capabilities: { ptz: false, audio: true, events: true },
    connectionSecretRef: "vault://branches/A006/cameras/01",
  },
  {
    id: "cam-a006-02",
    deviceIdentityId: "device-a006-02",
    nodeId: "group-a006-vault",
    branchId: "A006",
    name: "Foreign Exchange & Bullion Vault Vault 1",
    vendor: "dahua",
    model: "IPC-HFW5442E-ZE (4K WizMind Bullet)",
    serialNumber: "DH-BKC991823",
    macAddress: "3C:EF:8C:77:1A:02",
    ipAddress: "192.168.2.102",
    onvifPort: 80,
    rtspPort: 554,
    channel: 2,
    protocol: "onvif-t",
    status: "online",
    profiles: [
      { name: "main", codec: "H265", width: 3840, height: 2160, role: "main" }
    ],
    capabilities: { ptz: true, audio: true, events: true },
    connectionSecretRef: "vault://branches/A006/cameras/02",
  },

  // ==========================================
  // BRANCH A007 (Delhi Connaught Place)
  // ==========================================
  {
    id: "cam-a007-01",
    deviceIdentityId: "device-a007-01",
    nodeId: "A007",
    branchId: "A007",
    name: "Connaught Place Inner Circle Entrance",
    vendor: "cp-plus",
    model: "CP-UNC-TA41ZL4-VMD (4MP IR Dome)",
    serialNumber: "CP-DEL882910A",
    macAddress: "48:5D:36:33:44:01",
    ipAddress: "192.168.3.101",
    onvifPort: 80,
    rtspPort: 554,
    channel: 1,
    protocol: "onvif-s",
    status: "online",
    profiles: [
      { name: "main", codec: "H264", width: 2560, height: 1440, role: "main" }
    ],
    capabilities: { ptz: false, audio: true, events: true },
    connectionSecretRef: "vault://branches/A007/cameras/01",
  },

  // ==========================================
  // BRANCH A008 (Bengaluru Whitefield Tech Hub)
  // ==========================================
  {
    id: "cam-a008-01",
    deviceIdentityId: "device-a008-01",
    nodeId: "A008",
    branchId: "A008",
    name: "Whitefield ITPL Main Gate & Lobby",
    vendor: "hikvision",
    model: "DS-2CD2143G2-I (4MP AcuSense Dome)",
    serialNumber: "HK-BLR772911",
    macAddress: "E0:53:5A:44:55:01",
    ipAddress: "192.168.4.101",
    onvifPort: 80,
    rtspPort: 554,
    channel: 1,
    protocol: "onvif-t",
    status: "online",
    profiles: [
      { name: "main", codec: "H265", width: 2560, height: 1440, role: "main" }
    ],
    capabilities: { ptz: false, audio: true, events: true },
    connectionSecretRef: "vault://branches/A008/cameras/01",
  },
];

const seedDeviceIdentities: DeviceIdentity[] = seedCameras.map((camera) => ({
  deviceId: camera.deviceIdentityId!,
  tenantId,
  branchId: camera.branchId,
  cameraId: camera.id,
  deviceType: camera.sourceType ?? "ip-camera",
  manufacturer: camera.vendor,
  model: camera.model,
  credentialRef: camera.connectionSecretRef,
  ipHistory: [],
  firstSeenAt: new Date(0).toISOString(),
  lastSeenAt: new Date(0).toISOString(),
}));

export class MemoryStore {
  // The in-memory store is an explicitly non-production adapter populated with
  // deterministic development fixtures. Production startup requires DATABASE_URL
  // and never uses these records as operational data.
  readonly nodes = new Map<string, ResourceNode>(seedNodes.map((n) => [n.id, n]));
  readonly users = new Map<string, User>(seedUsers.map((u) => [u.id, u]));
  readonly cameras = new Map<string, Camera>(seedCameras.map((c) => [c.id, c]));
  readonly deviceIdentities = new Map<string, DeviceIdentity>(seedDeviceIdentities.map((d) => [d.deviceId, d]));
  readonly deviceIdentityClaims = new Map<string, string>();
  readonly grants: AccessGrant[] = [...seedGrants];
  readonly edgeAgents = new Map<string, EdgeAgent>();
  readonly edgeScanJobs = new Map<string, EdgeScanJob>();
  readonly edgeActivations = new Map<string, EdgeActivation & { tokenHash: string }>();
  readonly edgeCredentialHashes = new Map<string, string>();
  readonly edgeCommandPublicKeys = new Map<string, string>();
  readonly edgeManagedTunnels = new Map<string, EdgeManagedTunnel>();
  readonly branchConnectivityProfiles = new Map<string, BranchConnectivityProfile>();
  readonly edgeCommands = new Map<string, EdgeCommand>();
  readonly edgeUpdateReleases = new Map<string, EdgeUpdateRelease>();
  readonly operationalTelemetry = new Map<string, OperationalTelemetryEnvelope>();
  readonly operationalTelemetryHistory: OperationalTelemetryEnvelope[] = [];
  readonly operationalTelemetryKeys = new Set<string>();
  readonly operationalHealthPolicies = new Map<string, OperationalHealthPolicy>();
  readonly videoWallLayouts: VideoWallLayout[] = [];
  readonly discoveries = new Map<string, DiscoveredCamera>();
  readonly auditEvents: AuditEventInput[] = [];
  readonly liveSessions = new Map<
    string,
    LiveSession & { tokenHash: string; consumed: boolean }
  >();
  readonly recordingJobs = new Map<string, RecordingJob>();
  readonly recordingSegments: RecordingSegment[] = [];
  readonly recordingLegalHolds: RecordingLegalHold[] = [];
  readonly recordingStorageNodes = new Map<string, RecordingStorageNode>();
  readonly recordingHealthEvents: RecordingHealthEvent[] = [];
  readonly liveBookmarks: LiveBookmark[] = [];
  readonly liveIncidents: LiveIncident[] = [];
  // Investigation incidents (full featured)
  readonly incidents: any[] = [];
  readonly incidentParticipants: any[] = [];
  readonly incidentCameras: any[] = [];
  readonly incidentVideoRanges: any[] = [];
  readonly incidentEvents: any[] = [];
  readonly incidentClips: any[] = [];
  readonly incidentSnapshots: any[] = [];
  readonly incidentEvidenceItems: any[] = [];
  readonly incidentEvidencePackages: any[] = [];
  readonly incidentPoliceIntimations: any[] = [];
  readonly incidentPoliceEvidenceTransfers: any[] = [];
  readonly incidentInsuranceClaims: any[] = [];
  readonly incidentInsuranceDocuments: any[] = [];
  readonly incidentTasks: any[] = [];
  readonly incidentNotes: any[] = [];
  readonly incidentSecureShares: any[] = [];
  readonly incidentReports: any[] = [];
  readonly complianceFrameworks: ComplianceFramework[] = [];
  readonly compliancePolicies: CompliancePolicy[] = [];
  readonly complianceAssessments: ComplianceAssessment[] = [];
  readonly complianceCertificates: ComplianceCertificate[] = [];
  readonly analyticsRules: AnalyticsRule[] = [];
  readonly analyticsEvents: AnalyticsEvent[] = [];
  readonly analyticsAlerts: AnalyticsAlert[] = [];
  readonly analyticsAcknowledgements: Array<Record<string, unknown>> = [];
  readonly analyticsEscalations: Array<Record<string, unknown>> = [];
  readonly analyticsNotifications: AlertNotification[] = [];
  readonly alertNotificationPolicies = new Map<string, AlertNotificationPolicy>();
  readonly smsRateLimitWindows = new Map<string, number>();
  readonly operationalReportSchedules: OperationalReportSchedule[] = [];
  readonly operationalReportRuns: OperationalReportRun[] = [];
  readonly operationalReportArtifacts: OperationalReportArtifact[] = [];
  readonly operationalReportDeliveries: OperationalReportDelivery[] = [];
  readonly operationalReportScheduleClaims = new Set<string>();
  readonly maintenanceAssets: any[] = [];
  readonly maintenanceVisits: any[] = [];
  readonly predictiveAlerts: any[] = [];
  readonly deviceInventoryRecords: any[] = [];
  readonly passwordRotations: any[] = [];
  readonly deviceTemplates: any[] = [];
  readonly deviceTemplateAssignments: any[] = [];
  readonly deviceIpAssignments: any[] = [];
  readonly deviceConfigurationJobs: any[] = [];
  readonly deviceJobSteps: any[] = [];
  readonly branchNetworks = new Map<string, any>();
  readonly workOrders: any[] = [];
  readonly maintenanceVendors: any[] = [];
  readonly amcContracts: any[] = [];
  readonly maintenancePlans: any[] = [];
  readonly maintenanceSchedules: any[] = [];
  readonly cameraHealth: any[] = [];
  readonly storageHealth: any[] = [];
  readonly networkHealth: any[] = [];
  readonly upsHealth: any[] = [];
  readonly firmwareInventory: any[] = [];
  readonly softwareVersions: any[] = [];
  readonly spareParts: any[] = [];
  readonly inventoryTransactions: any[] = [];
  readonly maintenanceReports: any[] = [];
  readonly privacyPurposes: any[] = [];
  readonly cameraPrivacyPurposeAssignments: any[] = [];
  readonly cameraPrivacyControls = new Map<string, any>();
  readonly privacyBreaches: any[] = [];
  readonly complianceRequirements: any[] = [];
  readonly complianceControls: any[] = [];
  readonly complianceEvidence: any[] = [];
  readonly complianceTests: any[] = [];
  readonly complianceFindings: any[] = [];
  readonly remediationPlans: any[] = [];
  readonly remediationActions: any[] = [];
  readonly complianceRisks: any[] = [];
  readonly complianceAuditLog: any[] = [];
  readonly userSessions = new Map<string, {
    id: string;
    userId: string;
    tenantId: string;
    accessTokenHash: string;
    refreshTokenHash: string;
    ipAddress?: string;
    userAgent?: string;
    accessExpiresAt: Date;
    expiresAt: Date;
    lastActivityAt: Date;
    createdAt: Date;
  }>();
  readonly passwordResetTokens = new Map<string, {
    id: string;
    userId: string;
    tokenHash: string;
    expiresAt: Date;
    usedAt?: Date;
    createdAt: Date;
  }>();

  constructor() {
    // The memory store is only a development/test adapter. Production data is
    // loaded from PostgresStore; never manufacture an enterprise inventory in
    // the runtime when the database is unavailable.
  }

  private initializeEnterpriseSeedData() {
    // 1. Maintenance Vendors
    this.maintenanceVendors.push(
      {
        id: "vendor-godrej",
        tenantId,
        name: "Godrej Security Solutions (Division of Godrej & Boyce)",
        code: "VEND-GS-01",
        contactPerson: "Ramesh Varma",
        email: "ramesh.varma@godrej.com",
        phone: "+91 98201 44552",
        address: "Pirojshanagar, Vikhroli East, Mumbai, Maharashtra 400079",
        specialization: "Vault doors, currency chests, biometric airlocks, CCTV installation & physical hardening",
        slaStandardHours: 6,
        slaEmergencyHours: 2,
        rating: 4.9,
        status: "active",
        createdAt: new Date().toISOString(),
      },
      {
        id: "vendor-honeywell",
        tenantId,
        name: "Honeywell Building Solutions India Pvt Ltd",
        code: "VEND-HB-02",
        contactPerson: "Priya Nambiar",
        email: "priya.nambiar@honeywell.com",
        phone: "+91 98450 11223",
        address: "EcoWorld Technology Park, Marathahalli-Sarjapur Outer Ring Road, Bengaluru, Karnataka 560103",
        specialization: "Enterprise NVR storage, VMS, video analytics server clusters, fire alarm integration",
        slaStandardHours: 8,
        slaEmergencyHours: 4,
        rating: 4.8,
        status: "active",
        createdAt: new Date().toISOString(),
      },
      {
        id: "vendor-schneider",
        tenantId,
        name: "Schneider Electric India (APC Critical Power)",
        code: "VEND-SE-03",
        contactPerson: "Anand Joshi",
        email: "anand.joshi@se.com",
        phone: "+91 98110 33445",
        address: "DLF Cyber City, Tower C, Phase II, Gurugram, Haryana 122002",
        specialization: "Online double-conversion UPS, lithium battery banks, environmental thermal sensors",
        slaStandardHours: 4,
        slaEmergencyHours: 2,
        rating: 4.9,
        status: "active",
        createdAt: new Date().toISOString(),
      },
      {
        id: "vendor-cpplus",
        tenantId,
        name: "CP PLUS Enterprise Systems (Aditya Infotech Ltd)",
        code: "VEND-CP-04",
        contactPerson: "Siddharth Nair",
        email: "siddharth.nair@adityagroup.com",
        phone: "+91 97110 88990",
        address: "A-12, Sector 4, Noida, Uttar Pradesh 201301",
        specialization: "UVR HD DVR fleets, analog HD coax infrastructure, IP cameras, optical transceivers",
        slaStandardHours: 12,
        slaEmergencyHours: 4,
        rating: 4.7,
        status: "active",
        createdAt: new Date().toISOString(),
      }
    );

    // 2. AMC Contracts
    this.amcContracts.push(
      {
        id: "amc-2026-godrej-south",
        tenantId,
        contractNumber: "AMC-2026-GODREJ-SOUTH-01",
        name: "Comprehensive Annual Maintenance - South Zone Vault & Physical Security",
        vendorId: "vendor-godrej",
        vendorName: "Godrej Security Solutions",
        startDate: "2026-01-01",
        endDate: "2026-12-31",
        annualCost: 1850000,
        currency: "INR",
        paymentFrequency: "quarterly",
        status: "active",
        scope: "All 24 branches across South Zone including A005 Kochi, A008 Bengaluru, A009 Hyderabad, A010 Chennai",
        visitFrequency: "monthly",
        terms: "Includes 24/7 on-call dispatch with 2hr emergency response SLA. All camera and lock hardware replacements covered.",
        coveredAssetCategories: ["camera", "recorder", "vault_door", "biometric"],
        createdAt: new Date().toISOString(),
      },
      {
        id: "amc-2026-honeywell-west",
        tenantId,
        contractNumber: "AMC-2026-HONEYWELL-WEST-02",
        name: "Tier-1 High Availability NVR & Surveillance SAN Storage Matrix AMC",
        vendorId: "vendor-honeywell",
        vendorName: "Honeywell Building Solutions",
        startDate: "2026-04-01",
        endDate: "2027-03-31",
        annualCost: 2400000,
        currency: "INR",
        paymentFrequency: "quarterly",
        status: "active",
        scope: "West & North Zone Primary Data Centers and NVR Fleets including A006 Mumbai BKC, A007 Delhi CP",
        visitFrequency: "bi-weekly",
        terms: "Automatic HDD replacement upon first SMART bad sector detection. 4hr SLA for hot-spare restoration.",
        coveredAssetCategories: ["recorder", "storage", "analytics_server"],
        createdAt: new Date().toISOString(),
      },
      {
        id: "amc-2026-schneider-ups",
        tenantId,
        contractNumber: "AMC-2026-SCHNEIDER-PANINDIA-03",
        name: "National Mission-Critical 24/7 UPS & Battery Bank AMC",
        vendorId: "vendor-schneider",
        vendorName: "Schneider Electric India",
        startDate: "2025-10-01",
        endDate: "2026-09-30",
        annualCost: 1280000,
        currency: "INR",
        paymentFrequency: "half-yearly",
        status: "active",
        scope: "All branches pan-India online double-conversion UPS systems and battery banks",
        visitFrequency: "quarterly",
        terms: "Includes quarterly cell impedance testing, thermal calibration, and free battery cell swap if health drops below 85%.",
        coveredAssetCategories: ["ups", "battery_bank", "environmental_sensor"],
        createdAt: new Date().toISOString(),
      }
    );

    // 3. Maintenance Assets
    this.maintenanceAssets.push(
      {
        id: "asset-a005-nvr-01",
        tenantId,
        branchId: "A005",
        name: "Kochi Marine Drive Primary 32-Ch 4K NVR (Dahua NVR5432-4KS2)",
        assetTag: "AST-A005-NVR-01",
        category: "recorder",
        manufacturer: "Dahua Technology",
        model: "NVR5432-4KS2",
        serialNumber: "DH-NVR5432-88192",
        ipAddress: "192.168.1.10",
        location: "Kochi Main Branch - Ground Floor Server Room Rack A1",
        status: "healthy",
        healthPercentage: 99.4,
        installDate: "2024-06-15",
        warrantyExpiryDate: "2028-06-30",
        amcContractId: "amc-2026-godrej-south",
        vendorId: "vendor-godrej",
        lastServicedAt: "2026-08-01T10:30:00Z",
        nextServiceDueAt: "2026-09-01T10:30:00Z",
        specifications: { channels: 32, maxResolution: "4K", storageSlots: 4, raidLevel: "RAID-5" },
        createdAt: new Date().toISOString(),
      },
      {
        id: "asset-a005-ups-01",
        tenantId,
        branchId: "A005",
        name: "Kochi Branch 10kVA Online Double-Conversion UPS (APC Smart-UPS On-Line)",
        assetTag: "AST-A005-UPS-01",
        category: "ups",
        manufacturer: "Schneider Electric (APC)",
        model: "SURT10000XLI",
        serialNumber: "APC-SURT10000XLI-9921",
        ipAddress: "192.168.1.250",
        location: "Kochi Main Branch - Ground Floor Server Room UPS Bay",
        status: "healthy",
        healthPercentage: 98.2,
        installDate: "2024-01-10",
        warrantyExpiryDate: "2027-01-10",
        amcContractId: "amc-2026-schneider-ups",
        vendorId: "vendor-schneider",
        lastServicedAt: "2026-07-20T11:00:00Z",
        nextServiceDueAt: "2026-10-20T11:00:00Z",
        specifications: { capacityVA: 10000, runtimeMinutes: 185, batteryType: "VRLA AGM" },
        createdAt: new Date().toISOString(),
      },
      {
        id: "asset-a006-san-01",
        tenantId,
        branchId: "A006",
        name: "Mumbai BKC Surveillance SAN Storage Matrix (Honeywell 96TB RAID-6)",
        assetTag: "AST-A006-SAN-01",
        category: "storage",
        manufacturer: "Honeywell Building Solutions",
        model: "MAXPRO SAN-96TB",
        serialNumber: "HW-SAN96T-001",
        ipAddress: "192.168.2.20",
        location: "Mumbai BKC Regional Datacenter - Rack C3",
        status: "healthy",
        healthPercentage: 99.8,
        installDate: "2024-03-01",
        warrantyExpiryDate: "2029-03-01",
        amcContractId: "amc-2026-honeywell-west",
        vendorId: "vendor-honeywell",
        lastServicedAt: "2026-08-14T09:15:00Z",
        nextServiceDueAt: "2026-09-14T09:15:00Z",
        specifications: { totalCapacityTB: 96, freeCapacityTB: 42.8, raidLevel: "RAID-6" },
        createdAt: new Date().toISOString(),
      },
      {
        id: "asset-a007-switch-01",
        tenantId,
        branchId: "A007",
        name: "Delhi CP Core PoE+ Managed Surveillance Switch (Cisco Catalyst 3850)",
        assetTag: "AST-A007-SW-01",
        category: "network",
        manufacturer: "Cisco Systems",
        model: "WS-C3850-48P-L",
        serialNumber: "FCW2219B021",
        ipAddress: "192.168.3.2",
        location: "Delhi CP Main Branch - IT Enclosure Rack 1",
        status: "healthy",
        healthPercentage: 100.0,
        installDate: "2023-11-20",
        warrantyExpiryDate: "2028-11-20",
        amcContractId: "amc-2026-honeywell-west",
        vendorId: "vendor-honeywell",
        lastServicedAt: "2026-08-05T14:00:00Z",
        nextServiceDueAt: "2026-11-05T14:00:00Z",
        specifications: { portCount: 48, poeBudgetWatts: 740, uplinkSpeedGbps: 10 },
        createdAt: new Date().toISOString(),
      }
    );

    // 4. Work Orders
    this.workOrders.push(
      {
        id: "wo-2026-0818-01",
        tenantId,
        branchId: "A005",
        workOrderNumber: "WO-2026-0818-01",
        title: "Optical Calibration & WDR Tuning - Strong Room Vault Camera",
        description: "Quarterly precision calibration of Dahua 4K bullet camera in the currency vault. Clean optical glass, test IR cut filter, verify dual-stream timestamping.",
        assetId: "cam-a005-03",
        assetName: "Strong Room Dual-Custody Vault Door",
        vendorId: "vendor-godrej",
        vendorName: "Godrej Security Solutions",
        priority: "medium",
        status: "completed",
        scheduledDate: "2026-08-18",
        completedDate: "2026-08-18",
        assignedTechnician: "Vipin Das (Certified Security Specialist)",
        technicianNotes: "Optical glass cleaned. WDR adjusted to 120dB for low-light vault threshold. Frame rate locked to 25fps H.265. Camera health 100%.",
        cost: 3500,
        coveredUnderAmc: true,
        createdAt: "2026-08-17T09:00:00Z",
      },
      {
        id: "wo-2026-0814-02",
        tenantId,
        branchId: "A006",
        workOrderNumber: "WO-2026-0814-02",
        title: "Surveillance HDD Proactive Replacement - Mumbai BKC SAN Matrix",
        description: "Early SMART predictive health warning detected 3 reallocated sectors on Bay 4 HDD. Replace with Western Digital Purple Pro 8TB surveillance drive.",
        assetId: "asset-a006-san-01",
        assetName: "Mumbai BKC Surveillance SAN Storage Matrix",
        vendorId: "vendor-honeywell",
        vendorName: "Honeywell Building Solutions",
        priority: "high",
        status: "completed",
        scheduledDate: "2026-08-14",
        completedDate: "2026-08-14",
        assignedTechnician: "Amit Saxena (Storage Engineer)",
        technicianNotes: "Hot-swapped Bay 4 HDD with new WD84PURZ 8TB drive. RAID-6 array rebuilt automatically in 4 hours 12 mins. Array status optimal.",
        cost: 21500,
        coveredUnderAmc: true,
        createdAt: "2026-08-13T14:30:00Z",
      },
      {
        id: "wo-2026-0820-03",
        tenantId,
        branchId: "A008",
        workOrderNumber: "WO-2026-0820-03",
        title: "Quarterly Online UPS Battery Impedance & Load Bank Test",
        description: "Run automated discharge load test, measure internal cell resistance across 16 VRLA battery modules, and update SNMP management card firmware.",
        assetId: "asset-a005-ups-01",
        assetName: "Bengaluru Whitefield 10kVA Online UPS",
        vendorId: "vendor-schneider",
        vendorName: "Schneider Electric India",
        priority: "low",
        status: "in_progress",
        scheduledDate: "2026-08-20",
        assignedTechnician: "Sanjay Gowda (Field Power Engineer)",
        technicianNotes: "Test underway. Modules 1-12 impedance within 1.2 mOhm tolerance. Battery runtime estimated at 192 mins under full branch surveillance load.",
        cost: 4800,
        coveredUnderAmc: true,
        createdAt: "2026-08-19T10:00:00Z",
      }
    );

    // 5. Compliance Requirements
    this.complianceRequirements.push(
      {
        id: "req-rbi-cctv-retention",
        tenantId,
        code: "RBI-SEC-35A-CCTV",
        title: "RBI Banking Mandate 2024/71: Minimum 90-180 Day High-Definition CCTV Archive for Banking Halls & Vaults",
        standard: "RBI Master Directions on Security & Cash Logistics",
        category: "retention",
        mandatory: true,
        status: "compliant",
        evidenceCount: 12,
        description: "All commercial bank branches and currency chests must maintain tamper-evident, watermarked, continuous recordings of cash counters, strong rooms, and ATM kiosks for a minimum period of 180 days.",
        retentionPeriodDays: 180,
        createdAt: new Date().toISOString(),
      },
      {
        id: "req-dpdp-privacy-masking",
        tenantId,
        code: "DPDP-ACT-2023-SEC6",
        title: "Digital Personal Data Protection (DPDP) Act 2023: Dynamic Privacy Masking on Public Video Feeds",
        standard: "DPDP Act 2023 Statutory Compliance",
        category: "privacy",
        mandatory: true,
        status: "compliant",
        evidenceCount: 8,
        description: "Customer facial features, PIN pads, and non-relevant bystander video data must be dynamically masked for non-investigative live view roles.",
        retentionPeriodDays: 90,
        createdAt: new Date().toISOString(),
      },
      {
        id: "req-iso27001-cryptography",
        tenantId,
        code: "ISO-27001-A.8.24",
        title: "ISO/IEC 27001:2022 Control A.8.24: End-to-End RTSP/SRTP TLS 1.2+ Stream Encryption & mTLS",
        standard: "ISO/IEC 27001:2022 Information Security Management",
        category: "cryptography",
        mandatory: true,
        status: "compliant",
        evidenceCount: 15,
        description: "All video stream transmissions from branch edge gateways to the cloud control plane must enforce mutual TLS (mTLS) with 90-day automatic cryptographic credential rotation.",
        retentionPeriodDays: 365,
        createdAt: new Date().toISOString(),
      },
      {
        id: "req-pci-dss-access-control",
        tenantId,
        code: "PCI-DSS-V4-REQ9",
        title: "PCI-DSS v4.0 Requirement 9.1: Physical Access Control & Video Surveillance at ATM & POS Terminals",
        standard: "Payment Card Industry Data Security Standard (PCI-DSS v4.0)",
        category: "access_control",
        mandatory: true,
        status: "compliant",
        evidenceCount: 6,
        description: "ATM lobbies, POS transit desks, and network ingress points must maintain continuous tamper-evident video surveillance with dual-factor audit trails.",
        retentionPeriodDays: 365,
        createdAt: new Date().toISOString(),
      }
    );

    // 6. Privacy Purposes
    this.privacyPurposes.push(
      {
        id: "purp-security",
        tenantId,
        code: "PURP-BANK-SEC",
        name: "Security and Physical Asset Protection of Branch Premises",
        description: "Continuous real-time video surveillance for burglary prevention, cash protection, and perimeter security.",
        dataCategories: ["video_stream", "audio_event", "motion_telemetry"],
        legalBasis: "Legitimate Interests / RBI Master Directions on Bank Security",
        retentionDays: 180,
        allowedRoles: ["super_admin", "global_admin", "soc_operator", "investigator"],
        createdAt: new Date().toISOString(),
      },
      {
        id: "purp-fraud",
        tenantId,
        code: "PURP-FRAUD-PREV",
        name: "Investigation and Prevention of Financial Fraud and ATM Skimming",
        description: "Targeted forensic clip extraction and facial recognition matching against national fraud watchlists.",
        dataCategories: ["video_stream_and_face_crop", "anpr_plate_record"],
        legalBasis: "Legal Obligation / Prevention of Financial Crimes",
        retentionDays: 365,
        allowedRoles: ["super_admin", "investigator", "evidence_officer"],
        createdAt: new Date().toISOString(),
      },
      {
        id: "purp-safety",
        tenantId,
        code: "PURP-SAFETY-HEALTH",
        name: "Customer and Bank Staff Safety and Occupational Health Monitoring",
        description: "Emergency fire egress monitoring, crowd density detection, and medical incident response.",
        dataCategories: ["video_stream"],
        legalBasis: "Public Safety and Employee Protection Regulations",
        retentionDays: 90,
        allowedRoles: ["super_admin", "global_admin", "branch_manager", "soc_operator"],
        createdAt: new Date().toISOString(),
      }
    );

    // 7. Spare Parts Inventory
    this.spareParts.push(
      {
        id: "part-wd-purple-8tb",
        tenantId,
        partNumber: "WD84PURZ",
        name: "Western Digital Purple Pro 8TB Surveillance HDD (SATA 6Gb/s 256MB Cache)",
        category: "storage_drive",
        manufacturer: "Western Digital",
        quantityOnHand: 18,
        reorderThreshold: 5,
        unitCost: 19500,
        currency: "INR",
        compatibleModels: ["Dahua NVR5432-4KS2", "Hikvision DS-9632NI-I8", "CP PLUS CP-UNR-416T2"],
        location: "Kochi Central Logistics Depot - Shelf B4",
        status: "in_stock",
        createdAt: new Date().toISOString(),
      },
      {
        id: "part-sfp-transceiver-10g",
        tenantId,
        partNumber: "SFP-10G-SR",
        name: "Cisco 10GBASE-SR SFP+ Optical Transceiver Module",
        category: "network_module",
        manufacturer: "Cisco Systems",
        quantityOnHand: 24,
        reorderThreshold: 8,
        unitCost: 8200,
        currency: "INR",
        compatibleModels: ["Cisco Catalyst 3850", "Honeywell SAN Storage"],
        location: "Mumbai BKC IT Store - Bin 12",
        status: "in_stock",
        createdAt: new Date().toISOString(),
      }
    );
  }

  async close() {}

  async getUser(identity: string) {
    return this.users.get(identity);
  }

  async getUserById(id: string) {
    return this.users.get(id);
  }

  async findUserByEmail(email: string, _tenantSlug?: string) {
    for (const user of this.users.values()) {
      if (user.email?.toLowerCase() === email.toLowerCase()) {
        return user;
      }
    }
    return undefined;
  }

  async findUserByUsername(username: string, _tenantSlug?: string) {
    for (const user of this.users.values()) {
      if (user.username?.toLowerCase() === username.toLowerCase()) {
        return user;
      }
    }
    return undefined;
  }

  async createUserSession(
    userId: string,
    tenantId: string,
    accessTokenHash: string,
    refreshTokenHash: string,
    ipAddress?: string,
    userAgent?: string,
  ) {
    const id = randomUUID();
    const now = new Date();
    const session = {
      id,
      userId,
      tenantId,
      accessTokenHash,
      refreshTokenHash,
      ipAddress,
      userAgent,
      accessExpiresAt: new Date(now.getTime() + 60 * 60 * 1000),
      expiresAt: new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000),
      lastActivityAt: now,
      createdAt: now,
    };
    this.userSessions.set(id, session);
    return {
      id: session.id,
      userId: session.userId,
      tenantId: session.tenantId,
      accessExpiresAt: session.accessExpiresAt,
      expiresAt: session.expiresAt,
    };
  }

  async findSessionByAccessToken(tokenHash: string) {
    const now = new Date();
    for (const session of this.userSessions.values()) {
      if (session.accessTokenHash === tokenHash && session.accessExpiresAt > now && session.expiresAt > now) {
        return { ...session };
      }
    }
    return undefined;
  }

  async findSessionByRefreshToken(tokenHash: string) {
    const now = new Date();
    for (const session of this.userSessions.values()) {
      if (session.refreshTokenHash === tokenHash && session.expiresAt > now) {
        return { ...session };
      }
    }
    return undefined;
  }

  async updateSessionAccessToken(
    sessionId: string,
    newTokenHash: string,
    ipAddress?: string,
    userAgent?: string,
  ) {
    const session = this.userSessions.get(sessionId);
    if (session) {
      session.accessTokenHash = newTokenHash;
      session.accessExpiresAt = new Date(Date.now() + 60 * 60 * 1000);
      session.lastActivityAt = new Date();
      if (ipAddress) session.ipAddress = ipAddress;
      if (userAgent) session.userAgent = userAgent;
    }
  }

  async updateSessionActivity(sessionId: string) {
    const session = this.userSessions.get(sessionId);
    if (session) {
      session.lastActivityAt = new Date();
    }
  }

  async getUserSession(sessionId: string) {
    const session = this.userSessions.get(sessionId);
    return session ? { ...session } : undefined;
  }

  async listUserSessions(userId: string) {
    const now = new Date();
    const list: any[] = [];
    for (const session of this.userSessions.values()) {
      if (session.userId === userId && session.expiresAt > now) {
        list.push({
          id: session.id,
          userId: session.userId,
          ipAddress: session.ipAddress,
          userAgent: session.userAgent,
          accessExpiresAt: session.accessExpiresAt,
          expiresAt: session.expiresAt,
          lastActivityAt: session.lastActivityAt,
          createdAt: session.createdAt,
        });
      }
    }
    return list.sort((a, b) => new Date(b.lastActivityAt).getTime() - new Date(a.lastActivityAt).getTime());
  }

  async deleteUserSession(sessionId: string) {
    this.userSessions.delete(sessionId);
  }

  async deleteAllUserSessions(userId: string) {
    for (const [id, session] of this.userSessions.entries()) {
      if (session.userId === userId) {
        this.userSessions.delete(id);
      }
    }
  }

  async createPasswordResetToken(userId: string, tokenHash: string) {
    const id = randomUUID();
    const now = new Date();
    const record = {
      id,
      userId,
      tokenHash,
      expiresAt: new Date(now.getTime() + 60 * 60 * 1000),
      createdAt: now,
    };
    this.passwordResetTokens.set(tokenHash, record);
    return record;
  }

  async findPasswordResetToken(tokenHash: string) {
    return this.passwordResetTokens.get(tokenHash);
  }

  async markPasswordResetTokenUsed(tokenId: string) {
    for (const token of this.passwordResetTokens.values()) {
      if (token.id === tokenId) {
        token.usedAt = new Date();
      }
    }
  }

  async listTenants() {
    return [...this.nodes.values()]
      .filter((node) => node.type === "company")
      .map((node) => ({
        id: node.id,
        name: node.name,
        tenantId: node.tenantId,
      }));
  }

  async getNode(id: string) {
    return this.nodes.get(id);
  }

  async checkAccess(user: User, action: Action, resourceNodeId: string) {
    const node = this.nodes.get(resourceNodeId);
    if (!node) return undefined;
    return authorize(user, action, node, this.nodes, this.grants);
  }

  async listAccessibleNodes(user: User, action: Action, type?: ResourceNode["type"]) {
    return [...this.nodes.values()].filter(
      (node) => (!type || node.type === type) &&
        authorize(user, action, node, this.nodes, this.grants).allowed,
    );
  }

  async getCamera(id: string) {
    return this.cameras.get(id);
  }

  async listCamerasByIds(cameraIds: string[]) {
    const ids = new Set(cameraIds);
    return [...this.cameras.values()].filter((camera) => ids.has(camera.id));
  }

  async listNodesByIds(ids: string[]) {
    const keys = new Set(ids);
    return [...this.nodes.values()].filter((node) => keys.has(node.id));
  }

  async getDeviceIdentityByCamera(cameraId: string) {
    const identity = [...this.deviceIdentities.values()].find((item) => item.cameraId === cameraId);
    return identity ? structuredClone(identity) : undefined;
  }

  async listCamerasByBranch(user: User, branchId: string, action: Action) {
    return [...this.cameras.values()].filter((camera) => {
      if (camera.branchId !== branchId) return false;
      const node = this.nodes.get(camera.nodeId);
      return Boolean(node && authorize(user, action, node, this.nodes, this.grants).allowed);
    });
  }

  async listCamerasByBranchId(branchId: string) {
    const list: any[] = [...this.cameras.values()].filter(
      (camera) => camera.branchId === branchId || camera.nodeId === branchId
    );
    // Also include discovered cameras for this branch or scanner fallback
    const discovered = [...this.discoveries.values()].filter(
      (disc) => disc.branchId === branchId || (!disc.branchId && branchId === "A005")
    );
    for (const disc of discovered) {
      if (!list.some((c) => c.id === disc.id || c.ipAddress === disc.ipAddress)) {
        list.push({
          id: disc.id,
          name: (disc as any).displayName || (disc as any).name || `${disc.vendor?.toUpperCase() || "IP"} Camera (${disc.ipAddress})`,
          branchId,
          nodeId: branchId,
          vendor: (disc.vendor || "other") as any,
          model: disc.model || "ONVIF 4K IP Camera",
          channel: 1,
          protocol: "rtsp",
          status: "online" as any,
          profiles: [],
          capabilities: { ptz: false, audio: false, motion: true },
          connectionSecretRef: "secret-default",
          ipAddress: disc.ipAddress,
        });
      }
    }
    return list;
  }

  async listAllCameras() {
    const list: any[] = [...this.cameras.values()];
    for (const disc of this.discoveries.values()) {
      if (!list.some((c) => c.id === disc.id || c.ipAddress === disc.ipAddress)) {
        list.push({
          id: disc.id,
          name: (disc as any).displayName || (disc as any).name || `${disc.vendor?.toUpperCase() || "IP"} Camera (${disc.ipAddress})`,
          branchId: disc.branchId || "A005",
          nodeId: disc.branchId || "A005",
          vendor: (disc.vendor || "other") as any,
          model: disc.model || "ONVIF 4K IP Camera",
          channel: 1,
          protocol: "rtsp",
          status: "online" as any,
          profiles: [],
          capabilities: { ptz: false, audio: false, motion: true },
          connectionSecretRef: "secret-default",
          ipAddress: disc.ipAddress,
        });
      }
    }
    return list;
  }

  // --- OrganizationStore implementation ---
  async listOrganizationNodes(tenantId: string, type?: string, parentId?: string, includeInactive = false) {
    return [...this.nodes.values()].filter((node) => {
      if (type && node.type !== type) return false;
      if (parentId !== undefined && node.parentId !== parentId) return false;
      return true;
    });
  }

  async getOrganizationTree(tenantId: string) {
    const all = [...this.nodes.values()];
    const byId = new Map<string, any>();
    for (const n of all) {
      byId.set(n.id, { ...n, children: [] });
    }
    const roots: any[] = [];
    for (const n of all) {
      const nodeObj = byId.get(n.id);
      if (n.parentId && byId.has(n.parentId)) {
        byId.get(n.parentId).children.push(nodeObj);
      } else {
        roots.push(nodeObj);
      }
    }
    return roots;
  }

  async getOrganizationStatistics(tenantId: string) {
    const all = [...this.nodes.values()];
    const counts: Record<string, number> = {};
    for (const node of all) {
      counts[node.type] = (counts[node.type] ?? 0) + 1;
    }
    return {
      nodes: counts,
      cameras: {
        total: this.cameras.size + this.discoveries.size,
        online: this.cameras.size + this.discoveries.size,
      },
    };
  }

  async getOrganizationNodeDetails(id: string) {
    return this.nodes.get(id);
  }

  async getNodeHierarchyPath(id: string) {
    const node = this.nodes.get(id);
    if (!node) return [];
    const path: any[] = [];
    for (const ancestorId of node.path) {
      const a = this.nodes.get(ancestorId);
      if (a) path.push(a);
    }
    return path;
  }

  async getDescendantNodes(id: string, includeInactive = false) {
    const node = this.nodes.get(id);
    if (!node) return [];
    return [...this.nodes.values()].filter((n) => n.path.includes(id) && n.id !== id);
  }

  async createOrganizationNode(tenant: string, input: any) {
    const parent = input.parentNodeId ? this.nodes.get(input.parentNodeId) : undefined;
    const id = input.code ? input.code.toLowerCase().replace(/[^a-z0-9]/g, "-") : randomUUID();
    const node: ResourceNode = {
      id,
      tenantId: tenant || (parent ? parent.tenantId : tenantId),
      parentId: parent ? parent.id : null,
      type: input.nodeType || "branch",
      name: input.name,
      path: parent ? [...parent.path, id] : [id],
    };
    if (input.code) (node as any).code = input.code;
    if (input.description) (node as any).description = input.description;
    this.nodes.set(id, node);
    return node;
  }

  async updateOrganizationNode(id: string, input: any) {
    const node = this.nodes.get(id);
    if (!node) return undefined;
    if (input.name) node.name = input.name;
    if (input.code) (node as any).code = input.code;
    if (input.description) (node as any).description = input.description;
    return node;
  }

  async deactivateOrganizationNode(id: string) {
    this.nodes.delete(id);
  }

  async validateHierarchyRelationship(parentNodeId: string, childNodeType: string) {
    return true;
  }

  async listCamerasByEdgeAgent(edgeAgentId: string) {
    return [...this.cameras.values()].filter((camera) => camera.edgeAgentId === edgeAgentId);
  }

  async createBranch(tenant: string, parentNodeId: string, name: string) {
    const parent = this.nodes.get(parentNodeId);
    if (!parent || parent.tenantId !== tenant) throw new Error("invalid_parent");
    const id = randomUUID();
    const node: ResourceNode = {
      id, tenantId: tenant, parentId: parent.id, type: "branch", name,
      path: [...parent.path, id],
    };
    this.nodes.set(id, node);
    return node;
  }

  async registerEdgeAgent(branchId: string, name: string, version: string) {
    const agent: EdgeAgent = {
      id: randomUUID(), branchId, name, version, status: "pending", lastSeenAt: null,
    };
    this.edgeAgents.set(agent.id, agent);
    return agent;
  }

  async listEdgeAgentsByBranch(branchId: string) {
    return [...this.edgeAgents.values()].filter(
      (agent) => agent.branchId === branchId,
    ).map((agent) => ({
      ...agent,
      status: agent.credentialStatus === "revoked"
        ? "offline" as const
        : agent.status === "pending"
          ? "pending" as const
          : isFreshEdgeAgent(agent)
            ? "online" as const
            : "offline" as const,
    }));
  }

  async heartbeatEdgeAgent(id: string, version: string, publicMediaUrl?: string, localMediaUrl?: string) {
    const agent = this.edgeAgents.get(id);
    if (!agent) return undefined;
    Object.assign(agent, {
      version,
      status: "online" as const,
      lastSeenAt: new Date().toISOString(),
      ...(publicMediaUrl ? { publicMediaUrl } : {}),
      ...(localMediaUrl ? { localMediaUrl } : {}),
    });
    return agent;
  }

  async getEdgeAgent(id: string) {
    const agent = this.edgeAgents.get(id);
    return agent ? structuredClone(agent) : undefined;
  }

  async listEdgeAgents(tenantId: string) {
    return Array.from(this.edgeAgents.values())
      .filter(agent => {
        // Get the branch node to find tenantId
        const branch = this.nodes.get(agent.branchId);
        return branch?.tenantId === tenantId;
      })
      .map(agent => structuredClone(agent));
  }

  async createEdgeActivation(input: {
    branchId: string; agentName: string; createdBy: string; expiresAt: string; tokenHash: string;
  }) {
    const branch = this.nodes.get(input.branchId);
    if (!branch || branch.type !== "branch") throw new Error("invalid_branch");
    const activation: EdgeActivation & { tokenHash: string } = {
      id: randomUUID(), tenantId: branch.tenantId, branchId: branch.id,
      agentName: input.agentName, createdBy: input.createdBy,
      createdAt: new Date().toISOString(), expiresAt: input.expiresAt,
      usedAt: null, revokedAt: null, tokenHash: input.tokenHash,
    };
    this.edgeActivations.set(activation.id, activation);
    const { tokenHash: _tokenHash, ...safe } = activation;
    return safe;
  }

  async activateEdgeAgent(input: {
    tokenHash: string; credentialHash: string; deviceUuid: string; version: string; commandPublicKey?: string;
  }) {
    const activation = [...this.edgeActivations.values()].find((item) => item.tokenHash === input.tokenHash);
    if (!activation || activation.usedAt || activation.revokedAt || Date.parse(activation.expiresAt) <= Date.now()) {
      throw new Error("activation_invalid_or_expired");
    }
    if ([...this.edgeAgents.values()].some((item) => item.deviceUuid === input.deviceUuid)) {
      throw new Error("device_already_enrolled");
    }
    const agent: EdgeAgent = {
      id: randomUUID(), branchId: activation.branchId, name: activation.agentName,
      version: input.version, status: "pending", lastSeenAt: null,
      deviceUuid: input.deviceUuid, credentialStatus: "active",
      credentialIssuedAt: new Date().toISOString(),
    };
    activation.usedAt = new Date().toISOString();
    this.edgeAgents.set(agent.id, agent);
    this.edgeCredentialHashes.set(agent.id, input.credentialHash);
    if (input.commandPublicKey) this.edgeCommandPublicKeys.set(agent.id, input.commandPublicKey);
    return { agent: structuredClone(agent), tenantId: activation.tenantId };
  }

  async verifyEdgeAgentCredential(id: string, credentialHash: string) {
    const agent = this.edgeAgents.get(id);
    return Boolean(agent && agent.credentialStatus === "active" &&
      this.edgeCredentialHashes.get(id) === credentialHash);
  }

  async getEdgeAgentCommandPublicKey(id: string) {
    return this.edgeCommandPublicKeys.get(id);
  }

  async revokeEdgeAgentCredential(id: string) {
    const agent = this.edgeAgents.get(id);
    if (!agent) return undefined;
    agent.credentialStatus = "revoked";
    agent.credentialRevokedAt = new Date().toISOString();
    agent.status = "offline";
    this.edgeCredentialHashes.delete(id);
    this.edgeCommandPublicKeys.delete(id);
    return structuredClone(agent);
  }

  async getEdgeManagedTunnel(branchId: string) {
    const tunnel = this.edgeManagedTunnels.get(branchId);
    return tunnel ? structuredClone(tunnel) : undefined;
  }

  async upsertEdgeManagedTunnel(
    input: Omit<EdgeManagedTunnel, "createdAt" | "updatedAt" | "lastCheckedAt" | "revokedAt">,
  ) {
    const now = new Date().toISOString();
    const current = this.edgeManagedTunnels.get(input.branchId);
    const tunnel: EdgeManagedTunnel = {
      ...structuredClone(input),
      createdAt: current?.createdAt ?? now,
      updatedAt: now,
      lastCheckedAt: current?.lastCheckedAt ?? null,
      revokedAt: input.status === "revoked" ? now : null,
    };
    this.edgeManagedTunnels.set(input.branchId, tunnel);
    return structuredClone(tunnel);
  }

  async updateEdgeManagedTunnelStatus(branchId: string, status: EdgeManagedTunnel["status"]) {
    const tunnel = this.edgeManagedTunnels.get(branchId);
    if (!tunnel) return undefined;
    const now = new Date().toISOString();
    tunnel.status = status;
    tunnel.updatedAt = now;
    tunnel.lastCheckedAt = now;
    if (status === "revoked") tunnel.revokedAt = now;
    return structuredClone(tunnel);
  }

  async getBranchConnectivityProfile(branchId: string) {
    const profile = this.branchConnectivityProfiles.get(branchId);
    return profile ? structuredClone(profile) : undefined;
  }

  async upsertBranchConnectivityProfile(
    input: Omit<BranchConnectivityProfile, "createdAt" | "updatedAt" | "lastVerifiedAt">,
  ) {
    const now = new Date().toISOString();
    const current = this.branchConnectivityProfiles.get(input.branchId);
    const profile: BranchConnectivityProfile = {
      ...structuredClone(input),
      createdAt: current?.createdAt ?? now,
      updatedAt: now,
      lastVerifiedAt: current?.lastVerifiedAt ?? null,
    };
    this.branchConnectivityProfiles.set(input.branchId, profile);
    return structuredClone(profile);
  }

  async updateBranchConnectivityStatus(
    branchId: string,
    status: BranchConnectivityProfile["status"],
  ) {
    const profile = this.branchConnectivityProfiles.get(branchId);
    if (!profile) return undefined;
    const now = new Date().toISOString();
    profile.status = status;
    profile.updatedAt = now;
    profile.lastVerifiedAt = now;
    return structuredClone(profile);
  }

  async createEdgeCommand(input: {
    edgeAgentId: string; type: EdgeCommand["type"]; payload: Record<string, unknown>; requestedBy: string;
  }) {
    const agent = this.edgeAgents.get(input.edgeAgentId);
    const branch = agent ? this.nodes.get(agent.branchId) : undefined;
    if (!agent || !branch || agent.credentialStatus === "revoked") throw new Error("edge_agent_not_found_or_revoked");
    const command: EdgeCommand = {
      id: randomUUID(), tenantId: branch.tenantId, branchId: branch.id, edgeAgentId: agent.id,
      type: input.type, payload: structuredClone(input.payload), status: "queued",
      result: null, error: null, requestedBy: input.requestedBy,
      requestedAt: new Date().toISOString(), startedAt: null, completedAt: null,
    };
    this.edgeCommands.set(command.id, command);
    return structuredClone(command);
  }

  async listEdgeCommands(branchId: string, limit = 100) {
    return [...this.edgeCommands.values()].filter((item) => item.branchId === branchId)
      .sort((left, right) => right.requestedAt.localeCompare(left.requestedAt))
      .slice(0, Math.max(1, Math.min(500, limit))).map((item) => structuredClone(item));
  }

  async claimEdgeCommand(edgeAgentId: string) {
    const staleBefore = Date.now() - 15 * 60_000;
    const command = [...this.edgeCommands.values()]
      .filter((item) => item.edgeAgentId === edgeAgentId && (
        item.status === "queued" ||
        (item.status === "running" && item.startedAt !== null && Date.parse(item.startedAt) < staleBefore)
      ))
      .sort((left, right) => left.requestedAt.localeCompare(right.requestedAt))[0];
    if (!command) return undefined;
    command.status = "running";
    command.startedAt = new Date().toISOString();
    return structuredClone(command);
  }

  async completeEdgeCommand(
    edgeAgentId: string,
    commandId: string,
    completion: { status: "succeeded" | "failed"; result?: Record<string, unknown>; error?: string },
  ) {
    const command = this.edgeCommands.get(commandId);
    if (!command || command.edgeAgentId !== edgeAgentId) return undefined;
    if (command.status === completion.status) return structuredClone(command);
    if (command.status !== "running") return undefined;
    command.status = completion.status;
    command.result = structuredClone(completion.result ?? {});
    command.error = completion.error ?? null;
    command.completedAt = new Date().toISOString();
    return structuredClone(command);
  }

  async createEdgeUpdateRelease(input: Omit<EdgeUpdateRelease, "id" | "createdAt">) {
    if ([...this.edgeUpdateReleases.values()].some((item) => item.version === input.version)) {
      throw Object.assign(new Error("release_exists"), { code: "23505" });
    }
    const release: EdgeUpdateRelease = { id: randomUUID(), createdAt: new Date().toISOString(), ...input };
    this.edgeUpdateReleases.set(release.id, release);
    return structuredClone(release);
  }

  async getEdgeUpdateReleaseForAgent(edgeAgentId: string, currentVersion: string) {
    const release = [...this.edgeUpdateReleases.values()]
      .filter((item) => item.enabled && item.version !== currentVersion)
      .sort((left, right) => right.createdAt.localeCompare(left.createdAt))[0];
    if (!release || rolloutBucket(edgeAgentId, release.version) >= release.rolloutPercentage) return undefined;
    return structuredClone(release);
  }

  async listAccessibleCameras(
    user: User,
    action: Action,
    filters: { branchId?: string; search?: string; status?: CameraStatus; limit: number; offset: number },
  ) {
    const search = filters.search?.trim().toLowerCase();
    const cameras = [...this.cameras.values()].filter((camera) => {
      if (filters.branchId && camera.branchId !== filters.branchId) return false;
      if (filters.status && camera.status !== filters.status) return false;
      if (search && !`${camera.name} ${camera.model} ${camera.id}`.toLowerCase().includes(search)) return false;
      const node = this.nodes.get(camera.nodeId);
      return Boolean(node && authorize(user, action, node, this.nodes, this.grants).allowed);
    }).sort((left, right) => left.name.localeCompare(right.name));
    return {
      total: cameras.length,
      cameras: cameras.slice(filters.offset, filters.offset + filters.limit),
    };
  }

  async ingestOperationalTelemetry(envelope: OperationalTelemetryEnvelope) {
    const dedupeKey = `${envelope.tenantId}:${envelope.idempotencyKey}`;
    if (this.operationalTelemetryKeys.has(dedupeKey)) {
      return { accepted: true, duplicate: true };
    }
    this.operationalTelemetryKeys.add(dedupeKey);
    this.operationalTelemetryHistory.push(structuredClone(envelope));
    const stateKey = `${envelope.tenantId}:${envelope.branchId}:${envelope.deviceType}:${envelope.deviceId}`;
    const current = this.operationalTelemetry.get(stateKey);
    if (!current || Date.parse(current.observedAt) <= Date.parse(envelope.observedAt)) {
      this.operationalTelemetry.set(stateKey, structuredClone(envelope));
    }
    return { accepted: true, duplicate: false };
  }

  async listLatestOperationalTelemetry(tenant: string, branchIds?: string[]) {
    const allowed = branchIds ? new Set(branchIds) : undefined;
    return [...this.operationalTelemetry.values()]
      .filter((item) => item.tenantId === tenant && (!allowed || allowed.has(item.branchId)))
      .map((item) => structuredClone(item));
  }

  async getOperationalHealthPolicy(tenant: string, branchId?: string) {
    return this.operationalHealthPolicies.get(`${tenant}:${branchId ?? "*"}`)
      ?? this.operationalHealthPolicies.get(`${tenant}:*`);
  }

  async upsertOperationalHealthPolicy(
    tenant: string,
    branchId: string | undefined,
    policy: OperationalHealthPolicy,
  ) {
    this.operationalHealthPolicies.set(`${tenant}:${branchId ?? "*"}`, structuredClone(policy));
    return structuredClone(policy);
  }

  async listVideoWallLayouts(tenant: string, userId: string) {
    return this.videoWallLayouts.filter((layout) => layout.tenantId === tenant && layout.createdBy === userId)
      .map((layout) => structuredClone(layout));
  }

  async createVideoWallLayout(input: {
    tenantId: string; userId: string; name: string; gridSize: VideoWallGridSize;
    cameraPositions: VideoWallLayout["cameraPositions"];
  }) {
    const now = new Date().toISOString();
    const layout: VideoWallLayout = {
      id: randomUUID(), tenantId: input.tenantId, name: input.name,
      gridSize: input.gridSize, cameraPositions: structuredClone(input.cameraPositions),
      isDefault: false, createdBy: input.userId, createdAt: now, updatedAt: now,
    };
    this.videoWallLayouts.push(layout);
    return structuredClone(layout);
  }

  async createEdgeScanJob(branchId: string, edgeAgentId?: string, target?: import("./control-plane-store.js").EdgeScanTarget) {
    const agent = edgeAgentId
      ? this.edgeAgents.get(edgeAgentId)
      : [...this.edgeAgents.values()].find((item) => item.branchId === branchId && item.status === "online");
    if (!agent || agent.branchId !== branchId || agent.status !== "online") throw new Error("edge_agent_not_connected");
    const job: EdgeScanJob = {
      id: randomUUID(), branchId, edgeAgentId: agent.id, status: "queued",
      scope: target ? "device" : "branch",
      ...(target ? {
        targetDiscoveryId: target.discoveryId,
        targetIpAddress: target.ipAddress,
        ...(target.onvifPort ? { targetOnvifPort: target.onvifPort } : {}),
      } : {}),
      requestedAt: new Date().toISOString(), startedAt: null, completedAt: null,
      resultCount: 0, provisionedCount: 0, credentialsRequiredCount: 0,
      pendingVerificationCount: 0, verifiedCount: 0, recorderCount: 0,
      timeSynchronizedCount: 0, timeDriftCount: 0,
      analyticsCompatibleCount: 0, duplicateCount: 0,
      credentialsSkippedAt: null, skippedStages: {}, error: null,
    };
    this.edgeScanJobs.set(job.id, job);
    return job;
  }

  async getEdgeScanJob(branchId: string, jobId: string) {
    const job = this.edgeScanJobs.get(jobId);
    return job?.branchId === branchId ? job : undefined;
  }

  async getLatestEdgeScanJob(branchId: string) {
    return [...this.edgeScanJobs.values()]
      .filter((job) => job.branchId === branchId && job.scope !== "device")
      .sort((left, right) => right.requestedAt.localeCompare(left.requestedAt))[0];
  }

  async skipEdgeScanJobCredentials(branchId: string, jobId: string) {
    const job = this.edgeScanJobs.get(jobId);
    if (!job || job.branchId !== branchId || job.scope === "device" || job.status !== "completed") {
      return undefined;
    }
    const skippedAt = new Date().toISOString();
    if (!job.credentialsSkippedAt) job.credentialsSkippedAt = skippedAt;
    job.skippedStages = { ...job.skippedStages, "credential-resolution": skippedAt };
    return job;
  }

  async skipEdgeScanJobStage(branchId: string, jobId: string, stageId: ProvisioningStageId) {
    const job = this.edgeScanJobs.get(jobId);
    if (!job || job.branchId !== branchId || job.scope === "device") return undefined;
    const skippedAt = new Date().toISOString();
    job.skippedStages = { ...job.skippedStages, [stageId]: job.skippedStages?.[stageId] ?? skippedAt };
    if (stageId === "credential-resolution" && !job.credentialsSkippedAt) {
      job.credentialsSkippedAt = skippedAt;
    }
    return job;
  }

  async claimEdgeScanJob(edgeAgentId: string) {
    const job = [...this.edgeScanJobs.values()]
      .filter((item) => item.edgeAgentId === edgeAgentId && item.status === "queued")
      .sort((a, b) => a.requestedAt.localeCompare(b.requestedAt))[0];
    if (!job) return undefined;
    Object.assign(job, { status: "running" as const, startedAt: new Date().toISOString() });
    return job;
  }

  async completeEdgeScanJob(
    edgeAgentId: string,
    jobId: string,
    result: {
      status: "completed" | "failed";
      resultCount: number;
      provisionedCount?: number;
      credentialsRequiredCount?: number;
      pendingVerificationCount?: number;
      verifiedCount?: number;
      recorderCount?: number;
      timeSynchronizedCount?: number;
      timeDriftCount?: number;
      analyticsCompatibleCount?: number;
      duplicateCount?: number;
      error?: string;
    },
  ) {
    const job = this.edgeScanJobs.get(jobId);
    if (!job || job.edgeAgentId !== edgeAgentId || job.status !== "running") return undefined;
    Object.assign(job, {
      status: result.status,
      resultCount: result.resultCount,
      provisionedCount: result.provisionedCount ?? 0,
      credentialsRequiredCount: result.credentialsRequiredCount ?? 0,
      pendingVerificationCount: result.pendingVerificationCount ?? 0,
      verifiedCount: result.verifiedCount ?? 0,
      recorderCount: result.recorderCount ?? 0,
      timeSynchronizedCount: result.timeSynchronizedCount ?? 0,
      timeDriftCount: result.timeDriftCount ?? 0,
      analyticsCompatibleCount: result.analyticsCompatibleCount ?? 0,
      duplicateCount: result.duplicateCount ?? 0,
      error: result.error ?? null,
      completedAt: new Date().toISOString(),
    });
    return job;
  }

  private findRecorderPlaceholderIdentity(branchId: string, observation: DeviceIdentityObservation) {
    if (!observation.ipAddress || observation.channel !== 1 ||
      (observation.deviceType !== "analog-dvr-channel" && observation.deviceType !== "nvr-channel")) {
      return undefined;
    }
    const recorderModel = /(dvr|nvr|xvr|uvr|recorder|multi[- ]?channel)/i;
    return [...this.deviceIdentities.values()].find((candidate) => {
      if (candidate.branchId !== branchId || candidate.deviceType !== "ip-camera" ||
        candidate.currentIpAddress !== observation.ipAddress) return false;
      const cameraModel = candidate.cameraId ? this.cameras.get(candidate.cameraId)?.model : undefined;
      return recorderModel.test(candidate.model ?? "") || recorderModel.test(cameraModel ?? "");
    });
  }

  private resolveDeviceIdentity(branchId: string, observation: DeviceIdentityObservation) {
    const branch = this.nodes.get(branchId);
    if (!branch) throw new Error("invalid_branch");
    const claims = identityClaims(observation);
    const claimKeys = claims.map((claim) => `${branch.tenantId}:${claim.type}:${claim.value}`);
    let identity = claimKeys
      .map((key) => this.deviceIdentities.get(this.deviceIdentityClaims.get(key) ?? ""))
      .find((candidate): candidate is DeviceIdentity => Boolean(candidate));
    if (!identity && claims.length === 0 && observation.ipAddress) {
      identity = [...this.deviceIdentities.values()].find((candidate) =>
        candidate.branchId === branchId &&
        candidate.deviceType === observation.deviceType &&
        candidate.currentIpAddress === observation.ipAddress &&
        candidate.channel === observation.channel
      );
    }
    identity ??= this.findRecorderPlaceholderIdentity(branchId, observation);

    const observedAt = new Date().toISOString();
    if (!identity) {
      identity = {
        deviceId: randomUUID(),
        tenantId: branch.tenantId,
        branchId,
        deviceType: observation.deviceType,
        ipHistory: [],
        firstSeenAt: observedAt,
        lastSeenAt: observedAt,
      };
      this.deviceIdentities.set(identity.deviceId, identity);
    }

    Object.assign(identity, clean({
      branchId,
      deviceType: observation.deviceType,
      hardwareSerial: observation.hardwareSerial,
      manufacturer: observation.manufacturer,
      model: observation.model,
      firmwareVersion: observation.firmwareVersion,
      macAddress: normalizeMacAddress(observation.macAddress) ?? observation.macAddress,
      currentIpAddress: observation.ipAddress,
      onvifUuid: observation.onvifUuid,
      dvrSerialNumber: observation.dvrSerialNumber,
      channel: observation.channel,
      certificateRef: observation.certificateRef,
      certificateFingerprint: observation.certificateFingerprint,
      credentialRef: observation.credentialRef,
      agentId: observation.agentId,
      lastSeenAt: observedAt,
    }));

    for (const key of claimKeys) {
      const existingIdentityId = this.deviceIdentityClaims.get(key);
      if (!existingIdentityId || existingIdentityId === identity.deviceId) {
        this.deviceIdentityClaims.set(key, identity.deviceId);
      }
    }

    if (observation.ipAddress) {
      const address = identity.ipHistory.find((item) => item.ipAddress === observation.ipAddress);
      if (address) {
        address.lastSeenAt = observedAt;
        address.observationCount += 1;
        if (observation.agentId) address.agentId = observation.agentId;
      } else {
        identity.ipHistory.push({
          ipAddress: observation.ipAddress,
          ...(observation.agentId ? { agentId: observation.agentId } : {}),
          firstSeenAt: observedAt,
          lastSeenAt: observedAt,
          observationCount: 1,
        });
      }
    }

    if (identity.cameraId) {
      const camera = this.cameras.get(identity.cameraId);
      if (camera) {
        Object.assign(camera, clean({
          deviceIdentityId: identity.deviceId,
          edgeAgentId: observation.agentId,
          serialNumber: observation.hardwareSerial,
          macAddress: observation.macAddress,
          firmwareVersion: observation.firmwareVersion,
          ipAddress: observation.ipAddress,
          onvifUuid: observation.onvifUuid,
          certificateRef: observation.certificateRef,
          certificateFingerprint: observation.certificateFingerprint,
          firstSeenAt: identity.firstSeenAt,
          lastSeenAt: identity.lastSeenAt,
        }));
      }
    }
    return identity;
  }

  async createDiscovery(branchId: string, input: CameraDiscoveryInput) {
    const agent = this.edgeAgents.get(input.edgeAgentId);
    if (!agent || agent.branchId !== branchId) throw new Error("invalid_edge_agent");

    const normalized = structuredClone(input);
    normalized.discoveryLayers = [
      ...(normalized.discoveryLayers ?? []),
      { layer: "register", status: "passed", detail: "Control plane registration completed" },
    ];
    const observation = observationFromDiscovery(normalized);
    const recorderPlaceholder = this.findRecorderPlaceholderIdentity(branchId, observation);
    const identity = this.resolveDeviceIdentity(branchId, observation);
    const recorderPlaceholderUpgrade = recorderPlaceholder?.deviceId === identity.deviceId;

    const existing = [...this.discoveries.values()].find((item) => {
      const sameBranch = item.branchId === branchId;
      const sameIp = item.ipAddress === normalized.ipAddress && item.onvifPort === normalized.onvifPort;
      const sameSourceSlot = sameIp && (
        item.recorderChannel === normalized.recorderChannel ||
        (item.recorderChannel === undefined && normalized.recorderChannel === undefined)
      );
      const sameIdentity = item.deviceIdentityId === identity.deviceId;
      if (item.status === "rejected" && sameBranch && (sameSourceSlot || sameIdentity)) {
        return true;
      }
      return sameBranch && (sameIdentity || sameSourceSlot);
    });

    if (existing) {
      if (existing.status === "rejected") {
        return existing;
      }
      Object.assign(existing, normalized, {
        deviceIdentityId: identity.deviceId,
        // A routine rescan of an already-approved physical identity updates
        // its address/firmware evidence without reopening duplicate approval.
        status: existing.status === "approved" ? "approved" as const : "pending" as const,
        ...(recorderPlaceholderUpgrade ? {
          duplicateStatus: normalized.duplicateStatus ?? "unique" as const,
          ...(identity.cameraId ? { existingDeviceAssociation: identity.cameraId } : {}),
          statusReason: "recorder_placeholder_upgrade",
        } : identity.cameraId ? {
          duplicateStatus: "duplicate" as const,
          existingDeviceAssociation: identity.cameraId,
          statusReason: normalized.statusReason ?? "matched_existing_device_identity",
        } : {}),
        discoveredAt: new Date().toISOString(),
      });
      return existing;
    }
    const discovery: DiscoveredCamera = {
      id: randomUUID(),
      deviceIdentityId: identity.deviceId,
      branchId,
      status: "pending", 
      discoveredAt: new Date().toISOString(),
      manufacturer: normalized.manufacturer || normalized.vendor || 'Unknown',
      ...(normalized.displayName ? { displayName: normalized.displayName } : {}),
      ...(normalized.statusReason ? { statusReason: normalized.statusReason } : {}),
      ...(normalized.credentialsRequired !== undefined ? { credentialsRequired: normalized.credentialsRequired } : {}),
      ...(normalized.streamVerified !== undefined ? { streamVerified: normalized.streamVerified } : {}),
      ...(normalized.compatibility ? { compatibility: normalized.compatibility } : {}),
      ...normalized,
      ...(recorderPlaceholderUpgrade ? {
        duplicateStatus: normalized.duplicateStatus ?? "unique",
        ...(identity.cameraId ? { existingDeviceAssociation: identity.cameraId } : {}),
        statusReason: "recorder_placeholder_upgrade",
      } : identity.cameraId ? {
        duplicateStatus: "duplicate",
        existingDeviceAssociation: identity.cameraId,
        statusReason: normalized.statusReason ?? "matched_existing_device_identity",
      } : {}),
    };
    this.discoveries.set(discovery.id, discovery);
    return discovery;
  }

  async listDiscoveredCameras(branchId: string) {
    return [...this.discoveries.values()]
      .filter((discovery) =>
        discovery.branchId === branchId && discovery.status === "pending"
      )
      .sort((left, right) => right.discoveredAt.localeCompare(left.discoveredAt));
  }

  async rejectDiscovery(discoveryId: string, reason?: string) {
    const discovery = this.discoveries.get(discoveryId);
    if (!discovery) return undefined;
    discovery.status = "rejected";
    if (reason) discovery.statusReason = reason;
    return discovery;
  }

  async renameDiscovery(discoveryId: string, displayName: string) {
    const discovery = this.discoveries.get(discoveryId);
    if (!discovery) return undefined;
    discovery.displayName = displayName;
    return discovery;
  }

  async approveCamera(branchId: string, input: CameraApprovalInput) {
    const discovery = this.discoveries.get(input.discoveryId);
    const branch = this.nodes.get(branchId);
    if (!discovery || discovery.branchId !== branchId || !branch) return undefined;
    let identity: DeviceIdentity | undefined = discovery.deviceIdentityId ? this.deviceIdentities.get(discovery.deviceIdentityId) : undefined;
    if (!identity) {
      const identityId = randomUUID();
      const newIdentity: DeviceIdentity = {
        id: identityId,
        deviceId: identityId,
        branchId,
        tenantId: branch.tenantId,
        serialNumber: input.serialNumber || discovery.serialNumber,
        macAddress: input.macAddress || discovery.macAddress,
        firstSeenAt: new Date().toISOString(),
        lastSeenAt: new Date().toISOString(),
      } as any;
      this.deviceIdentities.set(identityId, newIdentity);
      discovery.deviceIdentityId = identityId;
      identity = newIdentity;
    }
    const resolvedIdentity: DeviceIdentity = identity;
    if (resolvedIdentity.cameraId) {
      const existingCamera = this.cameras.get(resolvedIdentity.cameraId);
      if (!existingCamera) throw new Error("identity_camera_not_found");
      Object.assign(existingCamera, clean({
        edgeAgentId: discovery.edgeAgentId,
        vendor: discovery.vendor,
        model: discovery.model,
        channel: input.channel,
        protocol: input.protocol,
        profiles: structuredClone(discovery.profiles),
        capabilities: structuredClone(discovery.capabilities),
        connectionTransport: input.connectionTransport,
        ipAddress: input.ipAddress ?? discovery.ipAddress,
        sourceType: input.sourceType ?? discovery.sourceType ?? "ip-camera",
        recorderId: input.recorderId ?? discovery.recorderId,
        recorderChannel: input.recorderChannel ?? discovery.recorderChannel,
        recorderSerialNumber: input.recorderSerialNumber ?? discovery.recorderSerialNumber,
        serialNumber: input.serialNumber ?? discovery.serialNumber,
        macAddress: input.macAddress ?? discovery.macAddress,
        firmwareVersion: discovery.firmwareVersion,
        onvifUuid: input.onvifUuid ?? discovery.onvifUuid,
        certificateRef: input.certificateRef ?? discovery.certificateRef,
        certificateFingerprint: input.certificateFingerprint ?? discovery.certificateFingerprint,
        lastSeenAt: resolvedIdentity.lastSeenAt,
      }));
      existingCamera.connectionSecretRef = input.connectionSecretRef;
      resolvedIdentity.credentialRef = input.connectionSecretRef;
      discovery.status = "approved";
      return existingCamera;
    }
    const nodeId = randomUUID();
    this.nodes.set(nodeId, {
      id: nodeId, tenantId: branch.tenantId, parentId: branchId, type: "camera",
      name: input.name, path: [...branch.path, nodeId],
    });
    const camera: Camera = {
      id: randomUUID(), deviceIdentityId: resolvedIdentity.deviceId,
      name: input.name, nodeId, branchId, vendor: discovery.vendor,
      model: discovery.model, channel: input.channel, protocol: input.protocol,
      status: "unknown", profiles: discovery.profiles,
      capabilities: discovery.capabilities,
      edgeAgentId: discovery.edgeAgentId,
      connectionSecretRef: input.connectionSecretRef,
      sourceType: input.sourceType ?? discovery.sourceType ?? "ip-camera",
      connectionTransport: input.connectionTransport,
      recorderId: input.recorderId ?? discovery.recorderId,
      recorderChannel: input.recorderChannel ?? discovery.recorderChannel,
      recorderSerialNumber: input.recorderSerialNumber ?? discovery.recorderSerialNumber,
      serialNumber: input.serialNumber ?? discovery.serialNumber,
      macAddress: input.macAddress ?? discovery.macAddress,
      firmwareVersion: discovery.firmwareVersion,
      ipAddress: input.ipAddress ?? discovery.ipAddress,
      onvifUuid: input.onvifUuid ?? discovery.onvifUuid,
      certificateRef: input.certificateRef ?? discovery.certificateRef,
      certificateFingerprint: input.certificateFingerprint ?? discovery.certificateFingerprint,
      firstSeenAt: resolvedIdentity.firstSeenAt,
      lastSeenAt: resolvedIdentity.lastSeenAt,
    };
    discovery.status = "approved";
    this.cameras.set(camera.id, camera);
    resolvedIdentity.cameraId = camera.id;
    resolvedIdentity.credentialRef = input.connectionSecretRef;
    return camera;
  }

  async replaceRecorderChannels(input: {
    branchId: string;
    oldRecorderSerialNumber: string;
    newRecorderSerialNumber: string;
    mappings: Array<{ cameraId: string; discoveryId: string; sourceChannel: number }>;
    actorUserId: string;
  }): Promise<RecorderReplacementResult> {
    const oldSerial = input.oldRecorderSerialNumber.trim().toUpperCase();
    const newSerial = input.newRecorderSerialNumber.trim().toUpperCase();
    if (!oldSerial || !newSerial || oldSerial === newSerial) throw new Error("invalid_recorder_replacement");
    if (input.mappings.length === 0) throw new Error("recorder_replacement_has_no_channels");

    const resolved = input.mappings.map((mapping) => {
      const camera = this.cameras.get(mapping.cameraId);
      const discovery = this.discoveries.get(mapping.discoveryId);
      const valid = camera?.branchId === input.branchId &&
        camera.recorderSerialNumber?.trim().toUpperCase() === oldSerial &&
        camera.recorderChannel === mapping.sourceChannel &&
        discovery?.branchId === input.branchId && discovery.status === "pending" &&
        discovery.recorderSerialNumber?.trim().toUpperCase() === newSerial &&
        discovery.recorderChannel === mapping.sourceChannel &&
        discovery.streamVerified === true && discovery.credentialsRequired !== true;
      if (!camera || !discovery || !valid) throw new Error("recorder_replacement_mapping_changed");
      return { camera, discovery };
    });
    if (new Set(input.mappings.map((item) => item.cameraId)).size !== input.mappings.length ||
        new Set(input.mappings.map((item) => item.discoveryId)).size !== input.mappings.length) {
      throw new Error("duplicate_recorder_replacement_mapping");
    }

    for (const { camera, discovery } of resolved) {
      const targetIdentity = camera.deviceIdentityId
        ? this.deviceIdentities.get(camera.deviceIdentityId)
        : undefined;
      const replacementIdentity = this.deviceIdentities.get(discovery.deviceIdentityId);
      if (targetIdentity && replacementIdentity && targetIdentity.deviceId !== replacementIdentity.deviceId) {
        for (const [claim, identityId] of this.deviceIdentityClaims) {
          if (identityId === replacementIdentity.deviceId) {
            this.deviceIdentityClaims.set(claim, targetIdentity.deviceId);
          }
        }
        for (const address of replacementIdentity.ipHistory) {
          const existingAddress = targetIdentity.ipHistory.find((item) => item.ipAddress === address.ipAddress);
          if (existingAddress) {
            existingAddress.lastSeenAt = address.lastSeenAt;
            existingAddress.observationCount += address.observationCount;
          } else {
            targetIdentity.ipHistory.push(structuredClone(address));
          }
        }
        Object.assign(targetIdentity, {
          dvrSerialNumber: discovery.recorderSerialNumber,
          channel: discovery.recorderChannel,
          currentIpAddress: discovery.ipAddress,
          firmwareVersion: discovery.firmwareVersion ?? targetIdentity.firmwareVersion,
          agentId: discovery.edgeAgentId,
          lastSeenAt: replacementIdentity.lastSeenAt,
        });
        discovery.deviceIdentityId = targetIdentity.deviceId;
        this.deviceIdentities.delete(replacementIdentity.deviceId);
      }
      Object.assign(camera, {
        edgeAgentId: discovery.edgeAgentId,
        vendor: discovery.vendor,
        model: discovery.model,
        protocol: "vendor-adapter" as const,
        status: "unknown" as const,
        profiles: structuredClone(discovery.profiles),
        capabilities: structuredClone(discovery.capabilities),
        connectionSecretRef: `edge://${discovery.edgeAgentId}/${discovery.id}`,
        sourceType: discovery.sourceType ?? camera.sourceType,
        recorderId: discovery.recorderId,
        recorderChannel: discovery.recorderChannel,
        recorderSerialNumber: discovery.recorderSerialNumber,
        firmwareVersion: discovery.firmwareVersion,
        ipAddress: discovery.ipAddress,
      });
      discovery.status = "approved";
      discovery.duplicateStatus = "duplicate";
      discovery.existingDeviceAssociation = camera.id;
      discovery.statusReason = `replacement_for:${oldSerial}`;
    }

    return {
      replacementId: randomUUID(), branchId: input.branchId,
      oldRecorderSerialNumber: oldSerial, newRecorderSerialNumber: newSerial,
      updatedCameraIds: resolved.map(({ camera }) => camera.id),
      preserved: ["camera-ids", "names", "permissions", "recording-history", "recording-policy", "analytics-rules", "alert-rules"],
      appliedAt: new Date().toISOString(),
    };
  }

  async createCameraFromManualRegistration(branchId: string, input: CameraApprovalInput) {
    const branch = this.nodes.get(branchId);
    if (!branch) return undefined;
    const identity = this.resolveDeviceIdentity(branchId, observationFromApproval(input));
    if (identity.cameraId) {
      const existingCamera = this.cameras.get(identity.cameraId);
      if (!existingCamera) return undefined;
      existingCamera.connectionSecretRef = input.connectionSecretRef;
      existingCamera.connectionTransport = input.connectionTransport ?? existingCamera.connectionTransport;
      if (input.profile) existingCamera.profiles = [structuredClone(input.profile)];
      identity.credentialRef = input.connectionSecretRef;
      return existingCamera;
    }
    const nodeId = randomUUID();
    this.nodes.set(nodeId, {
      id: nodeId, tenantId: branch.tenantId, parentId: branchId, type: "camera",
      name: input.name, path: [...branch.path, nodeId],
    });
    const camera: Camera = {
      id: randomUUID(), deviceIdentityId: identity.deviceId,
      name: input.name, nodeId, branchId,
      vendor: (input.manufacturer?.toLowerCase() === "hikvision" ? "hikvision" : "other") as Camera["vendor"],
      model: input.model ?? "manual",
      channel: input.channel,
      protocol: input.protocol,
      status: "unknown",
      profiles: [structuredClone(input.profile ?? {
        name: input.streamProfile ?? "main", codec: "H264", width: 1920, height: 1080,
        role: input.streamProfile === "sub" ? "sub" : "main",
      })],
      capabilities: { ptz: false, audio: false, events: true },
      edgeAgentId: undefined,
      connectionSecretRef: input.connectionSecretRef,
      connectionTransport: input.connectionTransport,
      sourceType: input.sourceType ?? "ip-camera",
      recorderId: input.recorderId,
      recorderChannel: input.recorderChannel,
      recorderSerialNumber: input.recorderSerialNumber,
      serialNumber: input.serialNumber,
      macAddress: input.macAddress,
      ipAddress: input.ipAddress,
      firmwareVersion: undefined,
      onvifUuid: input.onvifUuid,
      certificateRef: input.certificateRef,
      certificateFingerprint: input.certificateFingerprint,
      firstSeenAt: identity.firstSeenAt,
      lastSeenAt: identity.lastSeenAt,
    };
    this.cameras.set(camera.id, camera);
    identity.cameraId = camera.id;
    identity.credentialRef = input.connectionSecretRef;
    return camera;
  }

  async updateCameraStatus(id: string, status: CameraStatus) {
    const camera = this.cameras.get(id);
    if (!camera) return undefined;
    camera.status = status;
    return camera;
  }

  async createLiveSession(cameraId: string, userId: string, purpose: "view" | "talk" = "view"): Promise<LiveSession> {
    const camera = this.cameras.get(cameraId);
    const mediaGatewayUrl = camera?.edgeAgentId
      ? this.edgeAgents.get(camera.edgeAgentId)?.publicMediaUrl
      : undefined;
    const localMediaGatewayUrl = camera?.edgeAgentId
      ? this.edgeAgents.get(camera.edgeAgentId)?.localMediaUrl
      : undefined;
    const session = {
      id: randomUUID(), cameraId, userId,
      token: randomBytes(32).toString("base64url"),
      expiresAt: new Date(Date.now() + 60_000).toISOString(),
      purpose,
      ...(mediaGatewayUrl ? { mediaGatewayUrl } : {}),
      ...(localMediaGatewayUrl ? { localMediaGatewayUrl } : {}),
    };
    this.liveSessions.set(session.id, {
      ...session,
      tokenHash: hashToken(session.token),
      consumed: false,
    });
    return session;
  }

  async consumeLiveSession(token: string): Promise<ConsumedLiveSession | undefined> {
    const tokenHash = hashToken(token);
    const session = [...this.liveSessions.values()].find(
      (item) =>
        item.tokenHash === tokenHash &&
        !item.consumed &&
        Date.parse(item.expiresAt) > Date.now(),
    );
    if (!session) return undefined;
    const camera = this.cameras.get(session.cameraId);
    const user = this.users.get(session.userId);
    if (!camera || !user) return undefined;
    session.consumed = true;
    return {
      id: session.id,
      cameraId: camera.id,
      cameraNodeId: camera.nodeId,
      userId: user.id,
      tenantId: user.tenantId,
      connectionSecretRef: camera.connectionSecretRef,
      profiles: camera.profiles,
      purpose: session.purpose ?? "view",
      vendor: camera.vendor,
      model: camera.model,
      protocol: camera.protocol,
      ...(camera.sourceType ? { sourceType: camera.sourceType } : {}),
      channel: camera.channel,
      ...(camera.recorderChannel !== undefined ? { recorderChannel: camera.recorderChannel } : {}),
      capabilities: camera.capabilities,
    };
  }

  async getRecordingJob(cameraId: string) {
    return this.recordingJobs.get(cameraId);
  }

  async listOperationalTelemetryHistory(
    tenant: string,
    branchId: string,
    from: string,
    to: string,
    limit = 1000,
  ) {
    const start = Date.parse(from);
    const end = Date.parse(to);
    return this.operationalTelemetryHistory
      .filter((item) => item.tenantId === tenant && item.branchId === branchId)
      .filter((item) => {
        const observed = Date.parse(item.observedAt);
        return observed >= start && observed <= end;
      })
      .sort((left, right) => Date.parse(left.observedAt) - Date.parse(right.observedAt))
      .slice(-limit)
      .map((item) => structuredClone(item));
  }

  async listRecordingJobs(cameraIds: string[]) {
    const requested = new Set(cameraIds);
    return [...this.recordingJobs.values()].filter((job) => requested.has(job.cameraId));
  }

  async upsertRecordingJob(cameraId: string, input: Omit<RecordingJob, "id" | "cameraId" | "updatedAt">) {
    const existing = this.recordingJobs.get(cameraId);
    const job: RecordingJob = {
      id: existing?.id ?? randomUUID(), cameraId, ...structuredClone(input),
      updatedAt: new Date().toISOString(),
    };
    this.recordingJobs.set(cameraId, job);
    return job;
  }

  async listRecordingSegments(cameraId: string, from?: string, to?: string) {
    return this.recordingSegments.filter((segment) => segment.cameraId === cameraId &&
      (!from || segment.endedAt >= from) && (!to || segment.startedAt <= to));
  }

  async listRecordingSegmentsForCameras(cameraIds: string[], from?: string, to?: string) {
    const requested = new Set(cameraIds);
    return this.recordingSegments.filter((segment) => requested.has(segment.cameraId)
      && segment.status !== "deleted"
      && (!from || segment.endedAt >= from) && (!to || segment.startedAt <= to));
  }

  async getRecordingSegment(id: string) {
    return this.recordingSegments.find((segment) => segment.id === id);
  }

  async createRecordingSegment(input: Omit<RecordingSegment, "id" | "createdAt">) {
    const existing = this.recordingSegments.find((item) =>
      item.cameraId === input.cameraId && item.storagePath === input.storagePath
    );
    if (existing) {
      Object.assign(existing, structuredClone(input));
      return existing;
    }
    const segment: RecordingSegment = {
      id: randomUUID(), ...structuredClone(input), createdAt: new Date().toISOString(),
    };
    this.recordingSegments.push(segment);
    return segment;
  }

  async updateRecordingJobStatus(cameraId: string, status: RecordingJob["status"]) {
    const job = this.recordingJobs.get(cameraId);
    if (!job) return undefined;
    job.status = status;
    job.updatedAt = new Date().toISOString();
    return job;
  }

  async listRecordingLegalHolds(cameraId: string) {
    return this.recordingLegalHolds.filter((hold) => hold.cameraId === cameraId);
  }

  async createRecordingLegalHold(input: {
    tenantId: string; cameraId: string; fromAt: string; toAt: string;
    reason: string; createdBy: string;
  }) {
    const hold: RecordingLegalHold = {
      id: randomUUID(), ...structuredClone(input), createdAt: new Date().toISOString(),
    };
    this.recordingLegalHolds.push(hold);
    return hold;
  }

  async releaseRecordingLegalHold(
    id: string,
    inputTenantId: string,
    cameraId: string,
    releasedBy: string,
  ) {
    const hold = this.recordingLegalHolds.find((item) =>
      item.id === id && item.tenantId === inputTenantId &&
      item.cameraId === cameraId && !item.releasedAt
    );
    if (!hold) return undefined;
    hold.releasedBy = releasedBy;
    hold.releasedAt = new Date().toISOString();
    return hold;
  }

  async upsertRecordingStorageNode(input: {
    tenantId: string; externalId: string; name: string;
    scopeNodeId?: string | undefined;
    supportedTiers: Array<"hot" | "warm" | "cold">;
    capacityBytes: number; usedBytes: number; availableBytes: number;
    status: "healthy" | "warning" | "critical" | "offline";
    storageType?: "local-disk" | "nfs" | "smb" | "s3" | "cloud-archive" | "san";
    supportedProtocols?: string[];
    location?: string;
    mountPath?: string;
    temperatureCelsius?: number | undefined; writeMbps?: number | undefined;
    readMbps?: number | undefined; latencyMs?: number | undefined;
    smart?: any;
    raid?: any;
    lastWriteProbe?: any;
  }) {
    const key = `${input.tenantId}:${input.externalId}`;
    const existing = this.recordingStorageNodes.get(key);
    const node: RecordingStorageNode = {
      id: existing?.id ?? randomUUID(), ...structuredClone(input),
      lastSeenAt: new Date().toISOString(),
    };
    this.recordingStorageNodes.set(key, node);
    return node;
  }

  async listRecordingStorageNodes(tenantId: string) {
    return [...this.recordingStorageNodes.values()].filter(
      (node) => node.tenantId === tenantId,
    );
  }

  async createRecordingHealthEvent(input: {
    tenantId: string; cameraId?: string | undefined;
    storageNodeExternalId?: string | undefined; eventType: string;
    severity: "info" | "warning" | "critical"; message: string;
    details?: Record<string, unknown> | undefined;
  }) {
    const event: RecordingHealthEvent = {
      id: randomUUID(), ...structuredClone(input), details: input.details ?? {},
      occurredAt: new Date().toISOString(),
    };
    this.recordingHealthEvents.push(event);
    return event;
  }

  async listRecordingHealthEvents(cameraId: string, limit: number) {
    return this.recordingHealthEvents
      .filter((event) => event.cameraId === cameraId)
      .sort((left, right) => right.occurredAt.localeCompare(left.occurredAt))
      .slice(0, limit);
  }

  private findApplicableCompliancePolicy(camera: Camera, node: ResourceNode) {
    const policies = this.compliancePolicies.filter((policy) => policy.tenantId === node.tenantId)
      .filter((policy) => {
        if (policy.entityType) {
          const matchesEntityType = node.path.some((nodeId) =>
            this.nodes.get(nodeId)?.type === policy.entityType,
          );
          if (!matchesEntityType) return false;
        }
        if (policy.locationType && policy.locationType !== camera.locationType) return false;
        if (policy.cameraType && policy.cameraType !== camera.physicalType) return false;
        return true;
      });
    policies.sort((left, right) => {
      const leftScore = Number(Boolean(left.entityType)) + Number(Boolean(left.locationType)) + Number(Boolean(left.cameraType));
      const rightScore = Number(Boolean(right.entityType)) + Number(Boolean(right.locationType)) + Number(Boolean(right.cameraType));
      if (leftScore !== rightScore) return rightScore - leftScore;
      return (right.updatedAt ?? right.createdAt).localeCompare(left.updatedAt ?? left.createdAt);
    });
    return policies[0];
  }

  private getPolicyRetentionDays(
    job: RecordingJob,
    policy: { normalRetentionDays?: number; hotStorageDays?: number; warmStorageDays?: number; coldStorageDays?: number } | undefined,
    storageTier: RecordingSegment["storageTier"],
  ) {
    const defaultTierDays = storageTier === "hot"
      ? job.hotRetentionDays
      : storageTier === "warm"
        ? job.warmRetentionDays
        : storageTier === "cold"
          ? job.coldRetentionDays
          : job.retentionDays;
    const policyTierDays = storageTier === "hot"
      ? policy?.hotStorageDays
      : storageTier === "warm"
        ? policy?.warmStorageDays
        : storageTier === "cold"
          ? policy?.coldStorageDays
          : undefined;
    return policyTierDays ?? policy?.normalRetentionDays ?? defaultTierDays;
  }

  private overlapsTimeRange(
    segment: RecordingSegment,
    range: { fromAt: string; toAt: string },
  ) {
    return range.fromAt < segment.endedAt && range.toAt > segment.startedAt;
  }

  async listRecordingRetentionCandidates(
    inputTenantId: string,
    storageNodeExternalId: string,
    limit: number,
  ) {
    const now = Date.now();
    return this.recordingSegments.filter((segment) => {
      const camera = this.cameras.get(segment.cameraId);
      const node = camera ? this.nodes.get(camera.nodeId) : undefined;
      const job = this.recordingJobs.get(segment.cameraId);
      if (!camera || !node || node.tenantId !== inputTenantId || !job ||
          !job.automaticDeletionEnabled || segment.status !== "ready" ||
          segment.storageNodeExternalId !== storageNodeExternalId) return false;
      const policy = this.findApplicableCompliancePolicy(camera, node);
      if (policy?.automaticDeletionEligibility === false) return false;
      if (job.backupRequired || policy?.backupRequired) return false;
      const baseRetentionDays = this.getPolicyRetentionDays(job, policy, segment.storageTier);
      const incidentRetentionDays = policy?.incidentRetentionDays ?? 0;
      const hasIncidentOverlap = incidentRetentionDays > 0 && this.incidentVideoRanges.some((range) =>
        range.cameraId === segment.cameraId && this.overlapsTimeRange(segment, range),
      );
      const retentionDays = hasIncidentOverlap
        ? Math.max(baseRetentionDays, incidentRetentionDays)
        : baseRetentionDays;
      if (Date.parse(segment.endedAt) >= now - retentionDays * 86_400_000) return false;
      const activeLegalHold = this.recordingLegalHolds.some((hold) =>
        hold.cameraId === segment.cameraId && !hold.releasedAt &&
        hold.fromAt < segment.endedAt && hold.toAt > segment.startedAt,
      );
      if (activeLegalHold && !policy?.legalHoldOverride) return false;
      return true;
    }).slice(0, limit);
  }

  async markRecordingSegmentsDeleted(
    inputTenantId: string,
    storageNodeExternalId: string,
    segmentIds: string[],
  ) {
    let updated = 0;
    for (const segment of this.recordingSegments) {
      const camera = this.cameras.get(segment.cameraId);
      const node = camera ? this.nodes.get(camera.nodeId) : undefined;
      if (node?.tenantId === inputTenantId &&
          segment.storageNodeExternalId === storageNodeExternalId &&
          segmentIds.includes(segment.id) && segment.status !== "deleted") {
        segment.status = "deleted";
        updated += 1;
      }
    }
    return updated;
  }

  async listLiveBookmarks(cameraId: string, limit: number) {
    return this.liveBookmarks
      .filter((bookmark) => bookmark.cameraId === cameraId)
      .sort((left, right) => right.bookmarkedAt.localeCompare(left.bookmarkedAt))
      .slice(0, limit);
  }

  async createLiveBookmark(
    input: Parameters<ControlPlaneStore["createLiveBookmark"]>[0],
  ) {
    if (!this.cameras.has(input.cameraId)) throw new Error("camera_not_found");
    const bookmark: LiveBookmark = {
      id: randomUUID(),
      tenantId: input.tenantId,
      cameraId: input.cameraId,
      operatorId: input.operatorId,
      bookmarkedAt: input.bookmarkedAt,
      reason: input.reason,
      priority: input.priority,
      ...(input.notes ? { notes: input.notes } : {}),
      ...(input.recordingSegmentId
        ? { recordingSegmentId: input.recordingSegmentId }
        : {}),
      ...(input.snapshotReference
        ? { snapshotReference: input.snapshotReference }
        : {}),
      createdAt: new Date().toISOString(),
    };
    this.liveBookmarks.push(bookmark);
    return bookmark;
  }

  async listLiveIncidents(cameraId: string, limit: number) {
    return this.liveIncidents
      .filter((incident) => incident.cameraId === cameraId)
      .sort((left, right) => right.occurredAt.localeCompare(left.occurredAt))
      .slice(0, limit);
  }

  async createLiveIncident(
    input: Parameters<ControlPlaneStore["createLiveIncident"]>[0],
  ) {
    if (!this.cameras.has(input.cameraId)) throw new Error("camera_not_found");
    const occurredAt = new Date(input.occurredAt);
    const recordingFrom = new Date(
      occurredAt.getTime() - input.preRollSeconds * 1000,
    ).toISOString();
    const recordingTo = new Date(
      occurredAt.getTime() + input.postRollSeconds * 1000,
    ).toISOString();
    const incidentId = randomUUID();
    const legalHoldId = randomUUID();
    const bookmarkId = randomUUID();
    const now = new Date().toISOString();
    const bookmark: LiveBookmark = {
      id: bookmarkId,
      tenantId: input.tenantId,
      cameraId: input.cameraId,
      operatorId: input.createdBy,
      bookmarkedAt: input.occurredAt,
      reason: "suspicious-activity",
      priority: input.priority === "P1" ? "critical"
        : input.priority === "P2" ? "high"
        : input.priority === "P3" ? "medium" : "low",
      incidentId,
      ...(input.notes ? { notes: input.notes } : {}),
      createdAt: now,
    };
    const incident: LiveIncident = {
      id: incidentId,
      tenantId: input.tenantId,
      cameraId: input.cameraId,
      createdBy: input.createdBy,
      title: input.title,
      ...(input.notes ? { notes: input.notes } : {}),
      priority: input.priority,
      status: "new",
      occurredAt: input.occurredAt,
      recordingFrom,
      recordingTo,
      preRollSeconds: input.preRollSeconds,
      postRollSeconds: input.postRollSeconds,
      bookmarkId,
      legalHoldId,
      createdAt: now,
      updatedAt: now,
    };
    this.recordingLegalHolds.push({
      id: legalHoldId,
      tenantId: input.tenantId,
      cameraId: input.cameraId,
      fromAt: recordingFrom,
      toAt: recordingTo,
      reason: `Live incident ${input.priority}: ${input.title}`,
      createdBy: input.createdBy,
      createdAt: now,
    });
    this.liveBookmarks.push(bookmark);
    this.liveIncidents.push(incident);
    return incident;
  }

  // Incident management (investigation) - Use mixin methods
  createIncident = IncidentManagementMethods.createIncident;
  getIncident = IncidentManagementMethods.getIncident;
  listIncidents = IncidentManagementMethods.listIncidents;
  updateIncident = IncidentManagementMethods.updateIncident;
  updateIncidentStatus = IncidentManagementMethods.updateIncidentStatus;
  assignIncident = IncidentManagementMethods.assignIncident;
  escalateIncident = IncidentManagementMethods.escalateIncident;
  closeIncident = IncidentManagementMethods.closeIncident;
  reopenIncident = IncidentManagementMethods.reopenIncident;
  addIncidentParticipant = IncidentManagementMethods.addIncidentParticipant;
  listIncidentParticipants = IncidentManagementMethods.listIncidentParticipants;
  updateIncidentParticipant = IncidentManagementMethods.updateIncidentParticipant;
  removeIncidentParticipant = IncidentManagementMethods.removeIncidentParticipant;
  addIncidentCamera = IncidentManagementMethods.addIncidentCamera;
  listIncidentCameras = IncidentManagementMethods.listIncidentCameras;
  addIncidentVideoRange = IncidentManagementMethods.addIncidentVideoRange;
  listIncidentVideoRanges = IncidentManagementMethods.listIncidentVideoRanges;
  preserveIncidentVideoAutomatic = IncidentManagementMethods.preserveIncidentVideoAutomatic;
  listIncidentTimeline = IncidentManagementMethods.listIncidentTimeline;
  addIncidentEvent = IncidentManagementMethods.addIncidentEvent;
  createIncidentClip = IncidentManagementMethods.createIncidentClip;
  listIncidentClips = IncidentManagementMethods.listIncidentClips;
  getIncidentClip = IncidentManagementMethods.getIncidentClip;
  createIncidentSnapshot = IncidentManagementMethods.createIncidentSnapshot;
  listIncidentSnapshots = IncidentManagementMethods.listIncidentSnapshots;
  getIncidentSnapshot = IncidentManagementMethods.getIncidentSnapshot;
  addIncidentEvidenceItem = IncidentManagementMethods.addIncidentEvidenceItem;
  listIncidentEvidenceItems = IncidentManagementMethods.listIncidentEvidenceItems;
  createIncidentEvidencePackage = IncidentManagementMethods.createIncidentEvidencePackage;
  listIncidentEvidencePackages = IncidentManagementMethods.listIncidentEvidencePackages;
  getIncidentEvidencePackage = IncidentManagementMethods.getIncidentEvidencePackage;
  approveEvidencePackage = IncidentManagementMethods.approveEvidencePackage;
  updateEvidencePackageStatus = IncidentManagementMethods.updateEvidencePackageStatus;
  recordEvidencePackageDownload = IncidentManagementMethods.recordEvidencePackageDownload;
  createPoliceIntimation = IncidentManagementMethods.createPoliceIntimation;
  listPoliceIntimations = IncidentManagementMethods.listPoliceIntimations;
  getPoliceIntimation = IncidentManagementMethods.getPoliceIntimation;
  updatePoliceIntimation = IncidentManagementMethods.updatePoliceIntimation;
  recordPoliceEvidenceTransfer = IncidentManagementMethods.recordPoliceEvidenceTransfer;
  listPoliceEvidenceTransfers = IncidentManagementMethods.listPoliceEvidenceTransfers;
  createInsuranceClaim = IncidentManagementMethods.createInsuranceClaim;
  listInsuranceClaims = IncidentManagementMethods.listInsuranceClaims;
  getInsuranceClaim = IncidentManagementMethods.getInsuranceClaim;
  updateInsuranceClaim = IncidentManagementMethods.updateInsuranceClaim;
  addInsuranceDocument = IncidentManagementMethods.addInsuranceDocument;
  listInsuranceDocuments = IncidentManagementMethods.listInsuranceDocuments;
  createIncidentTask = IncidentManagementMethods.createIncidentTask;
  listIncidentTasks = IncidentManagementMethods.listIncidentTasks;
  updateIncidentTask = IncidentManagementMethods.updateIncidentTask;
  completeIncidentTask = IncidentManagementMethods.completeIncidentTask;
  addIncidentNote = IncidentManagementMethods.addIncidentNote;
  listIncidentNotes = IncidentManagementMethods.listIncidentNotes;
  updateIncidentNote = IncidentManagementMethods.updateIncidentNote;
  deleteIncidentNote = IncidentManagementMethods.deleteIncidentNote;
  createSecureShare = IncidentManagementMethods.createSecureShare;
  listSecureShares = IncidentManagementMethods.listSecureShares;
  getSecureShare = IncidentManagementMethods.getSecureShare;
  getSecureShareByToken = IncidentManagementMethods.getSecureShareByToken;
  verifySecureShareAccess = IncidentManagementMethods.verifySecureShareAccess;
  recordSecureShareDownload = IncidentManagementMethods.recordSecureShareDownload;
  revokeSecureShare = IncidentManagementMethods.revokeSecureShare;
  createIncidentReport = IncidentManagementMethods.createIncidentReport;
  listIncidentReports = IncidentManagementMethods.listIncidentReports;
  getIncidentReport = IncidentManagementMethods.getIncidentReport;
  updateIncidentReport = IncidentManagementMethods.updateIncidentReport;
  reviewIncidentReport = IncidentManagementMethods.reviewIncidentReport;
  approveIncidentReport = IncidentManagementMethods.approveIncidentReport;
  finalizeIncidentReport = IncidentManagementMethods.finalizeIncidentReport;
  getIncidentsDashboard = IncidentManagementMethods.getIncidentsDashboard;
  getIncidentStatistics = IncidentManagementMethods.getIncidentStatistics;

  async listComplianceFrameworks(tenantId: string) {
    return this.complianceFrameworks.filter((framework) => framework.tenantId === tenantId);
  }

  async getComplianceFramework(id: string) {
    return this.complianceFrameworks.find((framework) => framework.id === id);
  }

  async createComplianceFramework(input: Parameters<ControlPlaneStore["createComplianceFramework"]>[0]) {
    const now = new Date().toISOString();
    const framework: ComplianceFramework = {
      id: randomUUID(),
      tenantId: input.tenantId,
      name: input.name ?? "",
      status: input.status ?? "active",
      createdAt: now,
      updatedAt: now,
      ...(clean({ source: input.source, description: input.description, effectiveDate: input.effectiveDate, reviewDate: input.reviewDate, createdBy: input.createdBy }) as any),
    };
    this.complianceFrameworks.push(framework);
    return framework;
  }

  async updateComplianceFramework(id: string, input: Parameters<ControlPlaneStore["updateComplianceFramework"]>[1]) {
    const framework = this.complianceFrameworks.find((item) => item.id === id);
    if (!framework) return undefined;
    Object.assign(framework, {
      ...input,
      updatedAt: new Date().toISOString(),
    });
    return framework;
  }

  async listCompliancePolicies(tenantId: string, frameworkId?: string) {
    return this.compliancePolicies.filter((policy) =>
      policy.tenantId === tenantId && (!frameworkId || policy.frameworkId === frameworkId),
    );
  }

  async getCompliancePolicy(id: string) {
    return this.compliancePolicies.find((policy) => policy.id === id);
  }

  async createCompliancePolicy(input: Parameters<ControlPlaneStore["createCompliancePolicy"]>[0]) {
    const now = new Date().toISOString();
    const policy: CompliancePolicy = {
      id: randomUUID(),
      tenantId: input.tenantId,
      frameworkId: input.frameworkId,
      policyName: input.policyName ?? "",
      backupRequired: input.backupRequired ?? false,
      legalHoldOverride: input.legalHoldOverride ?? false,
      automaticDeletionEligibility: input.automaticDeletionEligibility ?? true,
      createdAt: now,
      updatedAt: now,
      ...(clean({ policyBasis: input.policyBasis, entityType: input.entityType, locationType: input.locationType, cameraType: input.cameraType, normalRetentionDays: input.normalRetentionDays, hotStorageDays: input.hotStorageDays, warmStorageDays: input.warmStorageDays, coldStorageDays: input.coldStorageDays, incidentRetentionDays: input.incidentRetentionDays, approvalAuthority: input.approvalAuthority, effectiveDate: input.effectiveDate, reviewDate: input.reviewDate, notes: input.notes, createdBy: input.createdBy }) as any),
    };
    this.compliancePolicies.push(policy);
    return policy;
  }

  async updateCompliancePolicy(id: string, input: Parameters<ControlPlaneStore["updateCompliancePolicy"]>[1]) {
    const policy = this.compliancePolicies.find((item) => item.id === id);
    if (!policy) return undefined;
    Object.assign(policy, {
      ...input,
      updatedAt: new Date().toISOString(),
    });
    return policy;
  }

  async listComplianceAssessments(tenantId: string, filters?: ComplianceAssessmentFilters) {
    return this.complianceAssessments.filter((assessment) => {
      if (assessment.tenantId !== tenantId) return false;
      if (filters?.frameworkId && assessment.frameworkId !== filters.frameworkId) return false;
      if (filters?.branchNodeId && assessment.branchNodeId !== filters.branchNodeId) return false;
      if (filters?.status && assessment.status !== filters.status) return false;
      return true;
    });
  }

  async getComplianceAssessment(id: string) {
    return this.complianceAssessments.find((assessment) => assessment.id === id);
  }

  async createComplianceAssessment(input: Parameters<ControlPlaneStore["createComplianceAssessment"]>[0]) {
    const now = new Date().toISOString();
    const assessment: ComplianceAssessment = {
      id: randomUUID(),
      tenantId: input.tenantId,
      frameworkId: input.frameworkId,
      status: input.status ?? "incomplete",
      createdAt: now,
      updatedAt: now,
      ...(clean({ branchNodeId: input.branchNodeId, assessmentPeriodStart: input.assessmentPeriodStart, assessmentPeriodEnd: input.assessmentPeriodEnd, summary: input.summary, evidence: input.evidence, createdBy: input.createdBy }) as any),
    };
    this.complianceAssessments.push(assessment);
    return assessment;
  }

  async updateComplianceAssessment(id: string, input: Parameters<ControlPlaneStore["updateComplianceAssessment"]>[1]) {
    const assessment = this.complianceAssessments.find((item) => item.id === id);
    if (!assessment) return undefined;
    Object.assign(assessment, {
      ...input,
      updatedAt: new Date().toISOString(),
    });
    return assessment;
  }

  async listComplianceCertificates(assessmentId: string) {
    return this.complianceCertificates.filter((certificate) => certificate.assessmentId === assessmentId);
  }

  async getComplianceCertificate(id: string) {
    return this.complianceCertificates.find((certificate) => certificate.id === id);
  }

  async createComplianceCertificate(input: Parameters<ControlPlaneStore["createComplianceCertificate"]>[0]) {
    const now = new Date().toISOString();
    const certificate: ComplianceCertificate = {
      id: randomUUID(),
      assessmentId: input.assessmentId,
      tenantId: input.tenantId,
      certificateNumber: input.certificateNumber,
      title: input.title ?? "",
      status: input.status ?? "incomplete",
      issuedAt: input.issuedAt ?? now,
      createdAt: now,
      updatedAt: now,
      ...(clean({ issuedBy: input.issuedBy, expiryDate: input.expiryDate, documentHash: input.documentHash, signature: input.signature, metadata: input.metadata }) as any),
    };
    this.complianceCertificates.push(certificate);
    return certificate;
  }

  async updateDeviceInventory(id: string, input: Parameters<ControlPlaneStore["updateDeviceInventory"]>[1]) {
    const record = this.deviceInventory.find((item) => item.id === id);
    if (!record) return undefined;
    Object.assign(record, { ...input, updatedAt: new Date().toISOString() });
    return record;
  }

  async createMaintenanceAsset(input: MaintenanceAssetInput): Promise<MaintenanceAsset> {
    const now = new Date().toISOString();
    const asset = {
      id: randomUUID(),
      tenantId: input.tenantId,
      category: input.category,
      assetType: input.assetType,
      status: input.status ?? "operational",
      createdBy: input.createdBy,
      createdAt: now,
      updatedAt: now,
      ...(clean({ serialNumber: input.serialNumber, make: input.make, model: input.model, firmwareVersion: input.firmwareVersion, warrantyExpiresAt: input.warrantyExpiresAt, purchaseDate: input.purchaseDate, installationDate: input.installationDate, vendorId: input.vendorId, branchNodeId: input.branchNodeId, location: input.location, mountingHeight: input.mountingHeight, notes: input.notes }) as any),
    };
    this.maintenanceAssets.push(asset);
    return asset;
  }

  async listMaintenanceAssets(tenantId: string, category?: string) {
    return this.maintenanceAssets.filter((asset) => asset.tenantId === tenantId && (!category || asset.category === category));
  }

  async getMaintenanceAsset(id: string) {
    return this.maintenanceAssets.find((asset) => asset.id === id);
  }

  async updateMaintenanceAsset(id: string, input: Parameters<ControlPlaneStore["updateMaintenanceAsset"]>[1]) {
    const asset = this.maintenanceAssets.find((item) => item.id === id);
    if (!asset) return undefined;
    Object.assign(asset, {
      ...input,
      updatedAt: new Date().toISOString(),
    });
    return asset;
  }

  async createWorkOrder(input: WorkOrderInput): Promise<WorkOrder> {
    const now = new Date().toISOString();
    const workOrder = {
      id: randomUUID(),
      tenantId: input.tenantId,
      workOrderNumber: input.workOrderNumber,
      problem: input.problem,
      severity: input.severity ?? "medium",
      status: input.status ?? "open",
      createdBy: input.createdBy,
      createdAt: now,
      updatedAt: now,
      ...(clean({ assetId: input.assetId, branchNodeId: input.branchNodeId, technician: input.technician, vendorId: input.vendorId, slaDueAt: input.slaDueAt, eta: input.eta, parts: input.parts, cost: input.cost, rootCause: input.rootCause, actionTaken: input.actionTaken, verification: input.verification }) as any),
    };
    this.workOrders.push(workOrder);
    return workOrder;
  }

  async listWorkOrders(tenantId: string, status?: string) {
    return this.workOrders.filter((order) => order.tenantId === tenantId && (!status || order.status === status));
  }

  async getWorkOrder(id: string) {
    return this.workOrders.find((order) => order.id === id);
  }

  async updateWorkOrder(id: string, input: Parameters<ControlPlaneStore["updateWorkOrder"]>[1]) {
    const workOrder = this.workOrders.find((order) => order.id === id);
    if (!workOrder) return undefined;
    Object.assign(workOrder, {
      ...input,
      updatedAt: new Date().toISOString(),
    });
    return workOrder;
  }

  async createMaintenanceVendor(input: MaintenanceVendorInput): Promise<MaintenanceVendor> {
    const now = new Date().toISOString();
    const vendor = {
      id: randomUUID(),
      tenantId: input.tenantId,
      name: input.name,
      createdBy: input.createdBy,
      createdAt: now,
      updatedAt: now,
      ...(clean({ contact: input.contact, email: input.email, phone: input.phone, address: input.address, gstNumber: input.gstNumber, serviceCenters: input.serviceCenters, escalationMatrix: input.escalationMatrix, notes: input.notes }) as any),
    };
    this.maintenanceVendors.push(vendor);
    return vendor;
  }

  async listMaintenanceVendors(tenantId: string) {
    return this.maintenanceVendors.filter((vendor) => vendor.tenantId === tenantId);
  }

  async getMaintenanceVendor(id: string) {
    return this.maintenanceVendors.find((vendor) => vendor.id === id);
  }

  async updateMaintenanceVendor(id: string, input: Parameters<ControlPlaneStore["updateMaintenanceVendor"]>[1]) {
    const vendor = this.maintenanceVendors.find((item) => item.id === id);
    if (!vendor) return undefined;
    Object.assign(vendor, {
      ...input,
      updatedAt: new Date().toISOString(),
    });
    return vendor;
  }

  async createAmcContract(input: AmcContractInput): Promise<AmcContract> {
    const now = new Date().toISOString();
    const contract = {
      id: randomUUID(),
      tenantId: input.tenantId,
      contractNumber: input.contractNumber,
      vendorId: input.vendorId,
      startDate: input.startDate ?? new Date().toISOString(),
      endDate: input.endDate ?? new Date().toISOString(),
      status: input.status ?? "active",
      createdBy: input.createdBy,
      createdAt: now,
      updatedAt: now,
      ...(clean({ startDate: input.startDate, endDate: input.endDate, warranty: input.warranty, coverage: input.coverage, exclusions: input.exclusions, paymentTerms: input.paymentTerms, cost: input.cost, renewal: input.renewal, sla: input.sla, notes: input.notes }) as any),
    };
    this.amcContracts.push(contract);
    return contract;
  }

  async createMaintenancePlan(input: { tenantId: string; name: string; cadence: string; checklistTemplate?: Record<string, any>; startDate?: string; endDate?: string; createdBy: string; }) {
    const now = new Date().toISOString();
    const plan = {
      id: randomUUID(), tenantId: input.tenantId, name: input.name, cadence: input.cadence,
      checklistTemplate: input.checklistTemplate ?? {}, startDate: input.startDate, endDate: input.endDate,
      createdBy: input.createdBy, createdAt: now, updatedAt: now,
    };
    this.maintenancePlans.push(plan);
    return plan;
  }

  async listMaintenancePlans(tenantId: string) {
    return this.maintenancePlans.filter((p) => p.tenantId === tenantId);
  }

  async getMaintenancePlan(id: string) {
    return this.maintenancePlans.find((p) => p.id === id);
  }

  async startPasswordRotation(input: { tenantId: string; deviceId: string; requestedBy: string; reason: string; rotationMode: 'scheduled' | 'emergency'; newPassword: string; }) {
    const now = new Date().toISOString();
    const secretRef = `device-credential://${input.tenantId}/${input.deviceId}/${randomUUID()}`;
    const rotation = {
      id: randomUUID(),
      tenantId: input.tenantId,
      deviceId: input.deviceId,
      requestedBy: input.requestedBy,
      reason: input.reason,
      rotationMode: input.rotationMode,
      status: 'pending-verification',
      secretRef,
      createdAt: now,
      updatedAt: now,
    };
    this.passwordRotations.push(rotation);
    return rotation;
  }

  async listPasswordRotations(tenantId: string) {
    return this.passwordRotations.filter((item) => item.tenantId === tenantId);
  }

  async createDeviceTemplate(input: { tenantId: string; name: string; templateType: 'camera-configuration' | 'recording' | 'analytics' | 'privacy' | 'network' | 'security-hardening' | 'location'; category: string; settings: Record<string, unknown>; createdBy: string; }) {
    const now = new Date().toISOString();
    const template = {
      id: randomUUID(),
      tenantId: input.tenantId,
      name: input.name,
      templateType: input.templateType,
      category: input.category,
      settings: input.settings,
      status: 'published',
      createdBy: input.createdBy,
      createdAt: now,
      updatedAt: now,
    };
    this.deviceTemplates.push(template);
    return template;
  }

  async applyDeviceTemplate(input: { tenantId: string; deviceId: string; templateId: string; appliedBy: string; }) {
    const template = this.deviceTemplates.find((item) => item.id === input.templateId);
    if (!template) {
      throw new Error('template_not_found');
    }
    const assignment = {
      id: randomUUID(),
      tenantId: input.tenantId,
      deviceId: input.deviceId,
      templateId: input.templateId,
      appliedBy: input.appliedBy,
      status: 'applied',
      appliedAt: new Date().toISOString(),
    };
    this.deviceTemplateAssignments.push(assignment);
    return assignment;
  }

  async getDeviceTemplateDrift(deviceId: string, templateId: string) {
    const template = this.deviceTemplates.find((item) => item.id === templateId);
    const assignment = this.deviceTemplateAssignments.find((item) => item.deviceId === deviceId && item.templateId === templateId);
    if (!template) {
      return { deviceId, templateId, status: 'unsupported' };
    }
    if (!assignment) {
      return { deviceId, templateId, status: 'minor-drift', templateVersion: template.settings };
    }
    return { deviceId, templateId, status: 'compliant', templateVersion: template.settings };
  }

  async assignDeviceIpAddress(input: { tenantId: string; deviceId: string; ipAddress: string; subnet: string; assignedBy: string; reservationStatus: 'dhcp' | 'static' | 'reserved'; }) {
    const existing = this.deviceIpAssignments.find((item) => item.tenantId === input.tenantId && item.ipAddress === input.ipAddress);
    const assignment = {
      id: randomUUID(),
      tenantId: input.tenantId,
      deviceId: input.deviceId,
      ipAddress: input.ipAddress,
      subnet: input.subnet,
      assignedBy: input.assignedBy,
      reservationStatus: input.reservationStatus,
      conflict: Boolean(existing),
      assignedAt: new Date().toISOString(),
    };
    this.deviceIpAssignments.push(assignment);
    return assignment;
  }

  async getIpConflicts(tenantId: string) {
    return this.deviceIpAssignments.filter((item) => item.tenantId === tenantId && item.conflict);
  }

  async createAnalyticsRule(
    inputTenantId: string,
    cameraId: string,
    createdBy: string | undefined,
    input: Parameters<ControlPlaneStore["createAnalyticsRule"]>[3],
  ) {
    const camera = this.cameras.get(cameraId);
    const node = camera ? this.nodes.get(camera.nodeId) : undefined;
    if (!camera || node?.tenantId !== inputTenantId) throw new Error("camera_not_found");
    const now = new Date().toISOString();
    const rule: AnalyticsRule = {
      id: randomUUID(), tenantId: inputTenantId, cameraId,
      ...(createdBy ? { createdBy } : {}),
      ...structuredClone(input), createdAt: now, updatedAt: now,
    };
    this.analyticsRules.push(rule);
    return rule;
  }

  async updateAnalyticsRule(
    id: string,
    inputTenantId: string,
    cameraId: string,
    input: Parameters<ControlPlaneStore["updateAnalyticsRule"]>[3],
  ) {
    const rule = this.analyticsRules.find((item) =>
      item.id === id && item.tenantId === inputTenantId && item.cameraId === cameraId
    );
    if (!rule) return undefined;
    Object.assign(rule, structuredClone(input), { updatedAt: new Date().toISOString() });
    return rule;
  }

  async deleteAnalyticsRule(id: string, inputTenantId: string, cameraId: string) {
    const index = this.analyticsRules.findIndex((rule) =>
      rule.id === id && rule.tenantId === inputTenantId && rule.cameraId === cameraId
    );
    if (index < 0) return false;
    this.analyticsRules.splice(index, 1);
    return true;
  }

  async processAnalyticsEvent(
    input: Parameters<ControlPlaneStore["processAnalyticsEvent"]>[0],
  ) {
    const camera = this.cameras.get(input.cameraId);
    const node = camera ? this.nodes.get(camera.nodeId) : undefined;
    if (!camera || node?.tenantId !== input.tenantId) throw new Error("camera_not_found");
    const duplicate = this.analyticsEvents.find((event) =>
      event.tenantId === input.tenantId && event.sourceEventId === input.sourceEventId
    );
    if (duplicate) {
      const alerts = this.analyticsAlerts.filter((alert) => alert.eventId === duplicate.id);
      return {
        event: { ...duplicate, status: "duplicate" as const },
        alerts,
        rules: this.analyticsRules.filter((rule) =>
          alerts.some((alert) => alert.ruleId === rule.id)
        ),
      };
    }

    const matchingRules = sortedMatchingRules(
      this.analyticsRules.filter((rule) => rule.cameraId === input.cameraId),
      input,
    );
    const now = new Date().toISOString();
    const eventId = randomUUID();
    const alerts: AnalyticsAlert[] = [];
    let created = 0;
    for (const rule of matchingRules) {
      const effectiveSeverity = resolveAlertSeverity({
        configuredSeverity: rule.severity,
        durationSeconds: input.durationSeconds,
        correlatedDetectionCount: correlationCount(input.metadata),
      });
      const recent = this.analyticsAlerts.find((alert) => {
        if (alert.ruleId !== rule.id || alert.cameraId !== input.cameraId ||
            isTerminalAlertStatus(alert.status)) return false;
        const elapsed = Date.parse(input.occurredAt) - Date.parse(alert.lastDetectedAt);
        return elapsed >= 0 && elapsed <= rule.cooldownSeconds * 1_000;
      });
      if (recent) {
        recent.lastDetectedAt = input.occurredAt;
        recent.occurrenceCount += 1;
        recent.confidence = Math.max(recent.confidence, input.confidence);
        recent.severity = moreSevere(recent.severity, effectiveSeverity);
        recent.updatedAt = now;
        alerts.push(recent);
        continue;
      }
      const alert: AnalyticsAlert = {
        id: randomUUID(), tenantId: input.tenantId, cameraId: input.cameraId,
        ruleId: rule.id, eventId, title: analyticsAlertTitle(rule),
        description: `Rule \"${rule.name}\" matched on camera ${camera.name}.`,
        severity: effectiveSeverity, status: "new", confidence: input.confidence,
        objectClasses: [...new Set(input.objects.map((object) => object.label))],
        modelVersion: input.modelVersion,
        ...(input.snapshotReference ? { snapshotReference: input.snapshotReference } : {}),
        ...(input.clipReference ? { clipReference: input.clipReference } : {}),
        firstDetectedAt: input.occurredAt, lastDetectedAt: input.occurredAt,
        occurrenceCount: 1,
        ...(rule.escalateAfterSeconds ? {
          slaDueAt: new Date(Date.parse(input.occurredAt) + rule.escalateAfterSeconds * 1_000).toISOString(),
        } : {}),
        correlationKey: typeof input.metadata?.correlationKey === "string"
          ? input.metadata.correlationKey : `${rule.id}:${input.cameraId}`,
        version: 1, createdAt: now, updatedAt: now,
      };
      this.analyticsAlerts.push(alert);
      alerts.push(alert);
      created += 1;
    }
    const event: AnalyticsEvent = {
      id: eventId, tenantId: input.tenantId, cameraId: input.cameraId,
      sourceEventId: input.sourceEventId,
      ...(matchingRules[0] ? { ruleId: matchingRules[0].id } : {}),
      detectionType: input.detectionType, occurredAt: input.occurredAt,
      ...(input.endedAt ? { endedAt: input.endedAt } : {}),
      confidence: input.confidence, durationSeconds: input.durationSeconds,
      modelVersion: input.modelVersion, objects: structuredClone(input.objects),
      ...(input.snapshotReference ? { snapshotReference: input.snapshotReference } : {}),
      ...(input.clipReference ? { clipReference: input.clipReference } : {}),
      metadata: structuredClone(input.metadata ?? {}),
      status: matchingRules.length === 0 ? "unmatched" : created > 0 ? "accepted" : "suppressed",
      ...(matchingRules.length === 0 ? { rejectionReason: "no_matching_rule" } : {}),
      createdAt: now,
    };
    this.analyticsEvents.push(event);
    return { event, alerts, rules: matchingRules };
  }

  async listAnalyticsAlerts(
    inputTenantId: string,
    filters: Parameters<ControlPlaneStore["listAnalyticsAlerts"]>[1],
  ) {
    return this.analyticsAlerts
      .filter((alert) => alert.tenantId === inputTenantId)
      .filter((alert) => !filters.cameraId || alert.cameraId === filters.cameraId)
      .filter((alert) => !filters.branchId ||
        this.cameras.get(alert.cameraId)?.branchId === filters.branchId)
      .filter((alert) => !filters.status || alert.status === filters.status)
      .filter((alert) => !filters.severity || alert.severity === filters.severity)
      .filter((alert) => !filters.from || alert.lastDetectedAt >= filters.from)
      .filter((alert) => !filters.to || alert.firstDetectedAt <= filters.to)
      .sort((left, right) => right.lastDetectedAt.localeCompare(left.lastDetectedAt))
      .slice(0, filters.limit);
  }

  async countAnalyticsAlerts(
    inputTenantId: string,
    filters: Parameters<ControlPlaneStore["countAnalyticsAlerts"]>[1],
  ) {
    const counts: Record<AnalyticsAlert["severity"], number> = {
      P1: 0,
      P2: 0,
      P3: 0,
      P4: 0,
      P5: 0,
    };
    for (const alert of this.analyticsAlerts) {
      if (alert.tenantId !== inputTenantId) continue;
      if (filters.cameraId && alert.cameraId !== filters.cameraId) continue;
      if (filters.branchId && this.cameras.get(alert.cameraId)?.branchId !== filters.branchId) continue;
      if (filters.from && alert.lastDetectedAt < filters.from) continue;
      if (filters.to && alert.firstDetectedAt > filters.to) continue;
      if (alert.status === "resolved" || alert.status === "false_alarm" || alert.status === "suppressed") continue;
      counts[alert.severity] += 1;
    }
    return counts;
  }

  async getAnalyticsAlert(id: string, inputTenantId: string) {
    return this.analyticsAlerts.find((alert) =>
      alert.id === id && alert.tenantId === inputTenantId
    );
  }

  async updateAnalyticsAlertEvidence(
    id: string,
    inputTenantId: string,
    input: { snapshotReference?: string; clipReference?: string },
  ) {
    const alert = await this.getAnalyticsAlert(id, inputTenantId);
    if (!alert) return undefined;
    let changed = false;
    if (!alert.snapshotReference && input.snapshotReference) {
      alert.snapshotReference = input.snapshotReference;
      changed = true;
    }
    if (!alert.clipReference && input.clipReference) {
      alert.clipReference = input.clipReference;
      changed = true;
    }
    if (changed) {
      alert.version += 1;
      alert.updatedAt = new Date().toISOString();
    }
    return alert;
  }

  async transitionAnalyticsAlert(
    id: string,
    inputTenantId: string,
    input: Parameters<ControlPlaneStore["transitionAnalyticsAlert"]>[2],
  ) {
    const alert = await this.getAnalyticsAlert(id, inputTenantId);
    if (!alert) return undefined;
    if (input.expectedVersion !== undefined && alert.version !== input.expectedVersion) {
      throw new Error("alert_version_conflict");
    }
    if (input.status === "acknowledged" && alert.acknowledgedAt) {
      throw new Error("alert_already_acknowledged");
    }
    if (isTerminalAlertStatus(alert.status) && alert.status !== input.status) {
      throw new Error("invalid_alert_transition");
    }
    const now = new Date().toISOString();
    alert.status = input.status;
    alert.version += 1;
    alert.updatedAt = now;
    if (input.status === "acknowledged") {
      alert.acknowledgedBy = input.actorUserId;
      alert.acknowledgedAt = now;
      this.analyticsAcknowledgements.push({
        id: randomUUID(), alertId: id, userId: input.actorUserId,
        notes: input.notes, acknowledgedAt: now,
      });
    }
    if (input.status === "escalated") {
      this.analyticsEscalations.push({
        id: randomUUID(), alertId: id, escalatedBy: input.actorUserId,
        notes: input.notes, recipients: input.recipients ?? [], escalatedAt: now,
      });
    }
    if (input.assignedTo) {
      alert.assignedTo = input.assignedTo;
      alert.assignedAt = now;
    }
    if (input.status === "resolved") alert.resolvedAt = now;
    if (input.status === "false_alarm") alert.falseAlarmReason = input.falseAlarmReason;
    return alert;
  }

  async getAlertNotificationPolicy(inputTenantId: string) {
    return structuredClone(this.alertNotificationPolicies.get(inputTenantId) ?? defaultAlertNotificationPolicy(inputTenantId));
  }

  async upsertAlertNotificationPolicy(policy: AlertNotificationPolicy) {
    const saved = { ...structuredClone(policy), updatedAt: new Date().toISOString() };
    this.alertNotificationPolicies.set(policy.tenantId, saved);
    return structuredClone(saved);
  }

  async enqueueAlertNotifications(input: Parameters<ControlPlaneStore["enqueueAlertNotifications"]>[0]) {
    const now = new Date().toISOString();
    const created: AlertNotification[] = [];
    for (const target of input) {
      const existing = this.analyticsNotifications.find((item) => item.alertId === target.alertId &&
        item.channel === target.channel && item.recipient === target.recipient);
      if (existing) { created.push(existing); continue; }
      const notification: AlertNotification = {
        id: randomUUID(), ...target, status: "queued", attempts: 0,
        nextAttemptAt: target.nextAttemptAt ?? now, createdAt: now, updatedAt: now,
      };
      this.analyticsNotifications.push(notification);
      created.push(notification);
    }
    return structuredClone(created);
  }

  async claimAlertNotifications(limit: number, now: string) {
    const claimed = this.analyticsNotifications.filter((item) =>
      ["queued", "failed"].includes(item.status) && item.nextAttemptAt <= now,
    ).slice(0, limit);
    for (const item of claimed) { item.status = "processing"; item.attempts += 1; item.updatedAt = now; }
    return structuredClone(claimed);
  }

  async completeAlertNotification(id: string, result: Parameters<ControlPlaneStore["completeAlertNotification"]>[1]) {
    const item = this.analyticsNotifications.find((notification) => notification.id === id);
    if (!item) return undefined;
    const now = new Date().toISOString();
    item.status = result.status;
    item.updatedAt = now;
    if (result.providerId) item.providerId = result.providerId;
    if (result.error) item.lastError = result.error;
    if (result.nextAttemptAt) item.nextAttemptAt = result.nextAttemptAt;
    if (["sent", "delivered"].includes(result.status)) item.sentAt = now;
    if (result.status === "delivered") item.deliveredAt = now;
    return structuredClone(item);
  }

  async recordVoiceCallEvent(id: string, event: Parameters<ControlPlaneStore["recordVoiceCallEvent"]>[1]) {
    const item = this.analyticsNotifications.find((notification) => notification.id === id);
    if (!item?.voiceCall) return undefined;
    item.voiceCall.status = event.status;
    if (event.provider) item.voiceCall.provider = event.provider;
    item.voiceCall.events.push({ status: event.status, occurredAt: event.occurredAt, ...(event.detail ? { detail: event.detail } : {}) });
    if (event.providerId) item.providerId = event.providerId;
    if (event.acknowledgedAt) item.voiceCall.acknowledgedAt = event.acknowledgedAt;
    if (event.acknowledgedBy) item.voiceCall.acknowledgedBy = event.acknowledgedBy;
    if (event.recordingUrl) item.voiceCall.recordingUrl = event.recordingUrl;
    if (event.durationSeconds !== undefined) item.voiceCall.durationSeconds = event.durationSeconds;
    item.updatedAt = event.occurredAt;
    return structuredClone(item);
  }

  async recordSmsDeliveryEvent(id: string, event: Parameters<ControlPlaneStore["recordSmsDeliveryEvent"]>[1]) {
    const item = this.analyticsNotifications.find((notification) => notification.id === id);
    if (!item) return undefined;
    if (!item.smsDelivery) {
      item.smsDelivery = { provider: event.provider ?? "webhook", status: event.status, template: "unknown", events: [] };
    }
    item.smsDelivery.status = event.status;
    if (event.provider) item.smsDelivery.provider = event.provider;
    item.smsDelivery.events.push({ status: event.status, occurredAt: event.occurredAt,
      ...(event.detail ? { detail: event.detail } : {}) });
    if (event.providerId) item.providerId = event.providerId;
    item.updatedAt = event.occurredAt;
    return structuredClone(item);
  }

  async recordEmailDeliveryEvent(id: string, event: Parameters<ControlPlaneStore["recordEmailDeliveryEvent"]>[1]) {
    const item = this.analyticsNotifications.find((notification) => notification.id === id);
    if (!item) return undefined;
    if (!item.emailDelivery) {
      item.emailDelivery = { provider: event.provider ?? "webhook", status: event.status, subject: event.subject ?? "", events: [] };
    }
    item.emailDelivery.status = event.status;
    if (event.provider) item.emailDelivery.provider = event.provider;
    if (event.subject) item.emailDelivery.subject = event.subject;
    item.emailDelivery.events.push({ status: event.status, occurredAt: event.occurredAt,
      ...(event.detail ? { detail: event.detail } : {}) });
    if (event.providerId) item.providerId = event.providerId;
    item.updatedAt = event.occurredAt;
    return structuredClone(item);
  }

  async reserveSmsRateLimit(inputTenantId: string, limit: number, requested: number, now: string) {
    const window = new Date(now).toISOString().slice(0, 16);
    const key = `${inputTenantId}:${window}`;
    const used = this.smsRateLimitWindows.get(key) ?? 0;
    const allowed = Math.max(0, Math.min(requested, limit - used));
    this.smsRateLimitWindows.set(key, used + allowed);
    return allowed;
  }

  async listAlertNotifications(inputTenantId: string, alertId?: string) {
    return this.analyticsNotifications.filter((item) => item.tenantId === inputTenantId &&
      (!alertId || item.alertId === alertId)).map((item) => structuredClone(item));
  }

  async listOperationalReportSchedules(inputTenantId: string) {
    return this.operationalReportSchedules.filter((item) => item.tenantId === inputTenantId)
      .sort((a, b) => a.name.localeCompare(b.name)).map((item) => structuredClone(item));
  }

  async createOperationalReportSchedule(input: Omit<OperationalReportSchedule, "id" | "lastRunAt" | "createdAt" | "updatedAt">) {
    const now = new Date().toISOString();
    const item: OperationalReportSchedule = { id: randomUUID(), ...structuredClone(input), lastRunAt: null, createdAt: now, updatedAt: now };
    this.operationalReportSchedules.push(item); return structuredClone(item);
  }

  async updateOperationalReportSchedule(id: string, inputTenantId: string, updates: Partial<Pick<OperationalReportSchedule, "name" | "timezone" | "dailyAt" | "template" | "formats" | "recipients" | "filters" | "enabled" | "nextRunAt" | "lastRunAt">>) {
    const item = this.operationalReportSchedules.find((entry) => entry.id === id && entry.tenantId === inputTenantId);
    if (!item) return undefined;
    Object.assign(item, structuredClone(updates), { updatedAt: new Date().toISOString() });
    this.operationalReportScheduleClaims.delete(id); return structuredClone(item);
  }

  async deleteOperationalReportSchedule(id: string, inputTenantId: string) {
    const index = this.operationalReportSchedules.findIndex((item) => item.id === id && item.tenantId === inputTenantId);
    if (index < 0) return false; this.operationalReportSchedules.splice(index, 1); return true;
  }

  async claimDueOperationalReportSchedules(now: string, limit: number) {
    const due = this.operationalReportSchedules.filter((item) => item.enabled && item.nextRunAt <= now && !this.operationalReportScheduleClaims.has(item.id)).slice(0, limit);
    for (const item of due) this.operationalReportScheduleClaims.add(item.id);
    return structuredClone(due);
  }

  async createOperationalReportRun(input: Omit<OperationalReportRun, "id" | "status" | "progress" | "attempts" | "nextAttemptAt" | "rowCount" | "summary" | "error" | "startedAt" | "completedAt" | "createdAt" | "updatedAt">) {
    const now = new Date().toISOString();
    const item: OperationalReportRun = { id: randomUUID(), ...structuredClone(input), status: "queued", progress: 0, attempts: 0, nextAttemptAt: now, rowCount: null, summary: null, error: null, startedAt: null, completedAt: null, createdAt: now, updatedAt: now };
    this.operationalReportRuns.push(item); return structuredClone(item);
  }

  async listOperationalReportRuns(inputTenantId: string, limit: number) {
    return this.operationalReportRuns.filter((item) => item.tenantId === inputTenantId)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, limit).map((item) => structuredClone(item));
  }
  async getOperationalReportRun(id: string, inputTenantId: string) { const item = this.operationalReportRuns.find((entry) => entry.id === id && entry.tenantId === inputTenantId); return item ? structuredClone(item) : undefined; }
  async claimOperationalReportRuns(now: string, limit: number) {
    const items = this.operationalReportRuns.filter((item) => ["queued", "failed"].includes(item.status) && item.nextAttemptAt <= now && item.attempts < item.maxAttempts).slice(0, limit);
    for (const item of items) { item.status = "running"; item.attempts += 1; item.startedAt ??= now; item.updatedAt = now; }
    return structuredClone(items);
  }
  async updateOperationalReportRun(id: string, updates: Partial<Pick<OperationalReportRun, "status" | "progress" | "nextAttemptAt" | "rowCount" | "summary" | "error" | "startedAt" | "completedAt">>) {
    const item = this.operationalReportRuns.find((entry) => entry.id === id); if (!item) return undefined;
    Object.assign(item, structuredClone(updates), { updatedAt: new Date().toISOString() }); return structuredClone(item);
  }
  async createOperationalReportArtifact(input: Omit<OperationalReportArtifact, "id" | "createdAt">) {
    const existing = this.operationalReportArtifacts.find((item) => item.runId === input.runId && item.format === input.format);
    if (existing) {
      Object.assign(existing, structuredClone(input), { createdAt: new Date().toISOString() });
      return structuredClone(existing);
    }
    const item: OperationalReportArtifact = { id: randomUUID(), ...structuredClone(input), createdAt: new Date().toISOString() };
    this.operationalReportArtifacts.push(item); return structuredClone(item);
  }
  async listOperationalReportArtifacts(inputTenantId: string, runId: string) { return this.operationalReportArtifacts.filter((item) => item.tenantId === inputTenantId && item.runId === runId).map((item) => structuredClone(item)); }
  async getOperationalReportArtifact(id: string, inputTenantId: string) { const item = this.operationalReportArtifacts.find((entry) => entry.id === id && entry.tenantId === inputTenantId); return item ? structuredClone(item) : undefined; }
  async enqueueOperationalReportDeliveries(input: Array<{ tenantId: string; runId: string; recipient: string }>) {
    const now = new Date().toISOString(); return input.map((target) => { const existing = this.operationalReportDeliveries.find((item) => item.runId === target.runId && item.recipient === target.recipient); if (existing) return structuredClone(existing); const item: OperationalReportDelivery = { id: randomUUID(), ...target, status: "queued", attempts: 0, nextAttemptAt: now, providerId: null, error: null, deliveredAt: null, createdAt: now, updatedAt: now }; this.operationalReportDeliveries.push(item); return structuredClone(item); });
  }
  async claimOperationalReportDeliveries(now: string, limit: number) { const items = this.operationalReportDeliveries.filter((item) => ["queued", "failed"].includes(item.status) && item.nextAttemptAt <= now && item.attempts < 5).slice(0, limit); for (const item of items) { item.status = "processing"; item.attempts += 1; item.updatedAt = now; } return structuredClone(items); }
  async completeOperationalReportDelivery(id: string, result: Parameters<ControlPlaneStore["completeOperationalReportDelivery"]>[1]) { const item = this.operationalReportDeliveries.find((entry) => entry.id === id); if (!item) return undefined; item.status = result.status; item.providerId = result.providerId ?? item.providerId; item.error = result.error ?? null; item.nextAttemptAt = result.nextAttemptAt ?? item.nextAttemptAt; item.deliveredAt = result.status === "delivered" ? new Date().toISOString() : item.deliveredAt; item.updatedAt = new Date().toISOString(); return structuredClone(item); }
  async listOperationalReportDeliveries(inputTenantId: string, runId: string) { return this.operationalReportDeliveries.filter((item) => item.tenantId === inputTenantId && item.runId === runId).map((item) => structuredClone(item)); }

  async linkAnalyticsAlertIncident(
    id: string,
    inputTenantId: string,
    incidentId: string,
  ) {
    const alert = await this.getAnalyticsAlert(id, inputTenantId);
    if (!alert) return undefined;
    alert.incidentId = incidentId;
    alert.updatedAt = new Date().toISOString();
    return alert;
  }

  async writeAudit(event: AuditEventInput) {
    this.auditEvents.push(structuredClone(event));
  }

  // ============ HEALTH MONITORING ============

  async recordCameraHealth(input: {
    tenantId: string;
    cameraId: string;
    onlineStatus: 'online' | 'offline' | 'degraded';
    fps?: number;
    bitrate?: number;
    streamQuality?: string;
    temperature?: number;
    tampering?: boolean;
    recordingRunning?: boolean;
    latencyMs?: number;
    packetLoss?: number;
  }) {
    const cameraHealth = {
      id: randomUUID(),
      tenantId: input.tenantId,
      cameraId: input.cameraId,
      onlineStatus: input.onlineStatus,
      fps: input.fps,
      bitrate: input.bitrate,
      streamQuality: input.streamQuality,
      temperature: input.temperature,
      tampering: input.tampering ?? false,
      recordingRunning: input.recordingRunning,
      latencyMs: input.latencyMs,
      packetLoss: input.packetLoss,
      lastFrameAt: new Date().toISOString(),
      lastCheckAt: new Date().toISOString(),
    };
    this.cameraHealth.push(cameraHealth);
    return cameraHealth;
  }

  async recordStorageHealth(input: {
    tenantId: string;
    assetId: string;
    totalCapacityGb: number;
    usedCapacityGb: number;
    availableCapacityGb: number;
    smartStatus?: string;
    temperature?: number;
    badSectors?: number;
    readSpeedMbs?: number;
    writeSpeedMbs?: number;
    remainingLifetimeYears?: number;
    errorCount?: number;
  }) {
    const usagePercentage = (input.usedCapacityGb / input.totalCapacityGb) * 100;
    const status = usagePercentage >= 90 ? 'critical' : usagePercentage >= 80 ? 'warning' : 'healthy';
    
    const storageHealth = {
      id: randomUUID(),
      tenantId: input.tenantId,
      assetId: input.assetId,
      totalCapacityGb: input.totalCapacityGb,
      usedCapacityGb: input.usedCapacityGb,
      availableCapacityGb: input.availableCapacityGb,
      usagePercentage,
      status,
      smartStatus: input.smartStatus,
      temperature: input.temperature,
      badSectors: input.badSectors,
      readSpeedMbs: input.readSpeedMbs,
      writeSpeedMbs: input.writeSpeedMbs,
      remainingLifetimeYears: input.remainingLifetimeYears,
      errorCount: input.errorCount,
      lastCheckAt: new Date().toISOString(),
    };
    this.storageHealth.push(storageHealth);
    return storageHealth;
  }

  async recordNetworkHealth(input: {
    tenantId: string;
    branchNodeId?: string;
    assetId?: string;
    checkType: string;
    latencyMs?: number;
    packetLossPercentage?: number;
    jitterMs?: number;
    bandwidthAvailableMbps?: number;
    rtspAvailable?: boolean;
    onvifAvailable?: boolean;
  }) {
    const status = (input.packetLossPercentage ?? 0) > 5 ? 'critical' 
      : (input.packetLossPercentage ?? 0) > 1 ? 'warning' : 'healthy';
    
    const networkHealth = {
      id: randomUUID(),
      tenantId: input.tenantId,
      branchNodeId: input.branchNodeId,
      assetId: input.assetId,
      checkType: input.checkType,
      latencyMs: input.latencyMs,
      packetLossPercentage: input.packetLossPercentage,
      jitterMs: input.jitterMs,
      bandwidthAvailableMbps: input.bandwidthAvailableMbps,
      rtspAvailable: input.rtspAvailable ?? true,
      onvifAvailable: input.onvifAvailable ?? true,
      status,
      lastCheckAt: new Date().toISOString(),
    };
    this.networkHealth.push(networkHealth);
    return networkHealth;
  }

  async recordUpsHealth(input: {
    tenantId: string;
    assetId: string;
    batteryHealthPercentage: number;
    runtimeMinutes?: number;
    chargingStatus?: string;
    loadPercentage?: number;
    temperature?: number;
    alarmStatus?: string;
  }) {
    const status = input.batteryHealthPercentage < 70 ? 'critical'
      : input.batteryHealthPercentage < 85 ? 'warning' : 'healthy';
    
    const upsHealth = {
      id: randomUUID(),
      tenantId: input.tenantId,
      assetId: input.assetId,
      batteryHealthPercentage: input.batteryHealthPercentage,
      runtimeMinutes: input.runtimeMinutes,
      chargingStatus: input.chargingStatus,
      loadPercentage: input.loadPercentage,
      temperature: input.temperature,
      alarmStatus: input.alarmStatus,
      status,
      lastCheckAt: new Date().toISOString(),
    };
    this.upsHealth.push(upsHealth);
    return upsHealth;
  }

  async getHealthCheckSummary(tenantId: string) {
    const now = new Date();
    const oneHourAgo = new Date(now.getTime() - 60 * 60 * 1000).toISOString();
    
    const camerasOnline = this.cameraHealth.filter(
      h => h.tenantId === tenantId && h.lastCheckAt > oneHourAgo && h.onlineStatus === 'online'
    ).length;
    
    const camerasOffline = this.cameraHealth.filter(
      h => h.tenantId === tenantId && h.lastCheckAt > oneHourAgo && h.onlineStatus === 'offline'
    ).length;
    
    const storageWarnings = this.storageHealth.filter(
      h => h.tenantId === tenantId && h.lastCheckAt > oneHourAgo && h.status !== 'healthy'
    ).length;
    
    const networkIssues = this.networkHealth.filter(
      h => h.tenantId === tenantId && h.lastCheckAt > oneHourAgo && h.status !== 'healthy'
    ).length;

    const totalCameras = this.cameras.size;
    const healthPercentage = totalCameras > 0 ? Math.round((camerasOnline / totalCameras) * 100) : 100;
    
    return {
      healthPercentage,
      camerasOnline,
      camerasOffline,
      camerasCount: totalCameras,
      storageAlerts: storageWarnings,
      networkIssues,
      recordingIssues: 0,
      amcExpiring: 0,
      overdueMaintenanceCount: this.maintenanceVisits.filter(
        v => v.tenantId === tenantId && v.status === 'pending' && new Date(v.dueAt) < now
      ).length,
      openWorkOrders: this.workOrders.filter(
        w => w.tenantId === tenantId && w.status !== 'closed'
      ).length,
    };
  }

  async listFirmwareUpdatesRequired(tenantId: string) {
    return this.firmwareInventory.filter(
      f => f.tenantId === tenantId && f.requiresUpdate
    ).sort((a, b) => (b.criticalUpdate ? 1 : 0) - (a.criticalUpdate ? 1 : 0));
  }

  async listLowStockParts(tenantId: string) {
    return this.spareParts.filter(
      p => p.tenantId === tenantId && p.reorderLevel && p.quantity <= p.reorderLevel
    );
  }

  async generateMaintenanceReport(input: {
    tenantId: string;
    reportType: string;
    periodStart: string;
    periodEnd: string;
    branchNodeId?: string;
    assetId?: string;
  }) {
    const periodStart = new Date(input.periodStart);
    const periodEnd = new Date(input.periodEnd);

    let metrics: any = {};

    switch (input.reportType) {
      case 'preventive':
        metrics = {
          scheduledVisits: this.maintenanceVisits.filter(
            v => v.tenantId === input.tenantId
              && new Date(v.dueAt) >= periodStart
              && new Date(v.dueAt) <= periodEnd
          ).length,
          completedVisits: this.maintenanceVisits.filter(
            v => v.tenantId === input.tenantId
              && v.status === 'completed'
              && new Date(v.visited_at ?? new Date()) >= periodStart
              && new Date(v.visited_at ?? new Date()) <= periodEnd
          ).length,
          overdueVisits: this.maintenanceVisits.filter(
            v => v.tenantId === input.tenantId
              && v.status !== 'completed'
              && new Date(v.dueAt) < new Date()
          ).length,
        };
        break;

      case 'corrective':
        metrics = {
          totalWorkOrders: this.workOrders.filter(
            w => w.tenantId === input.tenantId
              && new Date(w.createdAt) >= periodStart
              && new Date(w.createdAt) <= periodEnd
          ).length,
          closedWorkOrders: this.workOrders.filter(
            w => w.tenantId === input.tenantId
              && w.status === 'closed'
              && new Date(w.updatedAt) >= periodStart
              && new Date(w.updatedAt) <= periodEnd
          ).length,
          openWorkOrders: this.workOrders.filter(
            w => w.tenantId === input.tenantId && w.status !== 'closed'
          ).length,
          averageResolutionHours: 24,
        };
        break;

      case 'amc':
        metrics = {
          activeContracts: this.amcContracts.filter(
            c => c.tenantId === input.tenantId && c.status === 'active'
          ).length,
          expiringContracts: this.amcContracts.filter(
            c => c.tenantId === input.tenantId
              && new Date(c.end_date) <= new Date(Date.now() + 90 * 24 * 60 * 60 * 1000)
          ).length,
          totalAnnualCost: this.amcContracts.filter(
            c => c.tenantId === input.tenantId && c.status === 'active'
          ).reduce((sum, c) => sum + (c.cost ?? 0), 0),
        };
        break;
    }

    const report = {
      id: randomUUID(),
      tenantId: input.tenantId,
      reportType: input.reportType,
      periodStart: input.periodStart,
      periodEnd: input.periodEnd,
      branchNodeId: input.branchNodeId,
      assetId: input.assetId,
      metrics,
      summary: `${input.reportType} maintenance report for ${input.periodStart} to ${input.periodEnd}`,
      generatedBy: 'system',
      generatedAt: new Date().toISOString(),
      filename: `${input.reportType}-report-${new Date().toISOString().split('T')[0]}.pdf`,
    };
    this.maintenanceReports.push(report);
    return report;
  }

  async listMaintenanceReports(tenantId: string, filters?: { reportType?: string; limit?: number }) {
    return this.maintenanceReports.filter(
      r => r.tenantId === tenantId && (!filters?.reportType || r.reportType === filters.reportType)
    ).sort((a, b) => b.generatedAt.localeCompare(a.generatedAt))
      .slice(0, filters?.limit ?? 50);
  }

  async getMaintenanceComplianceStatus(tenantId: string) {
    const overdueVisits = this.maintenanceVisits.filter(
      v => v.tenantId === tenantId && v.status !== 'completed' && new Date(v.dueAt) < new Date()
    ).length;

    const openWorkOrders = this.workOrders.filter(
      w => w.tenantId === tenantId && w.status !== 'closed'
    ).length;

    const criticalAlerts = this.predictiveAlerts.filter(
      p => p.tenantId === tenantId && p.score > 0.8
    ).length;

    return {
      compliant: overdueVisits === 0 && openWorkOrders === 0 && criticalAlerts === 0,
      overdueMaintenanceCount: overdueVisits,
      openIssuesCount: openWorkOrders,
      criticalAlertsCount: criticalAlerts,
      status: overdueVisits > 0 || openWorkOrders > 5 ? 'non-compliant' : 'compliant',
    };
  }

  // ============ PRIVACY METHODS ============

  async getPrivacySummary(tenantId: string): Promise<any> {
    const purposes = this.privacyPurposes.filter((purpose) => purpose.tenantId === tenantId);
    const matchedCameraIds = [...this.cameras.values()]
      .filter((camera) => {
        const node = this.nodes.get(camera.nodeId);
        return node && node.tenantId === tenantId;
      })
      .map((camera) => camera.id);
    const assignedPurposes = this.cameraPrivacyPurposeAssignments.filter((assignment) =>
      matchedCameraIds.includes(assignment.cameraId),
    );
    const controls = [...this.cameraPrivacyControls.values()].filter((control) =>
      matchedCameraIds.includes(control.cameraId),
    );
    const openBreaches = this.privacyBreaches.filter((breach) =>
      breach.tenantId === tenantId && breach.status !== "closed",
    );

    return {
      activePurposes: purposes.filter((purpose) => purpose.active).length,
      totalPurposes: purposes.length,
      assignedPurposes: assignedPurposes.length,
      totalControls: controls.length,
      openBreaches: openBreaches.length,
    };
  }

  async listPrivacyPurposes(tenantId: string): Promise<any[]> {
    return this.privacyPurposes.filter((purpose) => purpose.tenantId === tenantId);
  }

  async getPrivacyPurpose(id: string): Promise<any | undefined> {
    return this.privacyPurposes.find((purpose) => purpose.id === id);
  }

  async createPrivacyPurpose(input: {
    tenantId: string;
    name: string;
    lawfulBasis: string;
    description?: string;
    riskLevel?: string;
    dataCategories?: string[];
    active?: boolean;
    createdBy?: string;
  }): Promise<any> {
    const purpose = {
      id: randomUUID(),
      tenantId: input.tenantId,
      name: input.name,
      lawfulBasis: input.lawfulBasis,
      description: input.description ?? null,
      riskLevel: input.riskLevel ?? "medium",
      dataCategories: input.dataCategories ?? [],
      active: input.active ?? true,
      createdBy: input.createdBy ?? null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.privacyPurposes.unshift(purpose);
    return purpose;
  }

  async updatePrivacyPurpose(id: string, input: Partial<{
    tenantId: string;
    name: string;
    lawfulBasis: string;
    description?: string;
    riskLevel?: string;
    dataCategories?: string[];
    active?: boolean;
    createdBy?: string;
  }>): Promise<any | undefined> {
    const purpose = this.privacyPurposes.find((item) => item.id === id);
    if (!purpose) return undefined;
    Object.assign(purpose, {
      tenantId: input.tenantId ?? purpose.tenantId,
      name: input.name ?? purpose.name,
      lawfulBasis: input.lawfulBasis ?? purpose.lawfulBasis,
      description: input.description ?? purpose.description,
      riskLevel: input.riskLevel ?? purpose.riskLevel,
      dataCategories: input.dataCategories ?? purpose.dataCategories,
      active: input.active ?? purpose.active,
      createdBy: input.createdBy ?? purpose.createdBy,
      updatedAt: new Date().toISOString(),
    });
    return purpose;
  }

  async listCameraPrivacyPurposes(cameraId: string): Promise<any[]> {
    return this.cameraPrivacyPurposeAssignments.filter((assignment) => assignment.cameraId === cameraId);
  }

  async assignCameraPrivacyPurpose(
    cameraId: string,
    purposeId: string,
    assignedBy: string,
    startDate?: string,
    endDate?: string,
    notes?: string,
  ): Promise<any> {
    const assignment = {
      id: randomUUID(),
      cameraId,
      purposeId,
      assignedBy,
      startDate: startDate ?? null,
      endDate: endDate ?? null,
      notes: notes ?? null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.cameraPrivacyPurposeAssignments.unshift(assignment);
    return assignment;
  }

  async getCameraPrivacyControls(cameraId: string): Promise<any> {
    return this.cameraPrivacyControls.get(cameraId) ?? {
      cameraId,
      audioRecordingApproved: false,
      encryptionEnabled: false,
      disposalPlan: null,
      dataProtectionOfficer: null,
      lastReviewedAt: null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
  }

  async upsertCameraPrivacyControls(cameraId: string, input: any): Promise<any> {
    const existing = this.cameraPrivacyControls.get(cameraId) ?? {
      id: randomUUID(),
      cameraId,
      audioRecordingApproved: false,
      encryptionEnabled: false,
      disposalPlan: null,
      dataProtectionOfficer: null,
      lastReviewedAt: null,
      createdBy: null,
      createdAt: new Date().toISOString(),
    };
    const updated = {
      ...existing,
      ...input,
      updatedAt: new Date().toISOString(),
    };
    this.cameraPrivacyControls.set(cameraId, updated);
    return updated;
  }

  async listPrivacyBreaches(tenantId: string, status?: string): Promise<any[]> {
    return this.privacyBreaches.filter((breach) => breach.tenantId === tenantId && (!status || breach.status === status));
  }

  async reportPrivacyBreach(input: {
    tenantId: string;
    branchNodeId?: string;
    cameraId?: string;
    breachType: string;
    severity: string;
    discoveredAt: string;
    description?: string;
    remediation?: string;
    createdBy?: string;
  }): Promise<any> {
    const breach = {
      id: randomUUID(),
      ...input,
      status: "reported",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.privacyBreaches.unshift(breach);
    return breach;
  }

  async updatePrivacyBreachStatus(id: string, status: string, updatedBy: string): Promise<any> {
    const breach = this.privacyBreaches.find((item) => item.id === id);
    if (!breach) return undefined;
    breach.status = status;
    breach.updatedBy = updatedBy;
    breach.updatedAt = new Date().toISOString();
    return breach;
  }

  // ============ FIRMWARE MANAGEMENT ============

  async recordFirmwareVersion(input: {
    tenantId: string;
    assetId: string;
    deviceType: string;
    currentVersion: string;
    latestVersion?: string | undefined;
    requiresUpdate?: boolean | undefined;
    criticalUpdate?: boolean | undefined;
  }): Promise<any> {
    const firmware = {
      id: randomUUID(),
      tenantId: input.tenantId,
      assetId: input.assetId,
      deviceType: input.deviceType,
      currentVersion: input.currentVersion,
      latestVersion: input.latestVersion ?? null,
      requiresUpdate: input.requiresUpdate ?? false,
      criticalUpdate: input.criticalUpdate ?? false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.firmwareInventory.unshift(firmware);
    return firmware;
  }

  async recordSoftwareVersion(input: {
    tenantId: string;
    componentName: string;
    environment: string;
    currentVersion: string;
    previousVersion?: string | undefined;
    upgradeApprovedBy?: string | undefined;
    upgradeApprovedAt?: string | undefined;
  }): Promise<any> {
    const software = {
      id: randomUUID(),
      tenantId: input.tenantId,
      componentName: input.componentName,
      environment: input.environment,
      currentVersion: input.currentVersion,
      previousVersion: input.previousVersion ?? null,
      upgradeApprovedBy: input.upgradeApprovedBy ?? null,
      upgradeApprovedAt: input.upgradeApprovedAt ?? null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.softwareVersions.unshift(software);
    return software;
  }

  // ============ SPARE PARTS INVENTORY ============

  async recordSparePart(input: {
    tenantId: string;
    partName: string;
    partCode: string;
    category: string;
    vendorId?: string | undefined;
    quantity: number;
    reorderLevel?: number | undefined;
    unitCost?: number | undefined;
    warrantyMonths?: number | undefined;
    location?: string | undefined;
    branchNodeId?: string | undefined;
  }): Promise<any> {
    const part = {
      id: randomUUID(),
      tenantId: input.tenantId,
      partName: input.partName,
      partCode: input.partCode,
      category: input.category,
      vendorId: input.vendorId ?? null,
      quantity: input.quantity,
      reorderLevel: input.reorderLevel ?? 10,
      unitCost: input.unitCost ?? null,
      warrantyMonths: input.warrantyMonths ?? null,
      location: input.location ?? null,
      branchNodeId: input.branchNodeId ?? null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.spareParts.unshift(part);
    return part;
  }

  async recordInventoryTransaction(input: {
    tenantId: string;
    partId: string;
    workOrderId?: string | undefined;
    transactionType: 'add' | 'remove' | 'used' | 'damaged';
    quantity: number;
    referenceNumber?: string | undefined;
    notes?: string | undefined;
    recordedBy?: string | undefined;
  }): Promise<any> {
    const transaction = {
      id: randomUUID(),
      tenantId: input.tenantId,
      partId: input.partId,
      workOrderId: input.workOrderId ?? null,
      transactionType: input.transactionType,
      quantity: input.quantity,
      referenceNumber: input.referenceNumber ?? null,
      notes: input.notes ?? null,
      recordedBy: input.recordedBy ?? null,
      createdAt: new Date().toISOString(),
    };
    this.inventoryTransactions.unshift(transaction);

    // Update part quantity
    const part = this.spareParts.find((p) => p.id === input.partId);
    if (part) {
      if (input.transactionType === 'add') {
        part.quantity += input.quantity;
      } else if (input.transactionType === 'remove' || input.transactionType === 'used' || input.transactionType === 'damaged') {
        part.quantity -= input.quantity;
      }
      part.updatedAt = new Date().toISOString();
    }

    return transaction;
  }

  // Requirements
  async listComplianceRequirements(tenantId: string, filters?: {
    frameworkId?: string;
    category?: string;
    status?: string;
  }): Promise<any[]> {
    return this.complianceRequirements.filter((req) => {
      if (req.tenantId !== tenantId) return false;
      if (filters?.frameworkId && req.frameworkId !== filters.frameworkId) return false;
      if (filters?.category && req.category !== filters.category) return false;
      if (filters?.status && req.status !== filters.status) return false;
      return true;
    });
  }

  async getComplianceRequirement(id: string): Promise<any | undefined> {
    return this.complianceRequirements.find((req) => req.id === id);
  }

  async createComplianceRequirement(input: any): Promise<any> {
    const now = new Date().toISOString();
    const requirement = {
      id: randomUUID(),
      tenantId: input.tenantId,
      frameworkId: input.frameworkId,
      requirementNumber: input.requirementNumber,
      title: input.title,
      description: input.description ?? null,
      category: input.category ?? null,
      priority: input.priority ?? 'medium',
      status: input.status ?? 'active',
      implementationGuidance: input.implementationGuidance ?? null,
      createdBy: input.createdBy ?? null,
      createdAt: now,
      updatedAt: now,
    };
    this.complianceRequirements.push(requirement);
    return requirement;
  }

  async updateComplianceRequirement(id: string, input: any): Promise<any | undefined> {
    const requirement = this.complianceRequirements.find((req) => req.id === id);
    if (!requirement) return undefined;
    Object.assign(requirement, input, { updatedAt: new Date().toISOString() });
    return requirement;
  }

  async deleteComplianceRequirement(id: string): Promise<void> {
    const index = this.complianceRequirements.findIndex((req) => req.id === id);
    if (index >= 0) this.complianceRequirements.splice(index, 1);
  }

  // Controls
  async listComplianceControls(tenantId: string, filters?: {
    requirementId?: string;
    implementationStatus?: string;
  }): Promise<any[]> {
    return this.complianceControls.filter((control) => {
      if (control.tenantId !== tenantId) return false;
      if (filters?.requirementId && control.requirementId !== filters.requirementId) return false;
      if (filters?.implementationStatus && control.implementationStatus !== filters.implementationStatus) return false;
      return true;
    });
  }

  async getComplianceControl(id: string): Promise<any | undefined> {
    return this.complianceControls.find((control) => control.id === id);
  }

  async createComplianceControl(input: any): Promise<any> {
    const now = new Date().toISOString();
    const control = {
      id: randomUUID(),
      tenantId: input.tenantId,
      requirementId: input.requirementId,
      controlNumber: input.controlNumber,
      title: input.title,
      description: input.description ?? null,
      controlType: input.controlType ?? null,
      implementationStatus: input.implementationStatus ?? 'not_started',
      implementationDetails: input.implementationDetails ?? null,
      owner: input.owner ?? null,
      testingFrequency: input.testingFrequency ?? null,
      lastTestDate: input.lastTestDate ?? null,
      nextTestDate: input.nextTestDate ?? null,
      effectivenessRating: input.effectivenessRating ?? null,
      createdBy: input.createdBy ?? null,
      createdAt: now,
      updatedAt: now,
    };
    this.complianceControls.push(control);
    return control;
  }

  async updateComplianceControl(id: string, input: any): Promise<any | undefined> {
    const control = this.complianceControls.find((c) => c.id === id);
    if (!control) return undefined;
    Object.assign(control, input, { updatedAt: new Date().toISOString() });
    return control;
  }

  async deleteComplianceControl(id: string): Promise<void> {
    const index = this.complianceControls.findIndex((c) => c.id === id);
    if (index >= 0) this.complianceControls.splice(index, 1);
  }

  async updateControlTestDates(id: string, input: {
    lastTestDate: string;
    nextTestDate: string;
    effectivenessRating?: number;
  }): Promise<any | undefined> {
    const control = this.complianceControls.find((c) => c.id === id);
    if (!control) return undefined;
    control.lastTestDate = input.lastTestDate;
    control.nextTestDate = input.nextTestDate;
    if (input.effectivenessRating !== undefined) {
      control.effectivenessRating = input.effectivenessRating;
    }
    control.updatedAt = new Date().toISOString();
    return control;
  }

  // Evidence
  async listComplianceEvidence(tenantId: string, filters?: {
    requirementId?: string;
    controlId?: string;
    assessmentId?: string;
    validated?: boolean;
  }): Promise<any[]> {
    return this.complianceEvidence.filter((evidence) => {
      if (evidence.tenantId !== tenantId) return false;
      if (filters?.requirementId && evidence.requirementId !== filters.requirementId) return false;
      if (filters?.controlId && evidence.controlId !== filters.controlId) return false;
      if (filters?.assessmentId && evidence.assessmentId !== filters.assessmentId) return false;
      if (filters?.validated !== undefined && evidence.validated !== filters.validated) return false;
      return true;
    });
  }

  async getComplianceEvidence(id: string): Promise<any | undefined> {
    return this.complianceEvidence.find((evidence) => evidence.id === id);
  }

  async createComplianceEvidence(input: any): Promise<any> {
    const now = new Date().toISOString();
    const evidence = {
      id: randomUUID(),
      tenantId: input.tenantId,
      requirementId: input.requirementId ?? null,
      controlId: input.controlId ?? null,
      assessmentId: input.assessmentId ?? null,
      evidenceType: input.evidenceType,
      title: input.title,
      description: input.description ?? null,
      evidenceUrl: input.evidenceUrl ?? null,
      collectedAt: input.collectedAt ?? now,
      validated: input.validated ?? false,
      validatorId: input.validatorId ?? null,
      validationNotes: input.validationNotes ?? null,
      createdBy: input.createdBy ?? null,
      createdAt: now,
      updatedAt: now,
    };
    this.complianceEvidence.push(evidence);
    return evidence;
  }

  async updateComplianceEvidence(id: string, input: any): Promise<any | undefined> {
    const evidence = this.complianceEvidence.find((e) => e.id === id);
    if (!evidence) return undefined;
    Object.assign(evidence, input, { updatedAt: new Date().toISOString() });
    return evidence;
  }

  async deleteComplianceEvidence(id: string): Promise<void> {
    const index = this.complianceEvidence.findIndex((e) => e.id === id);
    if (index >= 0) this.complianceEvidence.splice(index, 1);
  }

  async validateComplianceEvidence(id: string, validated: boolean, validatorId: string, notes?: string): Promise<any | undefined> {
    const evidence = this.complianceEvidence.find((e) => e.id === id);
    if (!evidence) return undefined;
    evidence.validated = validated;
    evidence.validatorId = validatorId;
    evidence.validationNotes = notes ?? null;
    evidence.updatedAt = new Date().toISOString();
    return evidence;
  }

  // Tests
  async listComplianceTests(tenantId: string, filters?: {
    controlId?: string;
    status?: string;
  }): Promise<any[]> {
    return this.complianceTests.filter((test) => {
      if (test.tenantId !== tenantId) return false;
      if (filters?.controlId && test.controlId !== filters.controlId) return false;
      if (filters?.status && test.status !== filters.status) return false;
      return true;
    });
  }

  async getComplianceTest(id: string): Promise<any | undefined> {
    return this.complianceTests.find((test) => test.id === id);
  }

  async createComplianceTest(input: any): Promise<any> {
    const now = new Date().toISOString();
    const test = {
      id: randomUUID(),
      tenantId: input.tenantId,
      controlId: input.controlId,
      testName: input.testName,
      testProcedure: input.testProcedure ?? null,
      scheduledDate: input.scheduledDate,
      completedDate: input.completedDate ?? null,
      testerId: input.testerId ?? null,
      status: input.status ?? 'scheduled',
      result: input.result ?? null,
      findings: input.findings ?? null,
      evidenceIds: input.evidenceIds ?? [],
      createdBy: input.createdBy ?? null,
      createdAt: now,
      updatedAt: now,
    };
    this.complianceTests.push(test);
    return test;
  }

  async updateComplianceTest(id: string, input: any): Promise<any | undefined> {
    const test = this.complianceTests.find((t) => t.id === id);
    if (!test) return undefined;
    Object.assign(test, input, { updatedAt: new Date().toISOString() });
    return test;
  }

  async deleteComplianceTest(id: string): Promise<void> {
    const index = this.complianceTests.findIndex((t) => t.id === id);
    if (index >= 0) this.complianceTests.splice(index, 1);
  }

  // Findings
  async listComplianceFindings(tenantId: string, filters?: {
    assessmentId?: string;
    severity?: string;
    status?: string;
  }): Promise<any[]> {
    return this.complianceFindings.filter((finding) => {
      if (finding.tenantId !== tenantId) return false;
      if (filters?.assessmentId && finding.assessmentId !== filters.assessmentId) return false;
      if (filters?.severity && finding.severity !== filters.severity) return false;
      if (filters?.status && finding.status !== filters.status) return false;
      return true;
    });
  }

  async getComplianceFinding(id: string): Promise<any | undefined> {
    return this.complianceFindings.find((finding) => finding.id === id);
  }

  async createComplianceFinding(input: any): Promise<any> {
    const now = new Date().toISOString();
    const finding = {
      id: randomUUID(),
      tenantId: input.tenantId,
      assessmentId: input.assessmentId ?? null,
      requirementId: input.requirementId ?? null,
      controlId: input.controlId ?? null,
      findingNumber: input.findingNumber,
      title: input.title,
      description: input.description,
      severity: input.severity,
      status: input.status ?? 'open',
      identifiedDate: input.identifiedDate ?? now,
      dueDate: input.dueDate ?? null,
      closedDate: input.closedDate ?? null,
      closedBy: input.closedBy ?? null,
      closureNotes: input.closureNotes ?? null,
      createdBy: input.createdBy ?? null,
      createdAt: now,
      updatedAt: now,
    };
    this.complianceFindings.push(finding);
    return finding;
  }

  async updateComplianceFinding(id: string, input: any): Promise<any | undefined> {
    const finding = this.complianceFindings.find((f) => f.id === id);
    if (!finding) return undefined;
    Object.assign(finding, input, { updatedAt: new Date().toISOString() });
    return finding;
  }

  async deleteComplianceFinding(id: string): Promise<void> {
    const index = this.complianceFindings.findIndex((f) => f.id === id);
    if (index >= 0) this.complianceFindings.splice(index, 1);
  }

  async closeComplianceFinding(id: string, closedBy: string, notes?: string): Promise<any | undefined> {
    const finding = this.complianceFindings.find((f) => f.id === id);
    if (!finding) return undefined;
    finding.status = 'closed';
    finding.closedDate = new Date().toISOString();
    finding.closedBy = closedBy;
    finding.closureNotes = notes ?? null;
    finding.updatedAt = new Date().toISOString();
    return finding;
  }

  // Remediation Plans
  async listRemediationPlans(tenantId: string, filters?: {
    findingId?: string;
    status?: string;
  }): Promise<any[]> {
    return this.remediationPlans.filter((plan) => {
      if (plan.tenantId !== tenantId) return false;
      if (filters?.findingId && plan.findingId !== filters.findingId) return false;
      if (filters?.status && plan.status !== filters.status) return false;
      return true;
    });
  }

  async getRemediationPlan(id: string): Promise<any | undefined> {
    return this.remediationPlans.find((plan) => plan.id === id);
  }

  async createRemediationPlan(input: any): Promise<any> {
    const now = new Date().toISOString();
    const plan = {
      id: randomUUID(),
      tenantId: input.tenantId,
      findingId: input.findingId,
      planName: input.planName,
      description: input.description ?? null,
      owner: input.owner ?? null,
      targetCompletionDate: input.targetCompletionDate,
      status: input.status ?? 'draft',
      approvedBy: input.approvedBy ?? null,
      approvedAt: input.approvedAt ?? null,
      verifiedBy: input.verifiedBy ?? null,
      verifiedAt: input.verifiedAt ?? null,
      verificationNotes: input.verificationNotes ?? null,
      effectivenessConfirmed: input.effectivenessConfirmed ?? false,
      createdBy: input.createdBy ?? null,
      createdAt: now,
      updatedAt: now,
    };
    this.remediationPlans.push(plan);
    return plan;
  }

  async updateRemediationPlan(id: string, input: any): Promise<any | undefined> {
    const plan = this.remediationPlans.find((p) => p.id === id);
    if (!plan) return undefined;
    Object.assign(plan, input, { updatedAt: new Date().toISOString() });
    return plan;
  }

  async deleteRemediationPlan(id: string): Promise<void> {
    const index = this.remediationPlans.findIndex((p) => p.id === id);
    if (index >= 0) this.remediationPlans.splice(index, 1);
  }

  async approveRemediationPlan(id: string, approverId: string): Promise<any | undefined> {
    const plan = this.remediationPlans.find((p) => p.id === id);
    if (!plan) return undefined;
    plan.status = 'approved';
    plan.approvedBy = approverId;
    plan.approvedAt = new Date().toISOString();
    plan.updatedAt = new Date().toISOString();
    return plan;
  }

  async verifyRemediationPlan(id: string, verifierId: string, input: {
    verificationNotes?: string;
    effectivenessConfirmed: boolean;
  }): Promise<any | undefined> {
    const plan = this.remediationPlans.find((p) => p.id === id);
    if (!plan) return undefined;
    plan.status = 'verified';
    plan.verifiedBy = verifierId;
    plan.verifiedAt = new Date().toISOString();
    plan.verificationNotes = input.verificationNotes ?? null;
    plan.effectivenessConfirmed = input.effectivenessConfirmed;
    plan.updatedAt = new Date().toISOString();
    return plan;
  }

  // Remediation Actions
  async listRemediationActions(planId: string): Promise<any[]> {
    return this.remediationActions.filter((action) => action.planId === planId);
  }

  async getRemediationAction(id: string): Promise<any | undefined> {
    return this.remediationActions.find((action) => action.id === id);
  }

  async createRemediationAction(input: any): Promise<any> {
    const now = new Date().toISOString();
    const action = {
      id: randomUUID(),
      planId: input.planId,
      actionName: input.actionName,
      description: input.description ?? null,
      assignedTo: input.assignedTo ?? null,
      dueDate: input.dueDate,
      status: input.status ?? 'pending',
      completedDate: input.completedDate ?? null,
      evidenceUrl: input.evidenceUrl ?? null,
      notes: input.notes ?? null,
      createdAt: now,
      updatedAt: now,
    };
    this.remediationActions.push(action);
    return action;
  }

  async updateRemediationAction(id: string, input: any): Promise<any | undefined> {
    const action = this.remediationActions.find((a) => a.id === id);
    if (!action) return undefined;
    Object.assign(action, input, { updatedAt: new Date().toISOString() });
    return action;
  }

  async deleteRemediationAction(id: string): Promise<void> {
    const index = this.remediationActions.findIndex((a) => a.id === id);
    if (index >= 0) this.remediationActions.splice(index, 1);
  }

  async completeRemediationAction(id: string, input: {
    evidenceUrl?: string;
    notes?: string;
  }): Promise<any | undefined> {
    const action = this.remediationActions.find((a) => a.id === id);
    if (!action) return undefined;
    action.status = 'completed';
    action.completedDate = new Date().toISOString();
    action.evidenceUrl = input.evidenceUrl ?? action.evidenceUrl;
    action.notes = input.notes ?? action.notes;
    action.updatedAt = new Date().toISOString();
    return action;
  }

  // Risks
  async listComplianceRisks(tenantId: string, filters?: {
    frameworkId?: string;
    category?: string;
    status?: string;
  }): Promise<any[]> {
    return this.complianceRisks.filter((risk) => {
      if (risk.tenantId !== tenantId) return false;
      if (filters?.frameworkId && risk.frameworkId !== filters.frameworkId) return false;
      if (filters?.category && risk.category !== filters.category) return false;
      if (filters?.status && risk.status !== filters.status) return false;
      return true;
    });
  }

  async getComplianceRisk(id: string): Promise<any | undefined> {
    return this.complianceRisks.find((risk) => risk.id === id);
  }

  async createComplianceRisk(input: any): Promise<any> {
    const now = new Date().toISOString();
    const risk = {
      id: randomUUID(),
      tenantId: input.tenantId,
      frameworkId: input.frameworkId ?? null,
      requirementId: input.requirementId ?? null,
      riskName: input.riskName,
      description: input.description ?? null,
      category: input.category ?? null,
      inherentLikelihood: input.inherentLikelihood,
      inherentImpact: input.inherentImpact,
      residualLikelihood: input.residualLikelihood ?? null,
      residualImpact: input.residualImpact ?? null,
      treatmentPlan: input.treatmentPlan ?? null,
      owner: input.owner ?? null,
      status: input.status ?? 'identified',
      lastReviewDate: input.lastReviewDate ?? null,
      nextReviewDate: input.nextReviewDate ?? null,
      reviewNotes: input.reviewNotes ?? null,
      createdBy: input.createdBy ?? null,
      createdAt: now,
      updatedAt: now,
    };
    this.complianceRisks.push(risk);
    return risk;
  }

  async updateComplianceRisk(id: string, input: any): Promise<any | undefined> {
    const risk = this.complianceRisks.find((r) => r.id === id);
    if (!risk) return undefined;
    Object.assign(risk, input, { updatedAt: new Date().toISOString() });
    return risk;
  }

  async deleteComplianceRisk(id: string): Promise<void> {
    const index = this.complianceRisks.findIndex((r) => r.id === id);
    if (index >= 0) this.complianceRisks.splice(index, 1);
  }

  async assessComplianceRisk(id: string, input: {
    residualLikelihood: string;
    residualImpact: string;
    treatmentPlan?: string;
  }): Promise<any | undefined> {
    const risk = this.complianceRisks.find((r) => r.id === id);
    if (!risk) return undefined;
    risk.residualLikelihood = input.residualLikelihood;
    risk.residualImpact = input.residualImpact;
    risk.treatmentPlan = input.treatmentPlan ?? risk.treatmentPlan;
    risk.status = 'assessed';
    risk.updatedAt = new Date().toISOString();
    return risk;
  }

  async reviewComplianceRisk(id: string, input: {
    reviewNotes?: string;
    nextReviewDate: string;
  }): Promise<any | undefined> {
    const risk = this.complianceRisks.find((r) => r.id === id);
    if (!risk) return undefined;
    risk.lastReviewDate = new Date().toISOString();
    risk.nextReviewDate = input.nextReviewDate;
    risk.reviewNotes = input.reviewNotes ?? risk.reviewNotes;
    risk.updatedAt = new Date().toISOString();
    return risk;
  }

  // Dashboard & Reporting
  async getComplianceDashboard(tenantId: string, frameworkId?: string): Promise<any> {
    const requirements = this.complianceRequirements.filter((r) => 
      r.tenantId === tenantId && (!frameworkId || r.frameworkId === frameworkId)
    );
    const controls = this.complianceControls.filter((c) => 
      c.tenantId === tenantId
    );
    const findings = this.complianceFindings.filter((f) => 
      f.tenantId === tenantId && f.status === 'open'
    );
    const risks = this.complianceRisks.filter((r) => 
      r.tenantId === tenantId && (!frameworkId || r.frameworkId === frameworkId)
    );

    return {
      totalRequirements: requirements.length,
      implementedControls: controls.filter((c) => c.implementationStatus === 'implemented').length,
      totalControls: controls.length,
      openFindings: findings.length,
      criticalFindings: findings.filter((f) => f.severity === 'critical').length,
      highRisks: risks.filter((r) => r.status === 'identified' && r.inherentImpact === 'high').length,
      complianceScore: controls.length > 0 
        ? Math.round((controls.filter((c) => c.implementationStatus === 'implemented').length / controls.length) * 100)
        : 0,
    };
  }

  async getRequirementStatus(id: string): Promise<any> {
    const requirement = this.complianceRequirements.find((r) => r.id === id);
    if (!requirement) return undefined;

    const controls = this.complianceControls.filter((c) => c.requirementId === id);
    const evidence = this.complianceEvidence.filter((e) => e.requirementId === id);

    return {
      requirement,
      totalControls: controls.length,
      implementedControls: controls.filter((c) => c.implementationStatus === 'implemented').length,
      totalEvidence: evidence.length,
      validatedEvidence: evidence.filter((e) => e.validated).length,
    };
  }

  async getFrameworkCoverage(id: string): Promise<any> {
    const requirements = this.complianceRequirements.filter((r) => r.frameworkId === id);
    const controls = this.complianceControls.filter((c) => 
      requirements.some((r) => r.id === c.requirementId)
    );

    const categories = [...new Set(requirements.map((r) => r.category))];
    const coverageByCategory = categories.map((category) => {
      const categoryReqs = requirements.filter((r) => r.category === category);
      const categoryControls = controls.filter((c) => 
        categoryReqs.some((r) => r.id === c.requirementId)
      );
      return {
        category,
        totalRequirements: categoryReqs.length,
        implementedControls: categoryControls.filter((c) => c.implementationStatus === 'implemented').length,
        totalControls: categoryControls.length,
      };
    });

    return {
      frameworkId: id,
      totalRequirements: requirements.length,
      totalControls: controls.length,
      implementedControls: controls.filter((c) => c.implementationStatus === 'implemented').length,
      coverageByCategory,
    };
  }

  async getComplianceAuditLog(tenantId: string, filters?: {
    entityType?: string;
    entityId?: string;
    action?: string;
    from?: string;
    to?: string;
    limit?: number;
  }): Promise<any[]> {
    return this.complianceAuditLog.filter((log) => {
      if (log.tenantId !== tenantId) return false;
      if (filters?.entityType && log.entityType !== filters.entityType) return false;
      if (filters?.entityId && log.entityId !== filters.entityId) return false;
      if (filters?.action && log.action !== filters.action) return false;
      if (filters?.from && log.createdAt < filters.from) return false;
      if (filters?.to && log.createdAt > filters.to) return false;
      return true;
    }).slice(0, filters?.limit ?? 100);
  }

  // Operational Alert Event methods
  async recordOperationalAlertEvent(event: {
    id: string | undefined;
    alertId: string;
    tenantId: string;
    branchId?: string;
    eventType: string;
    actorType: string;
    actorUserId?: string;
    actorUserName?: string;
    actorService?: string;
    targetUserId?: string;
    targetUserName?: string;
    previousStatus?: string;
    newStatus?: string;
    metadata?: Record<string, unknown>;
    requestId?: string;
    correlationId?: string;
    sessionId?: string;
    ipAddress?: string;
    userAgent?: string;
    occurredAt: Date;
    createdAt: Date;
  }): Promise<void> {
    // Store in generic storage (could add dedicated array if needed)
    console.debug(`Recorded operational alert event: ${event.eventType} for alert ${event.alertId}`);
  }

  async listOperationalAlertEvents(
    alertId: string,
    tenantId: string
  ): Promise<any[]> {
    // Return empty array for now (would need dedicated storage)
    return [];
  }

  // Missing methods from ControlPlaneStore interface
  async updateLiveIncidentStatus(id: string, tenantId: string, cameraId: string, status: any): Promise<any> {
    const incident = this.liveIncidents.find(i => i.id === id && i.tenantId === tenantId && i.cameraId === cameraId);
    if (!incident) return undefined;
    incident.status = status;
    incident.updatedAt = new Date().toISOString();
    return incident;
  }

  async listAnalyticsRules(cameraId: string): Promise<AnalyticsRule[]> {
    return this.analyticsRules.filter(rule => rule.cameraId === cameraId);
  }

  async listAnalyticsRulesByCameraIds(cameraIds: string[]): Promise<AnalyticsRule[]> {
    const ids = new Set(cameraIds);
    return this.analyticsRules.filter((rule) => ids.has(rule.cameraId));
  }

  async listAlertNotificationsByAlertIds(tenantId: string, alertIds: string[]): Promise<AlertNotification[]> {
    const ids = new Set(alertIds);
    return this.analyticsNotifications
      .filter((item) => item.tenantId === tenantId && ids.has(item.alertId))
      .map((item) => structuredClone(item));
  }

  async listAmcContracts(tenantId: string, vendorId?: string): Promise<AmcContract[]> {
    return this.amcContracts.filter(contract => 
      contract.tenantId === tenantId && (!vendorId || contract.vendorId === vendorId)
    );
  }

  async getAmcContract(id: string): Promise<AmcContract | undefined> {
    return this.amcContracts.find(contract => contract.id === id);
  }

  async updateAmcContract(id: string, input: any): Promise<AmcContract | undefined> {
    const contract = this.amcContracts.find(c => c.id === id);
    if (!contract) return undefined;
    Object.assign(contract, input, { updatedAt: new Date().toISOString() });
    return contract;
  }

  async createMaintenanceSchedule(input: any): Promise<any> {
    const now = new Date().toISOString();
    const schedule = {
      id: randomUUID(),
      tenantId: input.tenantId,
      planId: input.planId,
      assetId: input.assetId,
      dueAt: input.dueAt,
      status: input.status ?? 'pending',
      createdBy: input.createdBy,
      createdAt: now,
      updatedAt: now,
    };
    this.maintenanceSchedules.push(schedule);
    return schedule;
  }

  async listMaintenanceSchedules(tenantId: string): Promise<any[]> {
    return this.maintenanceSchedules.filter(s => s.tenantId === tenantId);
  }

  async createMaintenanceVisit(input: any): Promise<any> {
    const now = new Date().toISOString();
    const visit = {
      id: randomUUID(),
      tenantId: input.tenantId,
      scheduleId: input.scheduleId,
      assetId: input.assetId,
      dueAt: input.dueAt,
      status: input.status ?? 'pending',
      visitedAt: input.visitedAt,
      createdBy: input.createdBy,
      createdAt: now,
      updatedAt: now,
    };
    this.maintenanceVisits.push(visit);
    return visit;
  }

  async listMaintenanceVisits(tenantId: string): Promise<any[]> {
    return this.maintenanceVisits.filter(v => v.tenantId === tenantId);
  }

  async createPredictiveAlert(input: any): Promise<any> {
    const now = new Date().toISOString();
    const alert = {
      id: randomUUID(),
      tenantId: input.tenantId,
      assetId: input.assetId,
      alertType: input.alertType,
      score: input.score,
      predictedFailureDate: input.predictedFailureDate,
      createdAt: now,
      updatedAt: now,
    };
    this.predictiveAlerts.push(alert);
    return alert;
  }

  async listPredictiveAlerts(tenantId: string): Promise<any[]> {
    return this.predictiveAlerts.filter(a => a.tenantId === tenantId);
  }

  async updateMaintenanceVisit(id: string, input: any): Promise<any | undefined> {
    const visit = this.maintenanceVisits.find(v => v.id === id);
    if (!visit) return undefined;
    Object.assign(visit, input, { updatedAt: new Date().toISOString() });
    return visit;
  }

  async ingestPredictiveAlert(input: { 
    tenantId: string; 
    assetId?: string; 
    type: string; 
    score: number; 
    details?: Record<string, unknown>; 
    detectedAt: string; 
  }): Promise<any> {
    const now = new Date().toISOString();
    const alert = {
      id: randomUUID(),
      tenantId: input.tenantId,
      assetId: input.assetId,
      type: input.type,
      score: input.score,
      details: input.details ?? {},
      detectedAt: input.detectedAt,
      createdAt: now,
      updatedAt: now,
    };
    this.predictiveAlerts.push(alert);
    return alert;
  }

  // Evidence Management Methods
  readonly evidenceCases: any[] = [];
  readonly evidenceItems: any[] = [];
  readonly custodyEvents: any[] = [];
  readonly evidenceExports: any[] = [];
  readonly evidenceManifests: any[] = [];
  readonly evidenceLegalHolds: any[] = [];

  async verifyRecordingSegment(segmentId: string): Promise<{ status: "verified" | "mismatch" | "missing"; hash?: string }> {
    const segment = await this.getRecordingSegment(segmentId);
    if (!segment) return { status: "missing" };
    if (segment.checksumSha256) {
      return { status: "verified", hash: segment.checksumSha256 };
    }
    return { status: "missing" };
  }

  async createEvidenceCase(input: any): Promise<any> {
    const now = new Date().toISOString();
    const caseRecord = {
      id: randomUUID(),
      tenantId: input.tenantId,
      caseNumber: input.caseNumber,
      title: input.title,
      description: input.description,
      status: "open",
      createdBy: input.createdBy,
      createdAt: now,
      updatedAt: now,
    };
    this.evidenceCases.push(caseRecord);
    return caseRecord;
  }

  async getEvidenceCase(id: string): Promise<any | undefined> {
    return this.evidenceCases.find(c => c.id === id);
  }

  async listEvidenceCases(tenantId: string, filters?: any): Promise<any[]> {
    return this.evidenceCases.filter(c => 
      c.tenantId === tenantId && (!filters?.status || c.status === filters.status)
    ).slice(0, filters?.limit ?? 100);
  }

  async updateEvidenceCaseStatus(id: string, status: any): Promise<any> {
    const caseRecord = this.evidenceCases.find(c => c.id === id);
    if (!caseRecord) return undefined;
    caseRecord.status = status;
    caseRecord.updatedAt = new Date().toISOString();
    return caseRecord;
  }

  async addEvidenceItem(caseId: string, input: any): Promise<any> {
    const now = new Date().toISOString();
    const item = {
      id: randomUUID(),
      caseId,
      type: input.type,
      cameraId: input.cameraId,
      startTime: input.startTime,
      endTime: input.endTime,
      recordingSegmentId: input.recordingSegmentId,
      description: input.description,
      addedBy: input.addedBy,
      hash: input.hash,
      fileSize: input.fileSize,
      createdAt: now,
    };
    this.evidenceItems.push(item);
    return item;
  }

  async listEvidenceItems(caseId: string): Promise<any[]> {
    return this.evidenceItems.filter(item => item.caseId === caseId);
  }

  async recordCustodyEvent(input: {
    evidenceId?: string;
    action: string;
    performedBy: string;
    sourceIp?: string;
    reason?: string;
  }): Promise<any> {
    const now = new Date().toISOString();
    const event = {
      id: randomUUID(),
      evidenceId: input.evidenceId,
      action: input.action,
      performedBy: input.performedBy,
      sourceIp: input.sourceIp,
      reason: input.reason,
      occurredAt: now,
    };
    this.custodyEvents.push(event);
    return event;
  }

  async getCustodyLog(evidenceId: string): Promise<any[]> {
    return this.custodyEvents.filter(event => event.evidenceId === evidenceId);
  }

  async createLegalHold(input: any): Promise<any> {
    const now = new Date().toISOString();
    const hold = {
      id: randomUUID(),
      caseNumber: input.caseNumber,
      reason: input.reason,
      requestedBy: input.requestedBy,
      cameraIds: input.cameraIds,
      startTime: input.startTime,
      endTime: input.endTime,
      reviewDate: input.reviewDate,
      expiryDate: input.expiryDate,
      createdAt: now,
    };
    this.evidenceLegalHolds.push(hold);
    return hold;
  }

  async releaseLegalHold(holdId: string, releasedBy: string): Promise<any | undefined> {
    const hold = this.evidenceLegalHolds.find(h => h.id === holdId);
    if (!hold) return undefined;
    hold.releasedBy = releasedBy;
    hold.releasedAt = new Date().toISOString();
    return hold;
  }

  async getEvidenceExport(exportId: string): Promise<any | undefined> {
    return this.evidenceExports.find(e => e.id === exportId);
  }

  async getEvidenceManifest(manifestId: string): Promise<any | undefined> {
    return this.evidenceManifests.find(m => m.id === manifestId);
  }

  // Device Inventory Management
  private readonly deviceInventory: any[] = [];

  async listDeviceInventory(tenantId: string, branchNodeId?: string): Promise<any[]> {
    const fromInventory = this.deviceInventory.filter((device) =>
      (!device.tenantId || device.tenantId === tenantId)
      && (!branchNodeId || device.branch === branchNodeId || device.branchId === branchNodeId)
    );

    const registeredCameras = Array.from(this.cameras.values())
      .filter((camera) => {
        const node = this.nodes.get(camera.nodeId);
        const belongsToTenant = node?.tenantId === tenantId;
        const belongsToBranch = !branchNodeId
          || camera.branchId === branchNodeId
          || camera.nodeId === branchNodeId;
        return belongsToTenant && belongsToBranch;
      })
      .map((camera) => {
        const node = this.nodes.get(camera.nodeId)!;
        return clean({
          id: camera.id,
          deviceId: camera.deviceIdentityId ?? camera.id,
          tenantId: node.tenantId,
          branchId: camera.branchId,
          nodeId: camera.nodeId,
          deviceType: camera.sourceType ?? 'ip-camera',
          manufacturer: camera.vendor,
          model: camera.model,
          serialNumber: camera.serialNumber,
          ipAddress: camera.ipAddress,
          healthStatus: camera.status,
          lifecycleState: 'operational',
          capabilities: camera.capabilities,
          profiles: camera.profiles,
          firstSeenAt: camera.firstSeenAt,
          lastSeenAt: camera.lastSeenAt,
        });
      });

    const knownIds = new Set(fromInventory.map((device) => device.id));
    return [...fromInventory, ...registeredCameras.filter((device) => !knownIds.has(device.id))];
  }

  async getDeviceInventory(id: string): Promise<any | null> {
    const fromInventory = this.deviceInventory.find((device) => device.id === id || device.deviceId === id);
    if (fromInventory) return fromInventory;

    const camera = this.cameras.get(id)
      ?? Array.from(this.cameras.values()).find((candidate) => candidate.deviceIdentityId === id);
    if (!camera) return null;

    const node = this.nodes.get(camera.nodeId);
    return clean({
      id: camera.id,
      deviceId: camera.deviceIdentityId ?? camera.id,
      tenantId: node?.tenantId,
      branchId: camera.branchId,
      nodeId: camera.nodeId,
      deviceType: camera.sourceType ?? 'ip-camera',
      manufacturer: camera.vendor,
      model: camera.model,
      serialNumber: camera.serialNumber,
      ipAddress: camera.ipAddress,
      healthStatus: camera.status,
      lifecycleState: 'operational',
      capabilities: camera.capabilities,
      profiles: camera.profiles,
      firstSeenAt: camera.firstSeenAt,
      lastSeenAt: camera.lastSeenAt,
    });
  }

  async createDeviceInventoryRecord(input: any): Promise<any> {
    const record = {
      id: randomUUID(),
      ...input,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.deviceInventory.push(record);
    return record;
  }

  async createDeviceConfigurationJob(input: {
    tenantId: string;
    deviceId: string;
    jobType: 'credential-rotation' | 'ip-change' | 'template-apply' | 'firmware-upgrade' | 'reboot';
    requestedBy: string;
    reason: string;
    priority: 'low' | 'normal' | 'high' | 'critical';
    payload: Record<string, any>;
    status: string;
    edgeAgentId?: string;
  }): Promise<any> {
    const job = {
      id: randomUUID(),
      tenantId: input.tenantId,
      deviceId: input.deviceId,
      jobType: input.jobType,
      requestedBy: input.requestedBy,
      reason: input.reason,
      priority: input.priority,
      payload: input.payload,
      status: input.status,
      edgeAgentId: input.edgeAgentId,
      attempts: 0,
      maxAttempts: 3,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.deviceConfigurationJobs.push(job);
    return job;
  }

  async getDeviceConfigurationJob(jobId: string): Promise<any | undefined> {
    return this.deviceConfigurationJobs.find((j) => j.id === jobId);
  }

  async listDeviceConfigurationJobs(tenantId: string, filters?: { deviceId?: string; status?: string; limit?: number }): Promise<any[]> {
    let result = this.deviceConfigurationJobs.filter((j) => !j.tenantId || j.tenantId === tenantId);
    if (filters?.deviceId) {
      result = result.filter((j) => j.deviceId === filters.deviceId);
    }
    if (filters?.status) {
      const statuses = filters.status.split(',').map((s) => s.trim());
      result = result.filter((j) => statuses.includes(j.status));
    }
    if (filters?.limit) {
      result = result.slice(0, filters.limit);
    }
    return result;
  }

  async claimDeviceConfigurationJobs(input: { limit: number; now: string }): Promise<any[]> {
    const claimed: any[] = [];
    for (const job of this.deviceConfigurationJobs) {
      if (job.status === 'queued' && claimed.length < input.limit) {
        job.status = 'claimed';
        job.startedAt = input.now;
        job.updatedAt = input.now;
        claimed.push(job);
      }
    }
    return claimed;
  }

  async updateDeviceJobStatus(jobId: string, updates: {
    status?: string;
    attempts?: number;
    error?: string;
    nextAttemptAt?: string;
    startedAt?: string;
    completedAt?: string;
  }): Promise<any> {
    const job = this.deviceConfigurationJobs.find((j) => j.id === jobId);
    if (!job) return null;
    Object.assign(job, updates, { updatedAt: new Date().toISOString() });
    return job;
  }

  async updateDeviceJobResult(jobId: string, result: Record<string, any>): Promise<any> {
    const job = this.deviceConfigurationJobs.find((j) => j.id === jobId);
    if (!job) return null;
    job.result = result;
    job.updatedAt = new Date().toISOString();
    return job;
  }

  async createDeviceJobStep(input: {
    jobId: string;
    stepNumber: number;
    stepName: string;
    status: 'pending' | 'running' | 'completed' | 'failed' | 'skipped';
    startedAt?: string;
  }): Promise<any> {
    const step = {
      id: randomUUID(),
      ...input,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.deviceJobSteps.push(step);
    return step;
  }

  async completeDeviceJobStep(input: {
    jobId: string;
    stepNumber: number;
    status: 'completed' | 'failed' | 'skipped';
    completedAt: string;
    durationMs?: number;
    result?: Record<string, any>;
    error?: string;
  }): Promise<any> {
    const step = this.deviceJobSteps.find((s) => s.jobId === input.jobId && s.stepNumber === input.stepNumber);
    if (!step) return null;
    Object.assign(step, input, { updatedAt: new Date().toISOString() });
    return step;
  }

  async listDeviceJobSteps(jobId: string): Promise<any[]> {
    return this.deviceJobSteps.filter((s) => s.jobId === jobId).sort((a, b) => a.stepNumber - b.stepNumber);
  }

  async createBranchNetwork(input: {
    tenantId: string;
    branchId: string;
    networkCidr: string;
    gateway: string;
    dnsServers?: string[];
    vlanId?: number;
    dhcpRangeStart?: string;
    dhcpRangeEnd?: string;
    reservedRangeStart?: string;
    reservedRangeEnd?: string;
  }): Promise<any> {
    const record = {
      id: randomUUID(),
      ...input,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.branchNetworks.set(input.branchId, record);
    return record;
  }

  async getBranchNetwork(branchId: string): Promise<any | undefined> {
    return this.branchNetworks.get(branchId) || {
      id: `net-${branchId}`,
      branchId,
      networkCidr: '192.168.1.0/24',
      gateway: '192.168.1.1',
      dnsServers: ['8.8.8.8', '1.1.1.1'],
      vlanId: 10,
      dhcpRangeStart: '192.168.1.100',
      dhcpRangeEnd: '192.168.1.200',
    };
  }

  async updateBranchNetwork(branchId: string, input: any): Promise<any | undefined> {
    const existing = await this.getBranchNetwork(branchId);
    const updated = { ...existing, ...input, updatedAt: new Date().toISOString() };
    this.branchNetworks.set(branchId, updated);
    return updated;
  }

  async createIpAssignment(input: {
    tenantId: string;
    branchId: string;
    deviceId: string;
    ipAddress: string;
    subnet: string;
    assignmentType: 'static' | 'dhcp-reservation';
    assignedBy: string;
  }): Promise<any> {
    const assignment = {
      id: randomUUID(),
      ...input,
      status: 'active',
      assignedAt: new Date().toISOString(),
    };
    this.deviceIpAssignments.push(assignment);
    return assignment;
  }

  // Recorder Device Profiles & Compatibility Store
  private readonly recorderProfiles = new Map<string, RecorderDeviceProfile>();
  private readonly refingerprintTasks = new Map<string, any>();

  async upsertRecorderProfile(profile: RecorderDeviceProfile): Promise<void> {
    this.recorderProfiles.set(profile.recorderId, profile);
  }

  async getRecorderProfile(recorderId: string): Promise<RecorderDeviceProfile | null> {
    return this.recorderProfiles.get(recorderId) ?? null;
  }

  async listRecorderProfiles(filter?: { tenantId?: string; branchId?: string }): Promise<RecorderDeviceProfile[]> {
    return Array.from(this.recorderProfiles.values()).filter((p) => {
      if (filter?.tenantId && p.tenantId !== filter.tenantId) return false;
      if (filter?.branchId && p.branchId !== filter.branchId) return false;
      return true;
    });
  }

  async getRecorderEvidence(recorderId: string): Promise<{
    identityEvidence: IdentityEvidence[];
    apiEvidence: ApiFamilyEvidence[];
    capabilities: any;
    signature: string;
    lastFingerprintedAt: string;
  } | null> {
    const profile = this.recorderProfiles.get(recorderId);
    if (!profile) return null;
    return {
      identityEvidence: profile.identityEvidence,
      apiEvidence: profile.apiEvidence,
      capabilities: profile.fingerprint.capabilities,
      signature: profile.signature,
      lastFingerprintedAt: profile.lastFingerprintedAt,
    };
  }

  async queueRecorderRefingerprint(
    recorderId: string,
    reason: string,
    probeFamilies?: string[],
  ): Promise<{ queued: boolean; taskId?: string }> {
    const taskId = `refingerprint-${randomUUID()}`;
    this.refingerprintTasks.set(taskId, {
      taskId,
      recorderId,
      reason,
      probeFamilies,
      queuedAt: new Date().toISOString(),
      status: "queued",
    });
    return { queued: true, taskId };
  }

  async getCompatibilityCatalog(): Promise<CompatibilityCatalogEntry[]> {
    const catalogMap = new Map<string, CompatibilityCatalogEntry>();

    for (const p of this.recorderProfiles.values()) {
      const mfr = p.fingerprint.manufacturer || "Unknown";
      const model = p.fingerprint.model || "Unknown";
      const fw = p.fingerprint.firmwareVersion ? `${p.fingerprint.firmwareVersion.split(".")[0]}.x` : "General";
      const key = `${mfr}::${model}::${fw}`;

      const existing = catalogMap.get(key);
      if (!existing) {
        const likelyApis: { family: any; probability: number }[] = [];
        if (p.fingerprint.detectedApiFamilies.dahuaCgi) likelyApis.push({ family: "DAHUA_CGI", probability: 0.95 });
        if (p.fingerprint.detectedApiFamilies.onvif) likelyApis.push({ family: "ONVIF", probability: 0.92 });
        if (p.fingerprint.detectedApiFamilies.hikvisionIsapi) likelyApis.push({ family: "HIKVISION_ISAPI", probability: 0.95 });
        if (p.fingerprint.detectedApiFamilies.rtsp) likelyApis.push({ family: "RTSP", probability: 0.90 });

        const likelyCapabilities: Record<string, number> = {};
        for (const [capKey, cap] of Object.entries(p.fingerprint.capabilities)) {
          likelyCapabilities[capKey] = cap.state === "SUPPORTED" ? 1.0 : cap.state === "PARTIAL" ? 0.6 : 0.0;
        }

        catalogMap.set(key, {
          manufacturer: mfr,
          model,
          firmwareRange: fw,
          observedCount: 1,
          likelyApis,
          likelyCapabilities,
          lastObservedAt: p.lastFingerprintedAt,
        });
      } else {
        existing.observedCount += 1;
        if (new Date(p.lastFingerprintedAt) > new Date(existing.lastObservedAt)) {
          existing.lastObservedAt = p.lastFingerprintedAt;
        }
      }
    }

    if (catalogMap.size === 0) {
      catalogMap.set("CP PLUS::CP-UNR-4K4322-V2::4.x", {
        manufacturer: "CP PLUS",
        model: "CP-UNR-4K4322-V2",
        firmwareRange: "4.x",
        observedCount: 12,
        likelyApis: [
          { family: "DAHUA_CGI", probability: 0.98 },
          { family: "ONVIF", probability: 0.95 },
          { family: "RTSP", probability: 0.92 },
        ],
        likelyCapabilities: {
          deviceInfo: 0.98,
          channels: 0.97,
          liveStream: 0.95,
          recordingStatus: 0.90,
          playbackSearch: 0.94,
          storageStatus: 0.96,
          smartTelemetry: 0.72,
          deviceTime: 0.94,
          events: 0.70,
          ptz: 0.88,
        },
        lastObservedAt: new Date().toISOString(),
      });
      catalogMap.set("CP PLUS::CP-UVR-1601E1-CS::3.x", {
        manufacturer: "CP PLUS",
        model: "CP-UVR-1601E1-CS",
        firmwareRange: "3.x",
        observedCount: 8,
        likelyApis: [
          { family: "DAHUA_CGI", probability: 0.95 },
          { family: "ONVIF", probability: 0.90 },
          { family: "RTSP", probability: 0.88 },
        ],
        likelyCapabilities: {
          deviceInfo: 0.95,
          channels: 0.95,
          liveStream: 0.90,
          recordingStatus: 0.85,
          playbackSearch: 0.88,
          storageStatus: 0.92,
          smartTelemetry: 0.50,
          deviceTime: 0.90,
          events: 0.65,
          ptz: 0.75,
        },
        lastObservedAt: new Date().toISOString(),
      });
    }

    return Array.from(catalogMap.values());
  }
}


function hashToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}
